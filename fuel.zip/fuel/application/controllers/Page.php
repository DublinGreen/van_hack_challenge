<?php ob_start(); // Start output buffer

defined('BASEPATH') OR exit('No direct script access allowed');

#Controller for all pages not directly controlled by fuel CMS 
class Page extends CI_Controller {
	
	#social media class variable
	var $socialFacebook = "https://facebook.com";
	var $socialTwitter = "https://twitter.com";
	var $socialInstagram = "https://instagram.com";
	var $socialYoutube = "https://youtube.com";
	var $socialGooglePlus = "https://googleplus.com";
	
	var $appName = "Governance watchers";

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->database();
        $this->load->helper('file');
        $this->load->helper('html');
        $this->load->library('email');
        $this->load->helper('cookie');
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->helper('number');
    }

//Landing page (index page)
	public function index(){
		$data = array();
		$data['title'] = "Home";
		$data['warning'] = "";
		$data['message'] = "";
		
		$data['social_facebook'] = $this->socialFacebook;
		$data['social_twitter'] = $this->socialTwitter;
		$data['social_google'] = $this->socialGooglePlus;
		$data['social_instagram'] = $this->socialInstagram;
		$data['social_youtube'] = $this->socialYoutube;
		
		$data['posts'] = $this->ApplicationModel->getBlogPost();// post variable

//dynamic SEO meta tags
		$meta = array(
            array(
                'name' => 'robots',
                'content' => 'no-cache'
            ),
            array(
                'name' => 'description',
                'content' => "{$this->appName}, we provide hot news on a daily."
            ),
            array(
                'name' => 'keywords',
                'content' => "{$this->appName}, news in nigeria,breaking news in nigeria"
            ),
            array(
                'name' => 'author',
                'content' => 'greenDevNG'
            ),
            array(
                'name' => 'Content-type',
                'content' => 'text/html; charset=utf-8', 'type' => 'equiv'
            ), array(
                'name' => 'viewport',
                'content' => 'width=device-width, initial-scale=1'
            )
        );
		$data['meta'] = $meta;
		
		$this->load->view('page_views/header', $data);
        $this->load->view('page_views/nav', $data);
        $this->load->view('page_views/index_view', $data);
        $this->load->view('page_views/footer', $data);
	}

	public function surveySubmitQANDA($surveyId,$surveyOptionId){
		$ipAddr = $this->ApplicationModel->getIP();
		
		$query = $this->db->get_where('survey_options', array('id' => $surveyOptionId,'survery_id' => $surveyId));
		$row = $query->row();
		
		if ($query->num_rows() > 0){										
			$insertData = array(
			   'user_ip' => $ipAddr,
			   'survey_id' => $surveyId,
			   'survey_options_id' => $row->id,
			   'survey_option_choice' => $row->options_slot
			);
			$this->db->insert('survey_answers', $insertData); 	
			
			// set survey as session data to make the user survey entry
			$a = $surveyId;
			$this->session->set_userdata("governance_watchers_{$a}", "yes");
		}
		
		// with 301 redirect
		redirect('/page/survey', 'survey', 301);
    }
    
    public function surveyOpinion($surveyId){
		$data = array();
		$data['title'] = "Survey Opinion";
		$data['warning'] = "";
		$data['message'] = "";
		
		$data['social_facebook'] = $this->socialFacebook;
		$data['social_twitter'] = $this->socialTwitter;
		$data['social_google'] = $this->socialGooglePlus;
		$data['social_instagram'] = $this->socialInstagram;
		$data['social_youtube'] = $this->socialYoutube;
		$data['id'] = $surveyId;
		$data['survey'] = $this->ApplicationModel->getSurveyById($surveyId);
		
		if(empty($data['survey'])){
			// with 301 redirect
			redirect('/page/survey', 'survey', 301);
		}
		$data['surveyAnswers'] = $this->ApplicationModel->getSurveyAnswersOpinion($surveyId);

		$meta = array(
            array(
                'name' => 'robots',
                'content' => 'no-cache'
            ),
            array(
                'name' => 'description',
                'content' => "Contact {$this->appName}, we will love to hear from you."
            ),
            array(
                'name' => 'keywords',
                'content' => "{$this->appName},governance watchers survey"
            ),
            array(
                'name' => 'author',
                'content' => 'greenDevNG'
            ),
            array(
                'name' => 'Content-type',
                'content' => 'text/html; charset=utf-8', 'type' => 'equiv'
            ), array(
                'name' => 'viewport',
                'content' => 'width=device-width, initial-scale=1'
            )
        );
		$data['meta'] = $meta;


		$this->form_validation->set_rules('comment', 'Comment', 'required');
		$this->form_validation->set_rules('author', 'Name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		 if ($this->form_validation->run() == FALSE){
		}else{
			$comment = $this->input->post_get('comment', TRUE);
			$author = $this->input->post_get('author', TRUE);
			$email = $this->input->post_get('email', TRUE);
			$tel = $this->input->post_get('tel', TRUE);
			
			$insertData = array(
				'survey_id' => $surveyId,
				'answer' => $comment,
				'name' => $author,
				'email' => $email,
				'telephone' => $tel
			);
			$this->db->insert('survey_answers', $insertData); 			
			$data['message'] = "Thanks for your opinion., your comment has been submitted for review.";
			
		}
		
		//same view for all form state
		$this->load->view('page_views/header', $data);
        $this->load->view('page_views/nav', $data);
        $this->load->view('page_views/take_survey_view', $data);
        $this->load->view('page_views/footer', $data);
	}

    public function survey() {
		$data = array();
		$data['title'] = "Survey";
		$data['warning'] = "";
		$data['message'] = "";
		
		$data['social_facebook'] = $this->socialFacebook;
		$data['social_twitter'] = $this->socialTwitter;
		$data['social_google'] = $this->socialGooglePlus;
		$data['social_instagram'] = $this->socialInstagram;
		$data['social_youtube'] = $this->socialYoutube;
		
		$data['posts'] = $this->ApplicationModel->getBlogPost();

		$meta = array(
            array(
                'name' => 'robots',
                'content' => 'no-cache'
            ),
            array(
                'name' => 'description',
                'content' => "Contact {$this->appName}, we will love to hear from you."
            ),
            array(
                'name' => 'keywords',
                'content' => "{$this->appName},governance watchers survey"
            ),
            array(
                'name' => 'author',
                'content' => 'greenDevNG'
            ),
            array(
                'name' => 'Content-type',
                'content' => 'text/html; charset=utf-8', 'type' => 'equiv'
            ), array(
                'name' => 'viewport',
                'content' => 'width=device-width, initial-scale=1'
            )
        );
		$data['meta'] = $meta;
		
		$this->load->view('page_views/header', $data);
        $this->load->view('page_views/nav', $data);
        $this->load->view('page_views/survey_view', $data);
        $this->load->view('page_views/footer', $data);
    }

    public function contact() {
		$data = array();
		$data['title'] = "Contact Us";
		$data['warning'] = "";
		$data['message'] = "";
		
		$data['social_facebook'] = $this->socialFacebook;
		$data['social_twitter'] = $this->socialTwitter;
		$data['social_google'] = $this->socialGooglePlus;
		$data['social_instagram'] = $this->socialInstagram;
		$data['social_youtube'] = $this->socialYoutube;

		$meta = array(
            array(
                'name' => 'robots',
                'content' => 'no-cache'
            ),
            array(
                'name' => 'description',
                'content' => "Contact {$this->appName}, we will love to hear from you."
            ),
            array(
                'name' => 'keywords',
                'content' => "{$this->appName},contact governance watchers, news in nigeria,breaking news in nigeria"
            ),
            array(
                'name' => 'author',
                'content' => 'greenDevNG'
            ),
            array(
                'name' => 'Content-type',
                'content' => 'text/html; charset=utf-8', 'type' => 'equiv'
            ), array(
                'name' => 'viewport',
                'content' => 'width=device-width, initial-scale=1'
            )
        );
		$data['meta'] = $meta;

		$this->form_validation->set_rules('comment', 'Comment', 'required');
		$this->form_validation->set_rules('author', 'Name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		 if ($this->form_validation->run() == FALSE){
		}else{
			$comment = $this->input->post_get('comment', TRUE);
			$author = $this->input->post_get('author', TRUE);
			$email = $this->input->post_get('email', TRUE);
			$url = $this->input->post_get('url', TRUE);

			if(valid_email($email)){
				$config['protocol'] = 'sendmail';
				$config['mailpath'] = '/usr/sbin/sendmail';
				$config['charset'] = 'iso-8859-1';
				$config['wordwrap'] = TRUE;
				$confir['smtp_host'] = "mail.governancewatchers.org";
				$confir['smtp_user'] = "info@governancewatchers.org";
				$confir['smtp_pass'] = "Steeldubs0077!@#";
				$confir['smtp_port'] = "25";
				$this->email->initialize($config);
				
				$this->email->from($email, $author);
				$this->email->to('info@governancewatchers.org');
				$this->email->subject("Email From {$author}");
				$this->email->message($comment);
				$this->email->send();
				$data['message'] = "Message has been sent.";
			}else{
				$data['warning'] = "Hey, don't think this email is valid";
			}
		}
		
		//same view for all form state
		$this->load->view('page_views/header', $data);
        $this->load->view('page_views/nav', $data);
        $this->load->view('page_views/contact_view', $data);
        $this->load->view('page_views/footer', $data);
    }
}

ob_flush();
