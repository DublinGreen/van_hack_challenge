<?php 

/*
|--------------------------------------------------------------------------
| Google Analytics
|--------------------------------------------------------------------------
| Google Analytics UACCT value
| If this value == Nothing, then nothing will be inserted into the view
| Used in google_helper
*/

$config['google_uacct'] = "";

/* End of file strings.php */
/* Location: ./application/config/google.php */