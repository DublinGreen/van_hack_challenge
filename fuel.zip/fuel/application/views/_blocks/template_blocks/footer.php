
        <footer>
            <div class="container-fluid">
                <div class="row">
                    <div class="vk-sec-footer">
                        <div class="container">
                            <div class="row">
                                <div class="vk-footer">
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <div class="widget-title">
                                                <a href="#"><img src="<?php echo fuel_var('template_assets', ''); ?>image/governance_watchers.png"" alt="" class="img-responsive"></a>
                                            </div>
                                            <div class="widget-content">
                                                <div class="vk-footer-1">

                                                    <div class="vk-footer-1-content">
                                                        <p>
															<?php echo $this->fuel->blocks->render('company_about_footer'); ?>
                                                        </p>
                                                        <div class="vk-footer-1-address">
                                                            <ul>
                                                                <li><i class="fa fa-map-marker" aria-hidden="true"></i> <span><?php echo $this->fuel->blocks->render('footer_company_address'); ?></span></li>
                                                                <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <span><a href="mailto:<?php echo $this->fuel->blocks->render('company_official_email'); ?>"><?php echo $this->fuel->blocks->render('company_official_email'); ?></a></span></li>
                                                                <li><i class="fa fa-headphones" aria-hidden="true"></i> <span> <?php echo $this->fuel->blocks->render('company_telephone'); ?></span></li>
                                                            </ul>
                                                        </div>
                                                        <div class="vk-footer-1-icon">
                                                            <ul>
																<li><a target="_blank" href="<?php echo $this->fuel->blocks->render('social_facebook'); ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
																<li><a target="_blank" href="<?php echo $this->fuel->blocks->render('social_twitter'); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
																<li><a target="_blank" href="<?php echo $this->fuel->blocks->render('social_google'); ?>"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
																<li><a target="_blank" href="<?php echo $this->fuel->blocks->render('social_instagram'); ?>"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
																<li><a target="_blank" href="<?php echo $this->fuel->blocks->render('social_youtube'); ?>"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <h3 class="widget-title"> Latest News</h3>
                                            <div class="widget-content">
                                                <div class="vk-footer-2">
                                                    <div class="vk-footer-2-content">
														  <ul>
																<?php
																	$posts = $this->ApplicationModel->getBlogPost();
																	foreach($posts as $post){
																		$category = $this->ApplicationModel->getCategoryById($post->category_id);
																		if(!empty($post->main_image)){																		
																			static $counter = 0;
																			if($counter <= 2){
																				$b = base_url();
																				$postImg = $post->main_image;
																				$postImg = str_replace("{img_path('","{$b}assets/images/",$postImg);
																				$postImg = str_replace("')}","",$postImg);
																				$postImg = str_replace('alt=""',"alt='{$post->title}' width='10%' height='10%'" ,$postImg);
																				$category = $this->ApplicationModel->getCategoryById($post->category_id);
																				
																				$publishDate = strtotime($post->publish_date,time());
																				$publishDateFormat = strftime("%Y/%m/%d",$publishDate);
																				$publishDateFormat2 = date("l jS \of F Y",$publishDate);
																?>
																		<li>
																			<!--<div class="vk-footer-img">
																				<?php echo($postImg); ?>
																			</div>-->
																			<div class="vk-footer-content" style="padding-left: 0px;">
																				<div class="vk-footer-title">
																					<h2><a href="#"><a href="<?php echo(base_url() . "blog/{$publishDateFormat}/{$post->slug}"); ?>"><?php echo($post->title); ?> </a></a></h2>
																				</div>
																				<div class="vk-footer-time">
																					<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo($publishDateFormat2); ?></div>
																				</div>
																			</div>
																			<div class="clearfix"></div>
																		</li>
																<?php
																			}
																			$counter++;
																		}
																	}	
																?>
															</ul>
                                                      </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <h3 class="widget-title">Twitter Feeds</h3>
                                            <div class="widget-content">
                                                <div class="vk-footer-3">
                                                    <div class="vk-footer-3-content">
                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> Goverance watchers</a></span>
                                                            Twitter, twitter, twitter news
                                                        </p>
                                                        <div class="time">about 1 days ago</div>

                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> Goverance watchers</a></span>
                                                            More twitter, twitter, twitter news
                                                        </p>
                                                        <div class="time">about 2 days ago</div>

                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> Goverance watchers</a></span>
                                                            More twitter, twitter, twitter news
                                                        </p>
                                                        <div class="time">about 3 days ago</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="vk-sub-footer">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="vk-sub-footer-1">
                                            <p>
                                                <span><?php echo $this->fuel->blocks->render('company_name'); ?></span>
                                                -  News & More.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-5 col-md-offset-2">
                                        <div class="vk-sub-footer-2">
                                            <ul>
                                                <li><a href="<?php echo(base_url() . "disclaimer"); ?>">Disclaimer </a></li>
                                                <li><a href="<?php echo(base_url() . "privacy"); ?>"> Privacy</a></li>
                                                <li><a href="<?php echo(base_url() . "advertisement"); ?>"> Advertisement</a></li>
                                                <li><a href="<?php echo(base_url() . "page/contact"); ?>">Contact us</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>

        <script src="<?php echo fuel_var('template_assets', ''); ?>js/jquery-2.0.2.min.js"></script>
        <script src="<?php echo fuel_var('template_assets', ''); ?>js/jquery.sticky.js"></script>
        <script src="<?php echo fuel_var('template_assets', ''); ?>js/masonry.min.js"></script>
        <script src="<?php echo fuel_var('template_assets', ''); ?>js/jquery-ui.min.js"></script>
        <script src="<?php echo fuel_var('template_assets', ''); ?>js/bootstrap.min.js"></script>
        <script src="<?php echo fuel_var('template_assets', ''); ?>dist/owl.carousel.js"></script>
        <script src="<?php echo fuel_var('template_assets', ''); ?>js/main.js"></script>
        <script src="<?php echo fuel_var('template_assets', ''); ?>js/bootstrap-hover-tabs.js"></script>
    </body>
</html>
