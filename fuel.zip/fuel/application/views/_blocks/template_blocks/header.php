<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="keywords" content="<?php echo fuel_var('meta_keywords') ?>">
        <meta name="description" content="<?php echo fuel_var('meta_description') ?>">
        <!-- Latest compiled and minified CSS -->
        
        <link rel="stylesheet" href="<?php echo fuel_var('template_assets', ''); ?>dist/assets/owl.carousel.min.css">
        <link rel="stylesheet" href="<?php echo fuel_var('template_assets', ''); ?>dist/assets/owl.theme.default.min.css">
        <link rel="stylesheet" href="<?php echo fuel_var('template_assets', ''); ?>css/bootstrap.min.css">

        <!-- Optional theme -->
        <link rel="stylesheet" href="<?php echo fuel_var('template_assets', ''); ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" id="themify-icons-css" href="<?php echo fuel_var('template_assets', ''); ?>css/themify-icons.css" type="text/css" media="all">
        <link rel="stylesheet" href="<?php echo fuel_var('template_assets', ''); ?>css/style.css">
        <link rel="stylesheet" href="<?php echo fuel_var('template_assets', ''); ?>css/jquery-ui.min.css">
        <link rel="stylesheet" href="<?php echo fuel_var('template_assets', ''); ?>css/fonts.css">
        <link rel="stylesheet" href="<?php echo fuel_var('template_assets', ''); ?>css/font-awesome.min.css">
        <link rel="shortcut icon" href="<?php echo fuel_var('template_assets', ''); ?>/favicon.png">
        <title>
            <?php
            if (!empty($is_blog)) :
                echo $CI->fuel->blog->page_title($page_title, ' : ', 'right');
            else:
                echo fuel_var('page_title', '');
            endif;
            ?>
        </title>
        <link href='http://fonts.googleapis.com/css?family=Raleway:400,700' rel='stylesheet' type='text/css'>
    </head>
