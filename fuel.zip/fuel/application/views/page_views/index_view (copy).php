		<div id="main-content" class="site-main-content">
			<div id="home-main-content" class="site-home-main-content">
				<div id="vk-home-default-slide">
					<div class="container-fluid">
						<div class="row">
							<!--HOME 1 SLIDE-->
							<div id="uni-home-defaults-slide">
								<div id="vk-owl-demo-singer-slider" class="owl-carousel owl-theme">		
										<?php
											$posts = $this->ApplicationModel->getBlogPost();
											foreach($posts as $post){
												$b = base_url();
												$postImg = $post->main_image;
												$postImg = str_replace("{img_path('","{$b}assets/images/",$postImg);
												$postImg = str_replace("')}","",$postImg);
												$postImg = str_replace('alt=""',"alt='{$post->title}' class='img img-responsive'",$postImg);
												$category = $this->ApplicationModel->getCategoryById($post->category_id);
												
												$publishDate = strtotime($post->publish_date,time());
												$publishDateFormat = strftime("%Y/%m/%d",$publishDate);
												$publishDateFormat2 = date("l jS \of F Y h:i:s A",$publishDate);
										?>		
											<div class="item"><!-- ITEM START-->
												<div class="container-fluid">
													<?php echo($postImg); ?>
												</div>
												<div class="vk-item-caption">
													<div class="vk-item-caption-top">
														<ul>
															<li><a href="<?php echo(base_url() . "blog/categories/" . $category->slug); ?>"><?php echo( strtoupper($category->name) ); ?></a></li>
														</ul>
														<div class="clearfix"></div>
													</div>
													<div class="vk-item-caption-text">
														<h2><a href="<?php echo(base_url() . "blog/{$publishDateFormat}/{$post->slug}"); ?>"><?php echo($post->title); ?></a></h2>
													</div>
													<div class="vk-item-caption-time">
														<span class="time"> <?php echo($publishDateFormat2); ?></span>
													</div>
												</div>
											</div><!-- ITEM STOP-->
										<?php		
											}
										?>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div id="vk-home-default-body">
					<div class="container">
						<div class="row">
							<div class="col-md-8">
								
								
								
								<hr>
								<br><br>
								
								<div id="vk-home-default-left">

									<!--HOME DEFAULT HOT NEWS-->
									
									<div class="vk-home-tech-left">
                                        <div class="vk-tech-left-sec-2">
                                            <div class="uni-sticker-label">
                                                <div class="label-info">
                                                    <a href="#">
                                                        <img src="image/homepage1/icon/fire.png" alt="" class="img-responsive img-gen">
                                                        <img src="image/fire-red.png" alt="" class="img-responsive img-hover">
                                                        <span class="label-title">Popular News</span>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="vk-tech-left-sec-2-big">
                                                <div class="vk-home-sport-left-img">
                                                    <div class="item-img1">
                                                        <!--                                                        <a href=""><img src="image/01_04_techology/sec-3/img4.jpg" alt="" class="img-responsive"></a>-->
                                                    </div>
                                                    <div class="vk-home-sport-left-caption">
                                                        <div class="vk-item-caption-top">
                                                            <a href="#">Application</a>
                                                        </div>
                                                        <div class="clearfix"></div>
                                                        <div class="vk-item-caption-text">
                                                            <h2><a href="#">Lorem ipsum dolor sit amet, consect adipiscing elit</a></h2>
                                                        </div>
                                                        <div class="vk-fashion-sec-2-left-time">
                                                            <ul>
                                                                <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="vk-tech-left-sec-2-small">
                                                <ul>
                                                    <li class="vk-item">
                                                        <div class="vk-home-sport-left-img">
                                                            <div class="item-img2">
                                                                <!--                                                                <a href=""><img src="image/01_04_techology/sec-3/img9.jpg" alt="" class="img-responsive"></a>-->
                                                            </div>
                                                            <div class="vk-home-sport-left-caption">
                                                                <div class="vk-item-caption-top">
                                                                    <a href="#">Application</a>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                                <div class="vk-item-caption-text">
                                                                    <h2><a href="#">Lorem ipsum dolor sit amet, consect adipiscing elit</a></h2>
                                                                </div>
                                                                <div class="vk-fashion-sec-2-left-time">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                        <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                        <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="vk-item">
                                                        <div class="vk-home-sport-left-img">
                                                            <div class="item-img3">
                                                                <!--                                                                <a href=""><img src="image/01_04_techology/sec-3/img-2.jpg" alt="" class="img-responsive"></a>-->
                                                            </div>
                                                            <div class="vk-home-sport-left-caption">
                                                                <div class="vk-item-caption-top">
                                                                    <a href="#">Car</a>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                                <div class="vk-item-caption-text">
                                                                    <h2><a href="#">Lorem ipsum dolor sit amet, consect adipiscing elit</a></h2>
                                                                </div>
                                                                <div class="vk-fashion-sec-2-left-time">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                        <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                        <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="vk-item">
                                                        <div class="vk-home-sport-left-img">
                                                            <div class="item-img4">
                                                                <!--                                                                <a href=""><img src="image/01_04_techology/sec-3/img-1.jpg" alt="" class="img-responsive"></a>-->
                                                            </div>
                                                            <div class="vk-home-sport-left-caption">
                                                                <div class="vk-item-caption-top">
                                                                    <a href="#">Applycation</a>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                                <div class="vk-item-caption-text">
                                                                    <h2><a href="#">Lorem ipsum dolor sit amet, consect adipiscing elit</a></h2>
                                                                </div>
                                                                <div class="vk-fashion-sec-2-left-time">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                        <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                        <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="vk-item">
                                                        <div class="vk-home-sport-left-img">
                                                            <div class="item-img5">
                                                                <!--                                                                <a href=""><img src="image/01_04_techology/sec-3/img.jpg" alt="" class="img-responsive"></a>-->
                                                            </div>
                                                            <div class="vk-home-sport-left-caption">
                                                                <div class="vk-item-caption-top">
                                                                    <a href="#">Car</a>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                                <div class="vk-item-caption-text">
                                                                    <h2><a href="#">Lorem ipsum dolor sit amet, consect adipiscing elit</a></h2>
                                                                </div>
                                                                <div class="vk-fashion-sec-2-left-time">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                        <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                        <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="clearfix"></div>

                                            <div class="vk-home-tech-sec-4">
                                                <div class="uni-sticker-label">
                                                    <div class="label-info">
                                                        <a href="#">
                                                            <img src="image/homepage1/icon/fire.png" alt="" class="img-responsive img-gen">
                                                            <img src="image/fire-red.png" alt="" class="img-responsive img-hover">
                                                            <span class="label-title">Latest News</span>
                                                        </a>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="vk-fashion-sec-2-item">
                                                            <div class="vk-fashion-sec-2-left-img">
                                                                <a href="#"><img src="image/01_04_techology/sec-4/img-9.jpg" alt="" class="img-responsive"></a>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-content">
                                                                <h2><a href="#">Pellentesque habitant morbi tristique senectus
                                                                    et netus et malesuada fames ac turpis egestas</a></h2>
                                                                <div class="vk-fashion-sec-2-left-time">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                        <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                        <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="vk-fashion-sec-2-left-text">
                                                                    <p>
                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-btn">
                                                                <a href="#"> Read more <i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="vk-fashion-sec-2-item">
                                                            <div class="vk-fashion-sec-2-left-img">
                                                                <a href="#"><img src="image/01_04_techology/sec-4/img-8.jpg" alt="" class="img-responsive"></a>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-content">
                                                                <h2><a href="#">Pellentesque habitant morbi tristique senectus
                                                                    et netus et malesuada fames ac turpis egestas</a></h2>
                                                                <div class="vk-fashion-sec-2-left-time">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                        <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                        <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="vk-fashion-sec-2-left-text">
                                                                    <p>
                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-btn">
                                                                <a href="#"> Read more <i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="vk-fashion-sec-2-item">
                                                            <div class="vk-fashion-sec-2-left-img">
                                                                <a href="#"><img src="image/01_04_techology/sec-4/img-7.jpg" alt="" class="img-responsive"></a>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-content">
                                                                <h2><a href="#">Pellentesque habitant morbi tristique senectus
                                                                    et netus et malesuada fames ac turpis egestas</a></h2>
                                                                <div class="vk-fashion-sec-2-left-time">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                        <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                        <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="vk-fashion-sec-2-left-text">
                                                                    <p>
                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-btn">
                                                                <a href="#"> Read more <i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="vk-fashion-sec-2-item">
                                                            <div class="vk-fashion-sec-2-left-img">
                                                                <a href="#"><img src="image/01_04_techology/sec-4/img-6.jpg" alt="" class="img-responsive"></a>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-content">
                                                                <h2><a href="#">Pellentesque habitant morbi tristique senectus
                                                                    et netus et malesuada fames ac turpis egestas</a></h2>
                                                                <div class="vk-fashion-sec-2-left-time">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                        <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                        <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="vk-fashion-sec-2-left-text">
                                                                    <p>
                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-btn">
                                                                <a href="#"> Read more <i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="vk-fashion-sec-2-item">
                                                            <div class="vk-fashion-sec-2-left-img">
                                                                <a href="#"><img src="image/01_04_techology/sec-4/img-5.jpg" alt="" class="img-responsive"></a>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-content">
                                                                <h2><a href="#">Pellentesque habitant morbi tristique senectus
                                                                    et netus et malesuada fames ac turpis egestas</a></h2>
                                                                <div class="vk-fashion-sec-2-left-time">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                        <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                        <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="vk-fashion-sec-2-left-text">
                                                                    <p>
                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-btn">
                                                                <a href="#"> Read more <i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="vk-fashion-sec-2-item">
                                                            <div class="vk-fashion-sec-2-left-img">
                                                                <a href="#"><img src="image/01_04_techology/sec-4/img-4.jpg" alt="" class="img-responsive"></a>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-content">
                                                                <h2><a href="#">Pellentesque habitant morbi tristique senectus
                                                                    et netus et malesuada fames ac turpis egestas</a></h2>
                                                                <div class="vk-fashion-sec-2-left-time">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                        <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                        <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="vk-fashion-sec-2-left-text">
                                                                    <p>
                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-btn">
                                                                <a href="#"> Read more <i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="vk-fashion-sec-2-item">
                                                            <div class="vk-fashion-sec-2-left-img">
                                                                <a href="#"><img src="image/01_04_techology/sec-4/img-3.jpg" alt="" class="img-responsive"></a>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-content">
                                                                <h2><a href="#">Pellentesque habitant morbi tristique senectus
                                                                    et netus et malesuada fames ac turpis egestas</a></h2>
                                                                <div class="vk-fashion-sec-2-left-time">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                        <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                        <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="vk-fashion-sec-2-left-text">
                                                                    <p>
                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-btn">
                                                                <a href="#"> Read more <i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="vk-fashion-sec-2-item">
                                                            <div class="vk-fashion-sec-2-left-img">
                                                                <a href="#"><img src="image/01_04_techology/sec-4/img-2.jpg" alt="" class="img-responsive"></a>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-content">
                                                                <h2><a href="#">Pellentesque habitant morbi tristique senectus
                                                                    et netus et malesuada fames ac turpis egestas</a></h2>
                                                                <div class="vk-fashion-sec-2-left-time">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                        <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                        <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="vk-fashion-sec-2-left-text">
                                                                    <p>
                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-btn">
                                                                <a href="#"> Read more <i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="vk-fashion-sec-2-item">
                                                            <div class="vk-fashion-sec-2-left-img">
                                                                <a href="#"><img src="image/01_04_techology/sec-4/img-1.jpg" alt="" class="img-responsive"></a>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-content">
                                                                <h2><a href="#">Pellentesque habitant morbi tristique senectus
                                                                    et netus et malesuada fames ac turpis egestas</a></h2>
                                                                <div class="vk-fashion-sec-2-left-time">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                        <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                        <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="vk-fashion-sec-2-left-text">
                                                                    <p>
                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-btn">
                                                                <a href="#"> Read more <i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="vk-fashion-sec-2-item">
                                                            <div class="vk-fashion-sec-2-left-img">
                                                                <a href="#"><img src="image/01_04_techology/sec-4/img.jpg" alt="" class="img-responsive"></a>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-content">
                                                                <h2><a href="#">Pellentesque habitant morbi tristique senectus
                                                                    et netus et malesuada fames ac turpis egestas</a></h2>
                                                                <div class="vk-fashion-sec-2-left-time">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</a></li>
                                                                        <li><a href="#"> <i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</a></li>
                                                                        <li><a href="#"> <i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</a></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="vk-fashion-sec-2-left-text">
                                                                    <p>
                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="vk-fashion-sec-2-left-btn">
                                                                <a href="#"> Read more <i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                            <ul class="loop-pagination">
                                                <li class="current"><a class="page-numbers">1</a></li>
                                                <li><a class="page-numbers" href="#">2</a></li>
                                                <li><a class="page-numbers" href="#">3</a></li>
                                                <li><a class="page-numbers" href="#">...</a></li>
                                                <li><a class="page-numbers" href="#">9</a></li>
                                                <li><a class="next page-numbers" href="#"><i class="fa fa-angle-right"></i></a></li>
                                            </ul>

                                        </div>
                                    </div>
									
									<div class="cointainer">
										<?php
											foreach($posts as $post){
												$postImg = $post->main_image;
												$postImg = str_replace("{img_path('","{$b}assets/images/",$postImg);
												$postImg = str_replace("')}","",$postImg);
												$postImg = str_replace('alt=""',"alt='{$post->title}' class='img img-responsive'",$postImg);
												
												$publishDate = strtotime($post->publish_date,time());
												$publishDateFormat = strftime("%Y/%m/%d",$publishDate);
												$publishDateFormat2 = date("l jS \of F Y h:i:s A",$publishDate);
												
												$category = $this->ApplicationModel->getCategoryById($post->category_id);
										?>
										
											<div class="col-md-6 home-post">
												<?php echo($postImg); ?>
												<br>
												<p class="text-muted"><i class="glyphicon glyphicon-bell"> </i><?php echo($category->name); ?></p>
												<h2 style="">
													<a href="<?php echo(base_url() . "blog/{$publishDateFormat}/{$post->slug}"); ?>" >
														<?php echo($post->title); ?> 
													</a>
												</h2>	
											</div>
										<?php
											}	
										?>
									<div class="clearfix"></div>
									</div>
									<br><hr><br>

								</div>
							</div>
							<aside class="col-md-4">
								<aside class="widget-area">

									<aside class="widget">
										<div class="widget-content">
											<div class="vk-home-default-right-ad">
												<?php echo $this->fuel->blocks->render('side_advert'); ?>
											</div>
										</div>
									</aside>

									<aside class="widget">
										<h3 class="widget-title">Editor Picks</h3>
										<div class="widget-content">
											<div class="vk-home-default-right-ep">
												<div id="vk-owl-ep-slider" class="owl-carousel owl-theme">
													<div class="item">
														<ul>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img.jpg" alt="img"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img-1.jpg" alt="img-1"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img-2.jpg" alt="img-2"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img-3.jpg" alt="img-3"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img-4.jpg" alt="img-4"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
														</ul>
													</div>
													<div class="item">
														<ul>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img.jpg" alt="img"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img-1.jpg" alt="img-1"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img-2.jpg" alt="img-2"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img-3.jpg" alt="img-3"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img-4.jpg" alt="img-4"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
														</ul>
													</div>
													<div class="item">
														<ul>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img.jpg" alt="img"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img-1.jpg" alt="img-1"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img-2.jpg" alt="img-2"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img-3.jpg" alt="img-3"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
															<li>
																<div class="vk-item-ep">
																	<div class="vk-item-ep-img">
																		<a href="#"><img src="image/siderbar/img-4.jpg" alt="ìm-4"></a>
																	</div>
																	<div class="vk-item-ep-text">
																		<h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
																		<div class="vk-item-ep-time">
																			<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
																		</div>
																	</div>
																</div>
																<div class="clearfix"></div>
															</li>
														</ul>
													</div>
												</div>
											</div>
										</div>
									</aside>

									<aside class="widget">
										<div class="widget-content">
											<div class="vk-home-default-right-facebook">
												<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ffacebook&amp;tabs=timeline&amp;width=340&amp;height=500&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId" width="340" height="500" style="border:none;overflow:hidden"></iframe>
											</div>
										</div>
									</aside>

									<aside class="widget">
										<h3 class="widget-title">Feature Videos</h3>
										<div class="widget-content">
											<div class="vk-home-default-right-fea">
												<div id="vk-owl-fea-slider" class="owl-carousel owl-theme">
													<div class="item">
														<ul>
															<li>
																<div class="vk-item-fea">
																	 <?php echo $this->fuel->blocks->render('featured_video_1'); ?>
																</div>
																<div class="clearfix"></div>
															</li>
															</ul>
													</div>
													<div class="item">
														<ul>
															<li>
																<div class="vk-item-fea">
																	<?php echo $this->fuel->blocks->render('featured_video_2'); ?>
																</div>
																<div class="clearfix"></div>
															</li>
														</ul>
													</div>
													<div class="item">
														<ul>
															<li>
																<div class="vk-item-fea">
																	<?php echo $this->fuel->blocks->render('featured_video_3'); ?>
																</div>
																<div class="clearfix"></div>
															</li>
														</ul>
													</div>
												</div>
											</div>
										</div>
									</aside>

									<aside class="widget">
										<h3 class="widget-title">Stay Connected</h3>
										<div class="widget-content">
											<div class="vk-home-default-right-stay">
												<div class="vk-right-stay-body">
													<a class="btn btn-block btn-social btn-facebook">
														<span class="icon"><i class="fa fa-facebook"></i></span>
														<span class="info"> 2134 Like</span>
														<span class="text">Like</span>
													</a>
													<a class="btn btn-block btn-social btn-twitter">
														<span class="icon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
														<span class="info"> 13634 Follows</span>
														<span class="text">Follows</span>
													</a>
													<a class="btn btn-block btn-social btn-youtube">
														<span class="icon"><i class="fa fa-youtube-play" aria-hidden="true"></i></span>
														<span class="info">10634 Subscribers</span>
														<span class="text">Subscribe</span>
													</a>
												</div>
											</div>
										</div>
									</aside>

									<aside class="widget">
										<div class="widget-content">
											<div class="vk-home-default-right-ad">
												<a href="#">
													<img src="image/ad-sidebar.jpg" alt="ad-sidebar" class="img-responsive">
												</a>
											</div>
										</div>
									</aside>

									<aside class="widget">
										<h3 class="widget-title">News Tags</h3>
										<div class="widget-content">
											<div class="vk-home-default-right-tags">
												 <ul>
													<?php  
														$postCategories = $this->ApplicationModel->getBlogCategories();
														foreach($postCategories as $category){
															echo("<li><a href='". base_url() . "blog/categories/{$category->slug}" ."'>$category->name</a></li>");
														}
													?>
                                                </ul>
											</div>
										</div>
									</aside>

								</aside>
							</aside>
						</div>
					</div>
				</div>
			</div>
		</div>
