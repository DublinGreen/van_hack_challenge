<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <?php echo meta($meta); ?>
        <!-- Latest compiled and minified CSS -->
        
        <link rel="stylesheet" href="<?php echo base_url() . "public_assets/"; ?>dist/assets/owl.carousel.min.css">
        <link rel="stylesheet" href="<?php echo base_url() . "public_assets/"; ?>dist/assets/owl.theme.default.min.css">
        <link rel="stylesheet" href="<?php echo base_url() . "public_assets/"; ?>css/bootstrap.min.css">

        <!-- Optional theme -->
        <link rel="stylesheet" href="<?php echo base_url() . "public_assets/"; ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" id="themify-icons-css" href="<?php echo base_url() . "public_assets/"; ?>css/themify-icons.css" type="text/css" media="all">
        <link rel="stylesheet" href="<?php echo base_url() . "public_assets/"; ?>css/style.css">
        <link rel="stylesheet" href="<?php echo base_url() . "public_assets/"; ?>css/jquery-ui.min.css">
        <link rel="stylesheet" href="<?php echo base_url() . "public_assets/"; ?>css/fonts.css">
        <link rel="stylesheet" href="<?php echo base_url() . "public_assets/"; ?>css/font-awesome.min.css">
        <link rel="shortcut icon" href="<?php echo base_url() . "public_assets/"; ?>favicon.png">
        <title><?php echo($title); ?></title>
        <link href='http://fonts.googleapis.com/css?family=Raleway:400,700' rel='stylesheet' type='text/css'>
        
        
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script src="<?php echo base_url() . "public_assets/"; ?>RGraph/libraries/RGraph.common.core.js"></script>
        <script src="<?php echo base_url() . "public_assets/"; ?>RGraph/libraries/RGraph.common.key.js"></script>
        <script src="<?php echo base_url() . "public_assets/"; ?>RGraph/libraries/RGraph.hbar.js"></script>        
        <script src="<?php echo base_url() . "public_assets/"; ?>RGraph/libraries/RGraph.pie.js"></script>
        <script src="<?php echo base_url() . "public_assets/"; ?>RGraph/libraries/RGraph.common.dynamic.js"></script>
        <script src="<?php echo base_url() . "public_assets/"; ?>RGraph/libraries/RGraph.common.tooltips.js"></script>
        <script src="<?php echo base_url() . "public_assets/"; ?>RGraph/libraries/RGraph.rose.js"></script>
        <script src="<?php echo base_url() . "public_assets/"; ?>RGraph/libraries/RGraph.svg.bar.js"></script>
        <script src="<?php echo base_url() . "public_assets/"; ?>RGraph/libraries/RGraph.bar.js"></script>
        
        <style>
			.home-post{
				height: 360px;margin-bottom: 20px;
			}
			
			.home-post h2{
				height: 50px;overflow: auto;font-size: 1.5em;color: #777777;
			}
			
			.home-post a{
				color: #777777;
			}
			
			.home-post-text h2{
				overflow: auto;font-size: 1.5em;color: #777777;
			}
			
			.home-post-text a{
				color: #777777;
			}
			
			.category a{
				font-family: 'Poppins', sans-serif;
				font-size: 12px;
				line-height: 1.67;
				text-align: center;
				color: #ffffff;
				border: 1px solid #e12222;
				border-radius: 3px;
				background: #e12222;
				padding: 3px 10px;
				-webkit-transition: all 0.5s;
				-o-transition: all 0.5s;
				transition: all 0.5s;
				text-transform: uppercase;
			}
			
			.category a:hover {
				background: transparent;
				color: #e12222;
				text-decoration: none;
				-webkit-transition: all 0.5s;
				-o-transition: all 0.5s;
				transition: all 0.5s;
			}
			
			.post-image{
				width: 830px;
				height: 460px;
			}
			
			.comments{
				background-color: #E10000;
				border-radius: 25px 0px 25px 0px;
				color: #eee;
				padding: 1.4%;
			}
			
			.comment_content{
				font-size: 1.8em;
			}
				
        </style>
    </head>
