		<div id="main-content" class="site-main-content">
			<div id="home-main-content" class="site-home-main-content">
				<div id="vk-home-default-slide">
					<div class="container-fluid">
						<div class="row">
							<!--HOME 1 SLIDE-->
							<div id="uni-home-defaults-slide">
								<div id="vk-owl-demo-singer-slider" class="owl-carousel owl-theme">		
										<?php
										//Get 5 post and display post information as sliders
											$posts = $this->ApplicationModel->getBlogPost();
											foreach($posts as $post){
												static $counter  = 0;
												if($counter <= 6){
													if(!empty($post->main_image)){
														$b = base_url();
														$postImg = $post->main_image;
														$postImg = str_replace("{img_path('","{$b}assets/images/",$postImg);
														$postImg = str_replace("')}","",$postImg);
														$postImg = str_replace('alt=""',"alt='{$post->title}' class='img img-responsive post-image'",$postImg);
														$category = $this->ApplicationModel->getCategoryById($post->category_id);
														
														$publishDate = strtotime($post->publish_date,time());
														$publishDateFormat = strftime("%Y/%m/%d",$publishDate);
														$publishDateFormat2 = date("l jS \of F Y",$publishDate);
											?>		
													<div class="item"><!-- ITEM START-->
														<div class="container-fluid">
															<?php echo($postImg); ?>
														</div>
														<div class="vk-item-caption">
															<div class="vk-item-caption-top">
																<ul>
																	<li><a href="<?php echo(base_url() . "blog/categories/" . $category->slug); ?>"><?php echo( strtoupper($category->name) ); ?></a></li>
																</ul>
																<div class="clearfix"></div>
															</div>
															<div class="vk-item-caption-text">
																<h2><a href="<?php echo(base_url() . "blog/{$publishDateFormat}/{$post->slug}"); ?>"><?php echo($post->title); ?></a></h2>
															</div>
															<div class="vk-item-caption-time">
																<span class="time"> <?php echo($publishDateFormat2); ?></span>
															</div>
														</div>
													</div><!-- ITEM STOP-->
											<?php		
													}
												}
												$counter++;
											}
										?>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div id="vk-home-default-body">
					<div class="container">
						<div class="row">
							<div class="col-md-8">
								<div class="uni-sticker-label">
									<div class="label-info">
										<a href="<?php echo(base_url() . "blog"); ?>">
											<img src="<?php echo(base_url() . "public_assets/"); ?>image/homepage1/icon/fire.png" alt="" class="img-responsive img-gen">
											<img src="<?php echo(base_url() . "public_assets/"); ?>image/fire-red.png" alt="" class="img-responsive img-hover">
											<span class="label-title">News</span>
										</a>
									</div>
								</div>
								<div id="vk-home-default-left">
									<!--HOME DEFAULT HOT NEWS-->		
									<div class="cointainer">
										<?php
										//Get post that have images 
											foreach($posts as $post){
												if(!empty($post->main_image)){
													$postImg = $post->main_image;
													$postImg = str_replace("{img_path('","{$b}assets/images/",$postImg);
													$postImg = str_replace("')}","",$postImg);
													$postImg = str_replace('alt=""',"alt='{$post->title}' class='img img-responsive'",$postImg);
													
													$publishDate = strtotime($post->publish_date,time());
													$publishDateFormat = strftime("%Y/%m/%d",$publishDate);
													//$publishDateFormat2 = date("l jS \of F Y h:i:s A",$publishDate);
													$publishDateFormat2 = date("l jS \of F Y",$publishDate);
													
													$category = $this->ApplicationModel->getCategoryById($post->category_id);
										?>
										
												<div class="col-md-6 home-post">
													<?php echo($postImg); ?>
													<br>
													<div class="category">
														<a href="<?php echo(base_url() . "blog/categories/" . $category->slug); ?>"><?php echo($category->name); ?></a>
													</div><br>
													<h2 style="">
														<a href="<?php echo(base_url() . "blog/{$publishDateFormat}/{$post->slug}"); ?>" >
															<?php echo($post->title); ?> 
														</a>
													</h2>
													<!--<a href="<?php echo(base_url() . "blog/{$publishDateFormat}/{$post->slug}"); ?>"> Read more <i class="fa fa-chevron-right" aria-hidden="true"></i></a>-->
													<div class="time">
														<a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> <span class="text-muted"><?php echo($publishDateFormat2); ?></span></a>
													</div>
												</div>
										<?php
												}
											}	
										?>
									<div class="clearfix"></div>
									</div>
									<br>

									<div class="cointainer">
										<div class="uni-sticker-label">
											<div class="label-info">
												<a href="<?php echo(base_url() . "blog"); ?>">
													<img src="<?php echo(base_url() . "public_assets/"); ?>image/homepage1/icon/fire.png" alt="" class="img-responsive img-gen">
													<img src="<?php echo(base_url() . "public_assets/"); ?>image/fire-red.png" alt="" class="img-responsive img-hover">
													<span class="label-title">News</span>
												</a>
											</div>
										</div>
										<?php
										//Get post that don't have images 
											foreach($posts as $post){
												if(empty($post->main_image)){
													$publishDate = strtotime($post->publish_date,time());
													$publishDateFormat = strftime("%Y/%m/%d",$publishDate);
													//$publishDateFormat2 = date("l jS \of F Y h:i:s A",$publishDate);
													$publishDateFormat2 = date("l jS \of F Y",$publishDate);
													
													$category = $this->ApplicationModel->getCategoryById($post->category_id);
										?>
										
												<div class="col-md-12 home-post-text"><br>
													<h2 style="">
														<a href="<?php echo(base_url() . "blog/{$publishDateFormat}/{$post->slug}"); ?>" >
															<?php echo($post->excerpt); ?> 
														</a>
													</h2><br>
													<div class="category">
														<a href="<?php echo(base_url() . "blog/categories/" . $category->slug); ?>"><?php echo($category->name); ?></a>
													</div><br>
													<!--<a href="<?php echo(base_url() . "blog/{$publishDateFormat}/{$post->slug}"); ?>"> Read more <i class="fa fa-chevron-right" aria-hidden="true"></i></a>-->
													<div class="time">
														<a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> <span class="text-muted"><?php echo($publishDateFormat2); ?></span></a>
													</div>
													<br><hr><br>
												</div>
										<?php
												}
											}	
										?>
									<div class="clearfix"></div>
									</div>

								</div>
							</div>
							<aside class="col-md-4">
								<aside class="widget-area">

									<aside class="widget">
										<div class="widget-content">
											<div class="vk-home-default-right-ad">
												<?php echo $this->fuel->blocks->render('side_advert'); ?>
											</div>
										</div>
									</aside>

									<aside class="widget">
										<h3 class="widget-title">Editor Picks</h3>
										<div class="widget-content">
											<div class="vk-home-default-right-ep">
												<div id="vk-owl-ep-slider" class="owl-carousel owl-theme">
													<div class="item">
														<ul>
															<?php
															//Post category pick by me for display on the side pane
																foreach($posts as $post){
																	$category = $this->ApplicationModel->getCategoryById($post->category_id);
																	if(!empty($post->main_image) && ($category->slug == "politics" ||  $category->slug ==  "crime") ){																		
																		
																		$b = base_url();
																		$postImg = $post->main_image;
																		$postImg = str_replace("{img_path('","{$b}assets/images/",$postImg);
																		$postImg = str_replace("')}","",$postImg);
																		$postImg = str_replace('alt=""',"alt='{$post->title}' class='img img-responsive'",$postImg);
																		$category = $this->ApplicationModel->getCategoryById($post->category_id);
																		
																		$publishDate = strtotime($post->publish_date,time());
																		$publishDateFormat = strftime("%Y/%m/%d",$publishDate);
																		$publishDateFormat2 = date("l jS \of F Y",$publishDate);
															?>
																	<li>
																		<div class="vk-item-ep">
																			<div class="vk-item-ep-img">
																				<?php echo($postImg); ?>
																			</div>
																			<div class="vk-item-ep-text">
																				<h2><a href="<?php echo(base_url() . "blog/{$publishDateFormat}/{$post->slug}"); ?>"><?php echo($post->title); ?> </a></h2>
																				<div class="vk-item-ep-time">
																					<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo($publishDateFormat2); ?></div>
																				</div>
																			</div>
																		</div>
																		<div class="clearfix"></div>
																	</li>
															<?php
																	}
																}	
															?>
														</ul>
													</div>
													<div class="item">
														<ul>
															<?php
																foreach($posts as $post){
																	$category = $this->ApplicationModel->getCategoryById($post->category_id);
																	if(!empty($post->main_image) && ($category->slug == "hot-news" ||  $category->slug ==  "editor-pick") ){																		
																		
																		$b = base_url();
																		$postImg = $post->main_image;
																		$postImg = str_replace("{img_path('","{$b}assets/images/",$postImg);
																		$postImg = str_replace("')}","",$postImg);
																		$postImg = str_replace('alt=""',"alt='{$post->title}' class='img img-responsive'",$postImg);
																		$category = $this->ApplicationModel->getCategoryById($post->category_id);
																		
																		$publishDate = strtotime($post->publish_date,time());
																		$publishDateFormat = strftime("%Y/%m/%d",$publishDate);
																		$publishDateFormat2 = date("l jS \of F Y",$publishDate);
															?>
																	<li>
																		<div class="vk-item-ep">
																			<div class="vk-item-ep-img">
																				<?php echo($postImg); ?>
																			</div>
																			<div class="vk-item-ep-text">
																				<h2><a href="<?php echo(base_url() . "blog/{$publishDateFormat}/{$post->slug}"); ?>"><?php echo($post->title); ?> </a></h2>
																				<div class="vk-item-ep-time">
																					<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo($publishDateFormat2); ?></div>
																				</div>
																			</div>
																		</div>
																		<div class="clearfix"></div>
																	</li>
															<?php
																	}
																}	
															?>
														</ul>
													</div>
													<div class="item">
														<ul>
															<?php
																foreach($posts as $post){
																	$category = $this->ApplicationModel->getCategoryById($post->category_id);
																	if(!empty($post->main_image) && ($category->slug == "foreign" ||  $category->slug ==  "social") ){																		
																		
																		$b = base_url();
																		$postImg = $post->main_image;
																		$postImg = str_replace("{img_path('","{$b}assets/images/",$postImg);
																		$postImg = str_replace("')}","",$postImg);
																		$postImg = str_replace('alt=""',"alt='{$post->title}' class='img img-responsive'",$postImg);
																		$category = $this->ApplicationModel->getCategoryById($post->category_id);
																		
																		$publishDate = strtotime($post->publish_date,time());
																		$publishDateFormat = strftime("%Y/%m/%d",$publishDate);
																		$publishDateFormat2 = date("l jS \of F Y",$publishDate);
															?>
																	<li>
																		<div class="vk-item-ep">
																			<div class="vk-item-ep-img">
																				<?php echo($postImg); ?>
																			</div>
																			<div class="vk-item-ep-text">
																				<h2><a href="<?php echo(base_url() . "blog/{$publishDateFormat}/{$post->slug}"); ?>"><?php echo($post->title); ?> </a></h2>
																				<div class="vk-item-ep-time">
																					<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo($publishDateFormat2); ?></div>
																				</div>
																			</div>
																		</div>
																		<div class="clearfix"></div>
																	</li>
															<?php
																	}
																}	
															?>
														</ul>
													</div>
												</div>
											</div>
										</div>
									</aside>

									<aside class="widget">
										social widget
										<div class="widget-content">
											<div class="vk-home-default-right-facebook">
												<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ffacebook&amp;tabs=timeline&amp;width=340&amp;height=500&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId" width="340" height="500" style="border:none;overflow:hidden"></iframe>
											</div>
										</div>
									</aside>

									<aside class="widget">
										<h3 class="widget-title">Feature Videos</h3>
										<div class="widget-content">
											<div class="vk-home-default-right-fea">
												<div id="vk-owl-fea-slider" class="owl-carousel owl-theme">
													<div class="item">
														<ul>
															<li>
																<div class="vk-item-fea">
																	 <?php echo $this->fuel->blocks->render('featured_video_1'); ?>
																</div>
																<div class="clearfix"></div>
															</li>
															</ul>
													</div>
													<div class="item">
														<ul>
															<li>
																<div class="vk-item-fea">
																	<?php echo $this->fuel->blocks->render('featured_video_2'); ?>
																</div>
																<div class="clearfix"></div>
															</li>
														</ul>
													</div>
													<div class="item">
														<ul>
															<li>
																<div class="vk-item-fea">
																	<?php echo $this->fuel->blocks->render('featured_video_3'); ?>
																</div>
																<div class="clearfix"></div>
															</li>
														</ul>
													</div>
												</div>
											</div>
										</div>
									</aside>

									<aside class="widget">
										<h3 class="widget-title">Stay Connected</h3>
										<div class="widget-content">
											<div class="vk-home-default-right-stay">
												<div class="vk-right-stay-body">
													<a class="btn btn-block btn-social btn-facebook">
														<span class="icon"><i class="fa fa-facebook"></i></span>
														<span class="info"> 2134 Like</span>
														<span class="text">Like</span>
													</a>
													<a class="btn btn-block btn-social btn-twitter">
														<span class="icon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
														<span class="info"> 13634 Follows</span>
														<span class="text">Follows</span>
													</a>
													<a class="btn btn-block btn-social btn-youtube">
														<span class="icon"><i class="fa fa-youtube-play" aria-hidden="true"></i></span>
														<span class="info">10634 Subscribers</span>
														<span class="text">Subscribe</span>
													</a>
												</div>
											</div>
										</div>
									</aside>

									<aside class="widget">
										<div class="widget-content">
											<div class="vk-home-default-right-ad">
												<?php echo $this->fuel->blocks->render('side_advert2'); ?>
											</div>
										</div>
									</aside>

									<aside class="widget">
										<h3 class="widget-title">News Tags</h3>
										<div class="widget-content">
											<div class="vk-home-default-right-tags">
												 <ul>
													<?php  
														// All post categories
														$postCategories = $this->ApplicationModel->getBlogCategories();
														foreach($postCategories as $category){
															echo("<li><a href='". base_url() . "blog/categories/{$category->slug}" ."'>$category->name</a></li>");
														}
													?>
                                                </ul>
											</div>
										</div>
									</aside>

								</aside>
							</aside>
						</div>
					</div>
				</div>
			</div>
		</div>
