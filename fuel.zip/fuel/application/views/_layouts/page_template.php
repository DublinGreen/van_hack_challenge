<?php $this->load->view('_blocks/template_blocks/header') ?>
<?php $this->load->view('_blocks/template_blocks/nav') ?>
        
        <div id="main-content" class="site-main-content">
        <div id="home-main-content" class="site-home-main-content">

            <div class="uni-about">
                <div id="vk-home-default-slide">
                    <div class="container-fluid">
                        <div class="row">
                            <div id="uni-home-defaults-slide">
                                <div id="vk-owl-demo-singer-slider" class="owl-carousel owl-theme owl-loaded owl-drag">
                                    
                                    
                                    
                                <div class="owl-stage-outer"><div class="owl-stage" style="transition: 0s; width: 4764px; transform: translate3d(-1020px, 0px, 0px);"><div class="owl-item cloned" style="width: 670.5px; margin-right: 10px;"><div class="item">
                                        <div class="uni-item-img-2"></div>
                                        <!--                        <img src="image/slideshow/right.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">SPORT</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <div class="time"> June 21, 2017</div>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item cloned" style="width: 670.5px; margin-right: 10px;"><div class="item">
                                        <div class="uni-item-img-3"></div>
                                        <!--                        <img src="image/slideshow/left.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">TRAVEL</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <div class="time"> June 21, 2017</div>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item active center" style="width: 670.5px; margin-right: 10px;"><div class="item">
                                        <div class="uni-item-img-1"></div>
                                        <!--                        <img src="image/slideshow/center.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">LIFESTYLE</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <div class="time"> June 21, 2017</div>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item active" style="width: 670.5px; margin-right: 10px;"><div class="item">
                                        <div class="uni-item-img-2"></div>
                                        <!--                        <img src="image/slideshow/right.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">SPORT</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <div class="time"> June 21, 2017</div>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item" style="width: 670.5px; margin-right: 10px;"><div class="item">
                                        <div class="uni-item-img-3"></div>
                                        <!--                        <img src="image/slideshow/left.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">TRAVEL</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <div class="time"> June 21, 2017</div>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item cloned" style="width: 670.5px; margin-right: 10px;"><div class="item">
                                        <div class="uni-item-img-1"></div>
                                        <!--                        <img src="image/slideshow/center.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">LIFESTYLE</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <div class="time"> June 21, 2017</div>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item cloned" style="width: 670.5px; margin-right: 10px;"><div class="item">
                                        <div class="uni-item-img-2"></div>
                                        <!--                        <img src="image/slideshow/right.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">SPORT</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <div class="time"> June 21, 2017</div>
                                            </div>
                                        </div>
                                    </div></div></div></div><div class="owl-nav disabled"><div class="owl-prev"></div><div class="owl-next"></div></div><div class="owl-dots disabled"></div></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="uni-about-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="breadcrumb breadcrumb-search">
                                    <a href="#">Home</a>
                                    <a href="#" class="active">about</a>
                                </div>

                                <div class="uni-about-content">
                                    <h2><?php echo fuel_var('heading', 'This is a default layout. To change this layout go to the fuel/application/views/_layouts/main.php file.'); ?></h2>
                                    <div class="description">
										<?php echo fuel_var('body', 'This is a default layout. To change this layout go to the fuel/application/views/_layouts/main.php file.'); ?>
                                    </div>

                                    <!-- CONTACT INFORMATION-->
                                    <div class="uni-about-contact-info">
                                        <h2>Contact Infomation</h2>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="uni-about-contact-info-left">
                                                    <ul>
                                                        <li>
                                                            <h4><i class="fa fa-home" aria-hidden="true"></i> Office Address</h4>
                                                            <p>45 Queen's Park Rd, Brighton, BN2 0GJ, United Kingdom</p>
                                                        </li>
                                                        <li>
                                                            <h4><i class="fa fa-envelope" aria-hidden="true"></i> Office Address</h4>
                                                            <p>maxnews@domain.com</p>
                                                            <p>suppost@domain.com</p>
                                                        </li>
                                                        <li>
                                                            <h4><i class="fa fa-phone" aria-hidden="true"></i> Tel</h4>
                                                            <p>(+233) 123 456789</p>
                                                            <p>(+233) 123 458952</p>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="uni-about-contact-info-right">
                                                    <div class="uni-about-contact-map">
                                                        <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2520.3558605259554!2d-0.1305261839151272!3d50.824572079528714!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4875859878db2cc7%3A0xff129250121f260d!2s45+Queen's+Park+Rd%2C+Brighton+BN2+0GJ%2C+UK!5e0!3m2!1sen!2s!4v1505207016897" allowfullscreen=""></iframe>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <aside class="widget-area">

                                    <aside class="widget">
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-ad">
                                                <a href="#">
                                                    <img src="image/ad-sidebar.jpg" alt="ad-sidebar" class="img-responsive">
                                                </a>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-facebook">
                                                <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ffacebook&amp;tabs=timeline&amp;width=340&amp;height=500&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId" width="340" height="500" style="border:none;overflow:hidden"></iframe>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <h3 class="widget-title">Stay Connected</h3>
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-stay">
                                                <div class="vk-right-stay-body">
                                                    <a class="btn btn-block btn-social btn-facebook">
                                                        <span class="icon"><i class="fa fa-facebook"></i></span>
                                                        <span class="info"> 2134 Like</span>
                                                        <span class="text">Like</span>
                                                    </a>
                                                    <a class="btn btn-block btn-social btn-twitter">
                                                        <span class="icon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                                                        <span class="info"> 13634 Follows</span>
                                                        <span class="text">Follows</span>
                                                    </a>
                                                    <a class="btn btn-block btn-social btn-youtube">
                                                        <span class="icon"><i class="fa fa-youtube-play" aria-hidden="true"></i></span>
                                                        <span class="info">10634 Subscribers</span>
                                                        <span class="text">Subscribe</span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <h3 class="widget-title">Tags Clound</h3>
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-tags">
                                                <ul>
                                                    <li><a href="#">LifeStyle</a></li>
                                                    <li><a href="#">Sport</a></li>
                                                    <li><a href="#">Economy</a></li>
                                                    <li><a href="#">Business</a></li>
                                                    <li><a href="#">Travel</a></li>
                                                    <li><a href="#">Techology</a></li>
                                                    <li><a href="#">Movies</a></li>
                                                    <li><a href="#">Fashion</a></li>
                                                    <li><a href="#">video</a></li>
                                                    <li><a href="#">Music</a></li>
                                                    <li><a href="#">Photography</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </aside>

                                </aside>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>

        </div>
    </div>
<?php $this->load->view('_blocks/template_blocks/footer') ?>
