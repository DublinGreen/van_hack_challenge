<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('kfnjvmvhf.jpg');?>" alt="2019: We&rsquo;ve options other than Buhari, Nigerians reply El-Rufai" class="img img-responsive" /><br />
LAGOS&mdash;STRONG denunciations of the claim by Governor Nasir El-Rufai that Nigeria has no better option to President Muhammadu Buhari swept across the country yesterday, with leading Nigerians in civil society and opposition political parties strongly disagreeing with the Kaduna governor.<br />
Governor El-Rufai had in a Sunday television programme aired on Channels Television, affirmed that Buhari remained invincible and was best positioned to advance the interest of Nigeria. </p>

<p>Among those who reacted yesterday were former president of Civil Liberties Organisation, CLO, Chief Olisa Agbakoba, former governor of Anambra State, Dr. Chukwuemeka Ezeife, chairman of the Inter-Party Advisory Council, IPAC, Dr. Tanko Yakassai, elder-statesman Chief Ayo Adebanjo, former Senator Femi Okurunmu, Afenifere spokesman, Mr. Yinka Odumakin, Director of New Media in the National Intervention Movement, NIM, Mr. Kayode Salako, national chairman of Unity Party of Nigeria, UPN, Professor Bankole Okuwa, the Eastern Consultative Assembly and the national chairman of the Green Party of Nigeria, GPN, Dr Sam Eke also responded to the issue. </p>

<p>The assertions against Governor El-Rufai nonetheless, a coalition claiming to represent 200 Non Governmental Organisations, NGOs yesterday conveyed their adoption of Buhari in the 2019 election.</p>

<p>Responding to the issue of Buhari&rsquo;s electoral superiority, former Governor Ezeife said: &ldquo;Is Governor El-Rufai being honest? Is he not eyeing the Presidency? What does the continuation of Buhari&rsquo;s Presidency translates to for the average Nigerian?&rdquo; he asked among other related question. </p>

<p>&ldquo;Let me say that Nigerians know why these kinds of statement are being made today. But El-Rufai&rsquo;s statement is neither in Buhari&rsquo;s interest nor in Nigeria&rsquo;s interest. The governor is not serious.&rdquo; </p>

<p>IPAC president, Dr. Tanko said: &lsquo;&rsquo;That is his personal opinion because he cannot speak for over 180 million Nigerians. How can he say such in a country of over 180 people? What if something happens to the man, does it mean there would be no one in Nigeria? We know that Mr. President is a man of integrity but it is wrong for El-Rufai to have said so. It is an unfortunate statement from an intelligent person like him. It is an unfair statement, very wrong and an insult to Nigerians.&rsquo;&rsquo;</p>

<p>El-Rufai can&rsquo;t decide for Nigerians&mdash;Agbakoba</p>

<p>Puncturing el-Rufai&rsquo;s position, a leader of the Nigeria Intervention Movement, NIM, Chief Agbakoba, said: &ldquo;Of course, that is not correct. The people who can decide that are Nigerians and not Governor el-Rufai. As you know, Chief Olusegun Obasanjo has said that he (Buhari) should not run but I think the real question is: if he (Buhari) decides to run, will the voters accept to vote him in? It is only the voters that can answer that question, not el-Rufai, not APC, not Obasanjo, not even me.&rdquo; Another leader of the NIM and civil society activist, Salako on his part said:</p>

<p>&ldquo;APC is his party, he has not told us that he is going to another party yet, so he has only spoken like a good ambassador of the government of which he is a prominent member.</p>

<p>&ldquo;In my own opinion, Nigeria has another option, Buhari is not the only option. Telling us that Buhari is the only option that Nigeria has in 2019 is an insult to the consciousness of people like us who also feel that we are qualified and credible enough to lead Nigeria. There are millions of people out there who can do it better than Buhari. So, for him to say that there is no alternative, he has only spoken according to his own opinion.&rdquo;</p>

<p>Also speaking, elder-statesman, Adebanjo said: &ldquo;He is entitled to say that in his political party. All l know is that Nigerians know that there are a lot of qualified alternatives to Buhari in 2019. Maybe there is no alternative to Buhari in sleep and non performance. Maybe that&rsquo;s what he meant. If it&rsquo;s that, l agree with him.&rdquo;</p>

<p><br />
He&rsquo;s taken it too far&mdash;Odumakin</p>

<p>Afenifere spokesperson, Odumakin said: &ldquo;That&rsquo;s a funny statement. It&rsquo;s like playing God. There is nothing that doesn&rsquo;t have an alternative. To say that there is no alternative to Buhari El -Rufia is playing God over the affairs of Nigeria and he has taken it too far. </p>

<p>&ldquo;There are thousands of better alternatives to Buhari. It is an insult to Nigerians for him to say that there is no alternative to Buhari. Well he is one of those said to be nursing presidential ambition. It&rsquo;s all eye service to Buhari.&rdquo;</p>

<p>It&rsquo;s anybody else but Buhari in 2019&mdash;Okunronmu</p>

<p>Chief Femi Okunronmu, on his part, said: &ldquo;But for the rest of Nigerians, anybody else but Buhari in 2019.&rdquo;</p>

<p>National chairman of the Unity Party of Nigeria, UPN, Professor Okuwa, on his part, said there were many options for Nigeria besides Buhari who he said had failed. &rdquo;Apart from poor performance, Buhari has been sick and not in good health. He was a military man and has been unable to cope with the values of democracy. He promised to fight economic corruption, publish the amount of money recovered, those who made plea bargain, etc. He has not been able to keep the promise and now corruption is killing Nigeria,&rdquo; he said.</p>

<p>Speaking in like manner, national chairman of the Green Party of Nigeria, GPN, Dr Eke said: &rdquo;El-Rufai&rsquo;s comment is unfortunate and contradictory because in 2007, he said Buhari was not fit to rule Nigeria. Between when he made that comment and now ,Nigeria has produced more capable hands who can rule the country better than Buhari.</p>

<p>&rdquo;The APC government has failed Nigeria. The basic condition for re-election is performance not propaganda. Through their bad governance, nepotism, and skewed appointments and policies, Nigeria is now more divided than ever and the country is sitting on a keg of gun powder. Buhari and APC will be dealt with at the polls because Nigerians are prepared to exercise their rights through one-man, one-vote.&rdquo;</p>

<p>Coalition of 200 NGOs adopts Buhari</p>

<p>The coalition, &ldquo;Forum of Non-Governmental Organisations in Nigeria, FOGON, said it would begin a nationwide rally in support of the Buhari administration next week. It condemned what it called &ldquo;An orchestrated campaign going on across the country at the moment to demonise the Buhari administration, in order to pave way for the return of the same people who brought the country to where it was before President Buhari launched his rescue mission upon assuming office.</p>

<p>Addressing a press conference in Abuja on Tuesday, the coalition said it had resolved to throw its weight behind President Buhari because &rdquo; Since assuming office in 2015, he has performed creditably in putting Nigeria on the path of growth and development.&rdquo;</p>

<p>National Coordinator of the coalition, Wole Badmus said those critical of the APC-led administration are being &ldquo;unfair and uncharitable, &rdquo; arguing that before the assumption of office of incumbent administration.&rdquo;</p>

<p>&ldquo;The federal government was borrowing to pay salary; billions were being paid as fuel subsidies to fat cats; corruption was the order of the day and the treasury had become empty after repeated looting,&rdquo; he noted.</p>

<p>Badmus added that despite the difficulties he met on ground, things are beginning to look up for the nation.</p>

<p>By Emmanuel Aziken, Clifford Ndujihe, Dayo Johnson, Dapo Akinrefon, Charles Kumolu &amp; Dirisu Yakubu</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>