<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="keywords" content="<!--__FUEL_MARKER__0-->">
        <meta name="description" content="<!--__FUEL_MARKER__1-->">
        <!-- Latest compiled and minified CSS -->
        
        <link rel="stylesheet" href="<!--__FUEL_MARKER__2-->http://localhost/DEV/governancewatchers/public_assets/dist/assets/owl.carousel.min.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__3-->http://localhost/DEV/governancewatchers/public_assets/dist/assets/owl.theme.default.min.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__4-->http://localhost/DEV/governancewatchers/public_assets/css/bootstrap.min.css">

        <!-- Optional theme -->
        <link rel="stylesheet" href="<!--__FUEL_MARKER__5-->http://localhost/DEV/governancewatchers/public_assets/css/bootstrap-theme.min.css">
        <link rel="stylesheet" id="themify-icons-css" href="<!--__FUEL_MARKER__6-->http://localhost/DEV/governancewatchers/public_assets/css/themify-icons.css" type="text/css" media="all">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__7-->http://localhost/DEV/governancewatchers/public_assets/css/style.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__8-->http://localhost/DEV/governancewatchers/public_assets/css/jquery-ui.min.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__9-->http://localhost/DEV/governancewatchers/public_assets/css/fonts.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__10-->http://localhost/DEV/governancewatchers/public_assets/css/font-awesome.min.css">
        <link rel="shortcut icon" href="<!--__FUEL_MARKER__11-->http://localhost/DEV/governancewatchers/public_assets/image/favicon.png">
        <title>
            <!--__FUEL_MARKER__12-->Home        </title>
        <link href='http://fonts.googleapis.com/css?family=Raleway:400,700' rel='stylesheet' type='text/css'>
    </head>
<body onload="startTime()">
    <!--Load Page-->
    <div class="load-page">
        <div class="sk-cube-grid">
            <div class="sk-cube sk-cube1"></div>
            <div class="sk-cube sk-cube2"></div>
            <div class="sk-cube sk-cube3"></div>
            <div class="sk-cube sk-cube4"></div>
            <div class="sk-cube sk-cube5"></div>
            <div class="sk-cube sk-cube6"></div>
            <div class="sk-cube sk-cube7"></div>
            <div class="sk-cube sk-cube8"></div>
            <div class="sk-cube sk-cube9"></div>
        </div>
    </div>
    <!-- Mobile nav -->
    <nav class="visible-sm visible-xs mobile-menu-container mobile-nav">
        <div class="menu-mobile-nav navbar-toggle">
            <span class="icon-search-mobile"><i class="fa fa-search" aria-hidden="true"></i></span>
            <span class="icon-bar"><i class="fa fa-bars" aria-hidden="true"></i></span>
        </div>
        <div id="cssmenu" class="animated">
            <div class="uni-icons-close"><i class="fa fa-times" aria-hidden="true"></i></div>
            <ul class="nav navbar-nav animated">
                <li class="has-sub home-icon"><a href='#'>Home</a>
                </li>
                <li class='has-sub'><a href='#'>Economy</a></li>
                <li class="has-sub"><a href='#'>Sport</a></li>
                <li class="has-sub"><a href='#'>Fashion</a></li>
                <li class="has-sub"><a href='#'>Music</a></li>
                <li class="has-sub"><a href='#'>Video</a></li>
                <li class="has-sub"><a href='#'>Features</a>
                    <ul>
                        <li class="has-sub"><a href="#">Sidebar</a>
                            <ul>
                                <li><a href="03_01_01_left_sidebar.html">Left Sidebar</a></li>
                                <li><a href="03_01_02_right_sidebar.html">Right Sidebar</a></li>
                                <li><a href="03_01_03_without_sidebar.html">Without Sidebar</a></li>
                            </ul>
                        </li>
                        <li class="has-sub"><a href="#">Single Post</a>
                            <ul>
                                <li><a href="03_02_01_image_post.html">Image Post</a></li>
                                <li><a href="03_02_02_slide_post.html">Slide Post</a></li>
                                <li><a href="03_02_03_video_post.html">Video Post</a></li>
                                <li><a href="03_02_04_post_full_width.html">Post Full</a></li>
                                <li><a href="03_02_05_post_no_sidebar.html">Post No Sidebar</a></li>
                            </ul>
                        </li>
                        <li class="has-sub"><a href="#">Search Results</a>
                            <ul>
                                <li><a href="03_03_01_search_results_list.html">Search Result List</a></li>
                                <li><a href="03_03_02_search_results_grid.html">Search Result Grid</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="has-sub"><a href='#'>Category</a>
                    <ul>
                        <li><a href="02_01_list.html">List</a></li>
                        <li><a href="02_02_list.html">List 2</a></li>
                        <li><a href="02_03_grid_2_columns.html">Grid 2 Columns</a></li>
                        <li><a href="02_04_grid_2_columns_2.html">Grid 2 Columns 2</a></li>
                        <li><a href="02_05_mixed.html">Mixed</a></li>
                    </ul>
                </li>
                <li class="has-sub"><a href='#'>Pages</a>
                    <ul>
                        <li><a href="04_01_about.html">About</a></li>
                        <li><a href="04_02_contact.html">Contact</a></li>
                        <li><a href="04_03_404page.html">404 Page</a></li>
                    </ul>
                </li>
                <li class="has-sub"><a href='#'>Shop</a>
                    <ul>
                        <li><a href="05_01_shop.html">Shop</a></li>
                        <li><a href="05_02_single_product.html">Single Product</a></li>
                        <li><a href="05_03_cart.html">Cart</a></li>
                        <li><a href="05_04_checkout.html">Checkout</a></li>
                    </ul>
                </li>
            </ul>
            <div class="uni-nav-mobile-bottom">
                <div class="form-search-wrapper-mobile">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search">
                        <span class="input-group-addon success"><i class="fa fa-search"></i></span>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </nav>
    <!-- End mobile menu -->



    <div id="wrapper-container" class="site-wrapper-container">
        <header>
            <div class="vk-header-default">
                <div class="container-fluid">
                    <div class="row">
                        <div class="vk-top-header">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-4 col-sm-4">
                                        <div class="vk-top-header-1">
                                            <ul>
                                                <li><a href="#"> Contact</a></li>
                                                <!--<li><a href="#">Purchase Now</a></li>-->
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class="vk-top-header-2">
                                            <ul>
                                                <li><span id="datetime-current"></span></li>
                                                <li>-</li>
                                                <li><span id="year-current"></span></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class="vk-top-header-3">
                                            <ul>
                                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="vk-between-header">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="vk-between-header-logo">
                                            <a href="index-2.html"><img src="<!--__FUEL_MARKER__13-->http://localhost/DEV/governancewatchers/public_assets/image/governance_watchers.png" alt="" class="img-responsive"></a>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-md-offset-1">
                                        <div class="vk-between-header-banner">
                                            <a href="#"><img src="<!--__FUEL_MARKER__14-->http://localhost/DEV/governancewatchers/public_assets/image/ad-header.jpg" alt="" class="img-responsive"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="visible-md visible-lg vk-bottom-header uni-sticky">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-11">
                                        <div class="cssmenu">
                                            <ul>
                                                <li class="home-icon"><a href='#'><i class="fa fa-home" aria-hidden="true"></i></a>
                                                </li>
                                                <li><a href='#'>About</a></li>
                                                <li><a href='#'>Survey</a></li>
                                                <li><a href='#'>fashion</a></li>
                                                <li class="has-sub home-music"><a href='#'>music</a></li>
                                                <li class="has-sub home-video"><a href='#'>video</a></li>
                                                <li class="has-sub"><a href='#'>features</a>
                                                    <ul>
                                                        <li class="has-sub"><a href="#">Sidebar</a>
                                                            <ul>
                                                                <li><a href="03_01_01_left_sidebar.html">Left Sidebar</a></li>
                                                                <li><a href="03_01_02_right_sidebar.html">Right Sidebar</a></li>
                                                                <li><a href="03_01_03_without_sidebar.html">Without Sidebar</a></li>
                                                            </ul>
                                                        </li>
                                                        <li class="has-sub"><a href="#">Single Post</a>
                                                            <ul>
                                                                <li><a href="03_02_01_image_post.html">Image Post</a></li>
                                                                <li><a href="03_02_02_slide_post.html">Slide Post</a></li>
                                                                <li><a href="03_02_03_video_post.html">Video Post</a></li>
                                                                <li><a href="03_02_04_post_full_width.html">Post Full</a></li>
                                                                <li><a href="03_02_05_post_no_sidebar.html">Post No Sidebar</a></li>
                                                            </ul>
                                                        </li>
                                                        <li class="has-sub"><a href="#">Search Results</a>
                                                            <ul>
                                                                <li><a href="03_03_01_search_results_list.html">Search Result List</a></li>
                                                                <li><a href="03_03_02_search_results_grid.html">Search Result Grid</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="has-sub"><a href='#'>Category</a>
                                                    <ul>
                                                        <li><a href="02_01_list.html">List</a></li>
                                                        <li><a href="02_02_list.html">List 2</a></li>
                                                        <li><a href="02_03_grid_2_columns.html">Grid 2 Columns</a></li>
                                                        <li><a href="02_04_grid_2_columns_2.html">Grid 2 Columns 2</a></li>
                                                        <li><a href="02_05_mixed.html">Mixed</a></li>
                                                    </ul>
                                                </li>
                                                <li class="has-sub"><a href='#'>pages</a>
                                                    <ul>
                                                        <li><a href="04_01_about.html">About</a></li>
                                                        <li><a href="04_02_contact.html">Contact</a></li>
                                                        <li><a href="04_03_404page.html">404 Page</a></li>
                                                    </ul>
                                                </li>
                                                <li class="has-sub"><a href='#'>shop</a>
                                                    <ul>
                                                        <li><a href="05_01_shop.html">Shop</a></li>
                                                        <li><a href="05_02_single_product.html">Single Product</a></li>
                                                        <li><a href="05_03_cart.html">Cart</a></li>
                                                        <li><a href="05_04_checkout.html">Checkout</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-1">
                                        <div class="vk-bottom-header-search toggle-form">
                                            <i class="fa fa-search" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                                <!--Form search-->
                                <div class="form-search-wrapper">
                                    <div class="input-group">
                                        <input type="text" class="form-control" placeholder="Search">
                                        <span class="input-group-addon success"><i class="fa fa-search"></i></span>
                                    </div>
                                </div>
                                
							</div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        
        <div id="main-content" class="site-main-content">
        <div id="home-main-content" class="site-home-main-content">

            <div class="uni-about">

                <div class="uni-about-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="breadcrumb breadcrumb-search">
                                    <a href="#">Home</a>
                                    <a href="#" class="active">about</a>
                                </div>

                                <div class="uni-about-content">
                                    <h2><!--__FUEL_MARKER__15-->Who we are and what we do.</h2>
                                    <div class="description">
										<!--__FUEL_MARKER__16--><p>Governance watchers is a News web application, Survey and Governance rating platform with a vision of a global reputation and is oriented to develop the high-quality online and on-the-go resource of accurate information that mirrors variability of opinions and meaningful discussions about development of democratic society in Nigeria. Governance watchers provides instant news reports, analytical materials, reviews, comments.</p> 

<p>Governance watchers  produces news items about Politics, Lifestyles, Business, Sport, Technology, Opinions and Economy and it is multilingual. Its interactive features include traditional push-channels of content: RSS, mail list, online bookmarks and social networks: Facebook, Twitter and Instagram.</p>

<p>Governance watchers  provides latest news 24/7, survey on topical issues and governance performance index with data based facts. We aim to be the place where people can not only read, but discuss criticalssues. A platform that people can trust and rely on having high quality and unbiased information, being the voice of the masses and influencing inclusive and good democratic governance in Africa.</p>                                    </div>

									<br><br>
                                    <!-- CONTACT INFORMATION-->
                                    <div class="uni-about-contact-info">
                                        <h2>Contact Infomation</h2>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="uni-about-contact-info-left">
                                                    <ul>
                                                        <li>
                                                            <h4><i class="fa fa-home" aria-hidden="true"></i> Office Address</h4>
                                                            <!--__FUEL_MARKER__17--><strong>Ondo Address</strong>
<br>
<p>3, Ilaje Close, Ijapo Estate Akure.</p><br>
                                                            <!--__FUEL_MARKER__18--><strong>Canada</strong>

<p>909, Mandolin Place, Mississauga, Ontario</p><br>
                                                            <!--__FUEL_MARKER__19--><strong>Ireland</strong>					
<p>10 Mount Eustace Walk				
Tyrrelstown, Dublin 15</p><br>
                                                        </li>
                                                        <li>
                                                            <h4><i class="fa fa-envelope" aria-hidden="true"></i> Office Email</h4>
															<p><!--__FUEL_MARKER__20-->info@governancewatchers.com</p>
                                                            <p><!--__FUEL_MARKER__21-->support@governancewatchers.com</p>
                                                        </li>
                                                        <li>
                                                            <h4><i class="fa fa-phone" aria-hidden="true"></i> Tel</h4>
                                                            <p><!--__FUEL_MARKER__22-->+2349063190670</p>
                                                            <p><!--__FUEL_MARKER__23-->+2348095060650</p>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="uni-about-contact-info-right">
                                                    <div class="uni-about-contact-map">
                                                        <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2520.3558605259554!2d-0.1305261839151272!3d50.824572079528714!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4875859878db2cc7%3A0xff129250121f260d!2s45+Queen's+Park+Rd%2C+Brighton+BN2+0GJ%2C+UK!5e0!3m2!1sen!2s!4v1505207016897" allowfullscreen=""></iframe>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <aside class="widget-area">

                                    <aside class="widget">
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-ad">
                                                <a href="#">
                                                    <img src="image/ad-sidebar.jpg" alt="ad-sidebar" class="img-responsive">
                                                </a>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-facebook">
                                                <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ffacebook&amp;tabs=timeline&amp;width=340&amp;height=500&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId" width="340" height="500" style="border:none;overflow:hidden"></iframe>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <h3 class="widget-title">Stay Connected</h3>
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-stay">
                                                <div class="vk-right-stay-body">
                                                    <a class="btn btn-block btn-social btn-facebook">
                                                        <span class="icon"><i class="fa fa-facebook"></i></span>
                                                        <span class="info"> 2134 Like</span>
                                                        <span class="text">Like</span>
                                                    </a>
                                                    <a class="btn btn-block btn-social btn-twitter">
                                                        <span class="icon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                                                        <span class="info"> 13634 Follows</span>
                                                        <span class="text">Follows</span>
                                                    </a>
                                                    <a class="btn btn-block btn-social btn-youtube">
                                                        <span class="icon"><i class="fa fa-youtube-play" aria-hidden="true"></i></span>
                                                        <span class="info">10634 Subscribers</span>
                                                        <span class="text">Subscribe</span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <h3 class="widget-title">Tags Clound</h3>
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-tags">
                                                <ul>
                                                    <li><a href="#">LifeStyle</a></li>
                                                    <li><a href="#">Sport</a></li>
                                                    <li><a href="#">Economy</a></li>
                                                    <li><a href="#">Business</a></li>
                                                    <li><a href="#">Travel</a></li>
                                                    <li><a href="#">Techology</a></li>
                                                    <li><a href="#">Movies</a></li>
                                                    <li><a href="#">Fashion</a></li>
                                                    <li><a href="#">video</a></li>
                                                    <li><a href="#">Music</a></li>
                                                    <li><a href="#">Photography</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </aside>

                                </aside>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>

        </div>
    </div>

        <footer>
            <div class="container-fluid">
                <div class="row">
                    <div class="vk-sec-footer">
                        <div class="container">
                            <div class="row">
                                <div class="vk-footer">
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <div class="widget-title">
                                                <a href="index-2.html"><img src="<!--__FUEL_MARKER__24-->http://localhost/DEV/governancewatchers/public_assets/image/logo_2.png" alt="" class="img-responsive"></a>
                                            </div>
                                            <div class="widget-content">
                                                <div class="vk-footer-1">

                                                    <div class="vk-footer-1-content">
                                                        <p>
                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis
                                                            egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante.
                                                            Donec eu libero sit amet quam egestas semper.
                                                        </p>
                                                        <div class="vk-footer-1-address">
                                                            <ul>
                                                                <li><i class="fa fa-map-marker" aria-hidden="true"></i> <span>45 Queen's Park Rd, Brighton, BN2 0GJ, UK</span></li>
                                                                <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <span><a href="#">maxnews@domain.com</a></span></li>
                                                                <li><i class="fa fa-headphones" aria-hidden="true"></i> <span> (0123) 456 789</span></li>
                                                            </ul>
                                                        </div>
                                                        <div class="vk-footer-1-icon">
                                                            <ul>
                                                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <h3 class="widget-title"> Latest News</h3>
                                            <div class="widget-content">
                                                <div class="vk-footer-2">
                                                    <div class="vk-footer-2-content">
                                                        <ul>
                                                            <li>
                                                                <div class="vk-footer-img">
                                                                    <a href="#"><img src="<!--__FUEL_MARKER__25-->http://localhost/DEV/governancewatchers/public_assets/image/footer/img.jpg" alt="" class="img-responsive"></a>
                                                                </div>
                                                                <div class="vk-footer-content">
                                                                    <div class="vk-footer-title">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                    </div>
                                                                    <div class="vk-footer-time">
                                                                        <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-footer-img">
                                                                    <a href="#"><img src="<!--__FUEL_MARKER__26-->http://localhost/DEV/governancewatchers/public_assets/image/footer/img-1.jpg" alt="" class="img-responsive"></a>
                                                                </div>
                                                                <div class="vk-footer-content">
                                                                    <div class="vk-footer-title">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                    </div>
                                                                    <div class="vk-footer-time">
                                                                        <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-footer-img">
                                                                    <a href="#"><img src="<!--__FUEL_MARKER__27-->http://localhost/DEV/governancewatchers/public_assets/image/footer/img-2.jpg" alt="" class="img-responsive"></a>
                                                                </div>
                                                                <div class="vk-footer-content">
                                                                    <div class="vk-footer-title">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                    </div>
                                                                    <div class="vk-footer-time">
                                                                        <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <h3 class="widget-title">Twitter Feed</h3>
                                            <div class="widget-content">
                                                <div class="vk-footer-3">
                                                    <div class="vk-footer-3-content">
                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> MaxNews</a></span>
                                                            Your body is like a race car!! You need to fuel it right to keep performing at your best!
                                                        </p>
                                                        <div class="time">about 5 days ago</div>

                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> MaxNews</a></span>
                                                            Your body is like a race car!! You need to fuel it right to keep performing at your best!
                                                        </p>
                                                        <div class="time">about 5 days ago</div>

                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> MaxNews</a></span>
                                                            Your body is like a race car!! You need to fuel it right to keep performing at your best!
                                                        </p>
                                                        <div class="time">about 5 days ago</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="vk-sub-footer">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="vk-sub-footer-1">
                                            <p>
                                                <span>MaxNews</span>
                                                -  News & Magazine PSD Template. Design by
                                                <span>Univertheme</span>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-5 col-md-offset-2">
                                        <div class="vk-sub-footer-2">
                                            <ul>
                                                <li><a href="#">Disclaimer </a></li>
                                                <li><a href="#"> Privacy</a></li>
                                                <li><a href="#"> Advertisement</a></li>
                                                <li><a href="#">Contact us</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>

        <script src="<!--__FUEL_MARKER__28-->http://localhost/DEV/governancewatchers/public_assets/js/jquery-2.0.2.min.js"></script>
        <script src="<!--__FUEL_MARKER__29-->http://localhost/DEV/governancewatchers/public_assets/js/jquery.sticky.js"></script>
        <script src="<!--__FUEL_MARKER__30-->http://localhost/DEV/governancewatchers/public_assets/js/masonry.min.js"></script>
        <script src="<!--__FUEL_MARKER__31-->http://localhost/DEV/governancewatchers/public_assets/js/jquery-ui.min.js"></script>
        <script src="<!--__FUEL_MARKER__32-->http://localhost/DEV/governancewatchers/public_assets/js/bootstrap.min.js"></script>
        <script src="<!--__FUEL_MARKER__33-->http://localhost/DEV/governancewatchers/public_assets/dist/owl.carousel.js"></script>
        <script src="<!--__FUEL_MARKER__34-->http://localhost/DEV/governancewatchers/public_assets/js/main.js"></script>
        <script src="<!--__FUEL_MARKER__35-->http://localhost/DEV/governancewatchers/public_assets/js/bootstrap-hover-tabs.js"></script>
    </body>
</html>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>