<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('Rotimi-aketi-Akeredolu.jpg');?>" alt="We Are Ready To Face Fulani Herdsmen With Force, Says Gov. Akeredolu" class="img img-responsive" /><br />
Ondo State governor, Mr. Rotimi Akeredolu, has declared that his administration will apply force to arrest the menace of Fulani herdsmen in the state. The governor made the declaration in Akure, on Sunday, during an event to commemorate the Armed Forces Remembrance Day.&ldquo;We have been using security agencies to engage the herdsmen to carry out their business peacefully but when engagement fails, we will use force. We will confront the herdsmen with all we have,&#8221; the governor said.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>