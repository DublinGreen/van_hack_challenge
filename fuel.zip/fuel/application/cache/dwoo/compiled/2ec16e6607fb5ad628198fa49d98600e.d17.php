<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>Two security officials of Second Coming Gas Plant died in a fire outbreak that engulfed the gas station at the early hours of today. The two men and a number of others were on night duty when the fire started.</p>

<p><img src="<?php echo img_path('gas_inferno_1.jpg');?>" alt="Two Dead, Many Injured At Magodo Inferno" class="img img-responsive"/><br />
<br></p>

<p>An unofficial report by a Neighborhood Security officers who was at the scene when the inferno started said there were about ten causalities. He opined that the two dead men must have been asleep when the fire started hence they could not hurry for safety.</p>

<p>&ldquo;We were on patrol very early this morning when we heard noise of explosion from the gas company. </p>

<p>&ldquo;Some of the staff who were on night duty were able to escape with little bruises by jumping the fence but the two men who died were at sleep&rdquo; he said.</p>

<p>Also, eyewitnesses at the CMD road, Magodo, where the incident happened, confirmed that two men were severely burnt by the fire, expressing doubt about their chances of surviving. According to the Lagos State Director of Fire Service, Mr. Rasak Fadipe, the fire was caused by leakage from an offloading gas tank which was ignited by a moving vehicle.</p>

<p>The fire service were called in by the gas company to control the leakage unfortunately, while they were at it, the exhaust pipe of a passing vehicle ignited the fire.</p>

<p>&ldquo;We were inside the gas premises  but unfortunately when a vehicle was passing along. It was through the exhaust pipe that caused the fire.</p>

<p>He further stated that if not for the concerted effort of all emergency response agencies, the whole of Magodo could have been on fire.</p>

<p>Although he claimed there was no casualties on the side of the Lagos State Fire Service, but an unofficial report from one of the firemen claimed two of their colleagues have had to be taken to the hospital.</p>

<p>While also addressing the press, the General Manger of Lagos State Emergency Management Agency (LASEMA) Adesina Tiamiyu, said investigations are going on to ascertain the cause of the fire.</p>

<p>&ldquo;A comprehensive incident assessment will be done to unravel the mystery behind this fire and where there is negligence; we will also identify that and take our report back to the government to take appropriate action.&#8221;</p>

<p>All Lagos state law enforcement and emergency response team were around. However, one of the ambulance service personnel who was at the scene expressed worries about likelihood of trapped casualties.</p>

<p>The fire reportedly started at about 7:30am on Monday, January 15, 2018. At the time of filing this report, all hands were on deck by officials of different Lagos State emergency agencies to put out the fire.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>