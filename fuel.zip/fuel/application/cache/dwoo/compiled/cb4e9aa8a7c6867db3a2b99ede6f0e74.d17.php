<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('kfnjvmvhf.jpg');?>" alt="2019: We&rsquo;ve options other than Buhari, Nigerians reply El-Rufai" class="img img-responsive" /><br />
LAGOS&mdash;STRONG denunciations of the claim by Governor Nasir El-Rufai that Nigeria has no better option to President Muhammadu Buhari swept across the country yesterday, with leading Nigerians in civil society and opposition political parties strongly disagreeing with the Kaduna governor.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>