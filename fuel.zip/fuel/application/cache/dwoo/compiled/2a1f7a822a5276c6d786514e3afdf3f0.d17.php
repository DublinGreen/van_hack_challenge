<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><a href="https://facebook.com" target="_blank"><img src="<?php echo img_path('side-advert.jpg');?>" alt="side advert" title="side advert" class="img-responsive" /></a><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>