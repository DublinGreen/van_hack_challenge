<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('blog/patience_johnathan.jpg');?>" alt="Patience Jonathan" class="img-responsive" /><br />
<br><br />
The Economic and Financial Crimes Commission is in fresh moves to seize funds in 15 bank accounts linked to Mrs. Patience Jonathan.</p>

<p>The funds, which the EFCC is seeking to seize, include a total of $8,435,788.84 and over N7.35bn.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>