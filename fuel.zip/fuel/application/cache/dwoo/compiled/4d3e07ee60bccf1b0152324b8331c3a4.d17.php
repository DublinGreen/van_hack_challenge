<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>Mrs.&nbsp; Marie Ebikake, the former Commissioner for Transport in Bayelsa, a soldier and were abducted in separate incidents at the weekend by unknown gunmen in Bayelsa. The incidents occurred barely three days after a Bayelsa monarch&rsquo;s wife who spent 25 days in captivity was freed on Thursday.</p>

<p>Ebikake was kidnapped at her residence in Igbogene area of Yenagoa Local Government Council Area of the state in the early hours of Sunday. The spokesman for the Bayelsa Police Command AsImin Butswat confirmed the development on Sunday.<br />
 
&#8220;She was abducted at her residence by unknown gunmen at about 1 am today. Manhunt has been launched to apprehend the perpetrators.&#8221; Butswat said. A soldier was reportedly abducted by suspected sea pirates between the waterway of Foropa and Azuzuama area of Southern Ijaw Local Government Area. <br />
 
The soldier identified simply as Rotimi was abducted on board a passenger boat on to Yenagoa as kidnappers shot the boat driver shot in the shoulder. &ldquo;The suspected sea pirates attacked the boat conveying the soldier and two other person&#8217;s to Yenagoa, they shot the boat driver and took away the soldier.<br />
 
&ldquo;They also stole the boat engine. They however left behind the female passenger &#8221; A community said on phone.<br />
 
Ebikake, who hails from Brass Local Government Area was also a former local government chairperson in the area. It was learnt that on January 10 some armed men had invaded her country home in Twon-Brass in Brass Local Government and vandalized her residence.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>