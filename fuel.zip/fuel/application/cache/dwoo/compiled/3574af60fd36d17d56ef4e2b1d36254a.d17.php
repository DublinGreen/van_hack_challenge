<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?>Hakk Team Limited<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>