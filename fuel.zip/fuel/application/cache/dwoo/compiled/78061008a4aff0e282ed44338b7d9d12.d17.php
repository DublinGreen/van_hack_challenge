<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('2.jpg');?>" alt="Governor Rochas Okorocha of Imo State has said he will not give any land in Imo State to the Federal Government for a cattle colony." class="img img-responsive" /><br />
Governor Rochas Okorocha of Imo State has said he will not give any land in Imo State to the Federal Government for a cattle colony.</p>

<p>Okorocha also dismissed the speculation that he had adopted the proposed colonies and ceded a part of the state to herders as wicked, unfounded and untrue.</p>

<p>The governor who spoke on Tuesday in Owerri, the state capital, through the state Commissioner for Information, Prof. Nnamdi Obiaraeri, said there was no law, policy, decision, plan, request or intention to cede, allocate or designate any part of Imo State as a cattle colony.</p>

<p>The governor said, &ldquo;This information that Imo has ceded a part for the proposed cattle colony is wicked, unfounded and untrue, although it represents the typical product of warped thinking of desperate mischief makers via the social media.</p>

<p>&ldquo;Imo people and members of the public are therefore advised to disregard these baseless and laughable rumours.</p>

<p>&ldquo;It is unfortunate that manufacturing wicked and capricious lies on an hourly basis has become the hallmark or DNA of desperate opposition politicians in our dear state.&rdquo;<br />
Also, the Rivers State Governor, Chief Nyesom Wike, has said the state does not have land for a cattle colony.<br />
 Wike, who also declared that his administration would not allow Rivers to be controlled by external forces, insisted that his government would not be drawn into any debate on cattle colonies.<br />
 The governor, who spoke on Tuesday when he granted audience to D-Source Connect Group at the Government House in Port Harcourt, said, &ldquo;We will not allow our state to be controlled by external forces; we will not be drawn into debates on cattle colonic. We don&rsquo;t have land for any cattle colony in Rivers State.&rdquo;<br />
Similarly, the Senator representing Southern Kaduna, Danjuma Laah, on Tuesday asked the Federal Government not to expect any land from the zone for the planned cattle colonies.</p>

<p>Laah said, &ldquo;Kaduna South Senatorial Zone and, by extension, the entire Southern Kaduna rejects any attempt to seize more of its lands for the exclusive settlement of herdsmen and their cattle, using state power.<br />
&ldquo;Already, there is an existing Cattle Grazing Reserve in Laduga from land taken away from the indigenes of Zangon Kataf and Kachia Local Government Areas dating back decades ago.</p>

<p>&ldquo;That massive land officially gazetted at 32,000 hectaress, (32,000 football fields), but which the present Kaduna State Government has expanded to 74,000 hectare, was taken from my constituents without compensation till date, as records have it.&rdquo;<br />
The lawmaker lamented that rather than the Federal Government requesting land for university, industry, it was asking for land for colonies.</p>

<p>&ldquo;Ask us for lands to site universities, government institutions etc, we are willing to give out our land in partnership with industrialists, mechanised farmers, estate developers and all positive social and economic endeavours that are of mutual benefits to everyone.</p>

<p>&ldquo;No land in Southern Kaduna is free again for the exclusive economic benefit of a group of people who have paid us with mass murder and destruction in scores of our settlements since 2011 for humanely accommodating them and their forebears.&rdquo;</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>