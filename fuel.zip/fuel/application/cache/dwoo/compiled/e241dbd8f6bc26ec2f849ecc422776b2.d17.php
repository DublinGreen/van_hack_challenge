<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>Afenifere said the removal of the Defence Minister&#8230;</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>