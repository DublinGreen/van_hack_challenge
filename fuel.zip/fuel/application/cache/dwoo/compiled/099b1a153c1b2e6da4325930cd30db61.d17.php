<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>The All Progressives Congress National Working Committee and governors elected on its platform would meet at the party national secretariat on Wednesday, Jan. 17.</p>

<p>The consultative meeting according to a source at the party&rsquo;s national secretariat will discuss the 2019 general election timetable issued by the Independent National Electoral <br />
Commission recently.</p>

<p><img src="<?php echo img_path('apc.jpg');?>" alt="APC" class="img img-responsive"/><br />
<br></p>

<p>The meeting is expected to also fix a date for the party&rsquo;s congresses and national convention that had been slated to hold this year.</p>

<p>&ldquo;The governors and the NWC members will discuss the issue of the party congress and convention; they will also look at the INEC 2019 general election timetable,</p>

<p>&ldquo;As you know, this will be the first consultative meeting in 2018.</p>

<p>&ldquo;The meeting is expected to be attended by the governors as other national issues as regards APC winning the 2019 general elections will be discussed,&rsquo;&rsquo; the source said.</p>

<p>The APC consultative meeting was initiated in April 2017 by its National Chairman, Chief John Odigie-Oyegun to ensure monthly meeting of governors elected on the party&rsquo;s platform and members of its NWC.</p>

<p>Kaduna State governor, Malam Nasir El-Rufai, had told newsmen that the consultative meeting will be holding monthly until 2019 general elections.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>