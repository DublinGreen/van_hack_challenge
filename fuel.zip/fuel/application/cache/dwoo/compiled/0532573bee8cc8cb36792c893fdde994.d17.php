<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('South-African-Airways-Airbus-A319-100_PlanespottersNet_159129.jpg');?>" alt="Nigerian Drug Law Agency Arrests Nine Drug Traffickers Including A South African At Lagos Airport" class="img img-responsive" /><br />
Officials of the National Drug Law Enforcement Agency (NDLEA) have arrested nine drug traffickers within one week at the Murtala Muhammed International Airport (MMIA), Lagos. The arrests were made between December 24 and 31, 2017 at the airport. Among the suspects was a South African male. At least, 120kg of several illicit narcotic substances were seized from the suspects within the one week period. An investigation by SaharaReporters indicated that many of the suspects fights originated from Brazil, connected Lagos to Johannesburg, South Africa.</p>

<p>Seven of the suspects were males, including a South African while the two others were females.</p>

<p>Most of the suspects were arrested during the inward screening of passengers on South Africa Airways flights.</p>

<p>An NDLEA source told SaharaReporters that many of the suspects thought they had perfected their plans by changing flights in Brazil to South Africa Airways, but they were still arrested at the airport by NDLEA operatives.</p>

<p>The source said: &ldquo;These NDLEA operatives are very proactive in their operations. They made a lot of arrests of suspected drug traffickers and seizures between December 24 till 31, 2017. While some of the suspects were arrested on the flights of other airlines, the majority of the arrests were made of South Africa Airways&rsquo; flights.</p>

<p>&ldquo;We learnt that the NDLEA operatives have discovered that the suspects have changed their choice of airline from their Brazil base to Nigeria. But, unfortunately for them they were arrested on arrival in Lagos. I can tell you that one of them is a South African who feigned an ailment believing that the agency would allow him to go back to his country because of his health condition, but he was wrong as NDLEA officials hold on to him, took him to a well-equipped hospital for treatment.</p>

<p>&ldquo;It was however discovered at the hospital that the suspect was seeking a cunning way to get off the NDLEA&rsquo;s hook. He has since been returned to his cell after treatment.&rdquo;</p>

<p>However, attempts to get the Commander,&nbsp; NDLEA Murtala Muhammed International Airport, Mr. Garba to comment on the arrests and seizures were not successful.</p>

<p>Also another attempt to get the agency&rsquo;s spokesperson Jonah Achema comment on the development proved abortive.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>