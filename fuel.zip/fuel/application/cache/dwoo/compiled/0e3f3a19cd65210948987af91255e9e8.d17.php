<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><a href="http://hakkteam.com" target="_blank" title="hakk team limited">Hakk Team Limited</a><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>