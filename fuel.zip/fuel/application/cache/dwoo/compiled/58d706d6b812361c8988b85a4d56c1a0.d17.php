<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('17861431_10210808805448942_2517129343912443366_n.jpg');?>" alt="President Muhammadu Buhari" class="img-responsive" /><br />
<br><br />
President Muhammadu Buhari on Monday assured Benue State leaders who met with him on recent killings in the state that he will never protect criminals.</p>

<p>He has again ordered the Inspector-General of Police, Ibrahim Idris, to arrest and prosecute the perpetrators of the recent killings in the state.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>