<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><strong>Ireland</strong>					
<p>10 Mount Eustace Walk				
Tyrrelstown, Dublin 15</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>