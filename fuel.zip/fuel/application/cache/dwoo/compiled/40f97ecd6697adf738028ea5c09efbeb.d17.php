<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>The Minister of Interior, retired Lt.-Gen. Abdulrahman Dambazau, Tuesday in Abuja held a crucial closed-door meeting with heads of internal security agencies over the security challenges in the country.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>