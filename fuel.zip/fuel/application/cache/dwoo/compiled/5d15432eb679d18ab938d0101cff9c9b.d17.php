<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('happy_new_year_hamida.jpg');?>" alt="" /><br />
Kemi is eating bread and tea and it seem she is really enjoying it&#8230;.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>