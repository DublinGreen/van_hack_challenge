<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('12.jpg');?>" alt="Oshiomhole Canvasses Support for Buhari as Thousands Defect to APC" class="img img-responsive" /><br />
Former Governor of Edo State, Comrade Adams Oshiomhole has canvassed support for President Muhammadu Buhari, saying people should be patient with the president because money meant to develop the country was cornered by the past administration.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>