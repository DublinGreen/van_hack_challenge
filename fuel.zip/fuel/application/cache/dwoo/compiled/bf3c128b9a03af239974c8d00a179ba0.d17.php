<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="keywords" content="<!--__FUEL_MARKER__0-->contact governance watchers,">
        <meta name="description" content="<!--__FUEL_MARKER__1-->contact governance watchers">
        <!-- Latest compiled and minified CSS -->
        
        <!--__FUEL_MARKER__2-->http://localhost/DEV/governancewatchers/public_assets/        <link rel="stylesheet" href="http://localhost/DEV/governancewatchers/public_assets/dist/assets/owl.carousel.min.css">
        <link rel="stylesheet" href="http://localhost/DEV/governancewatchers/public_assets/dist/assets/owl.theme.default.min.css">
        <link rel="stylesheet" href="http://localhost/DEV/governancewatchers/public_assets/css/bootstrap.min.css">

        <!-- Optional theme -->
        <link rel="stylesheet" href="http://localhost/DEV/governancewatchers/public_assets/css/bootstrap-theme.min.css">
        <link rel="stylesheet" id="themify-icons-css" href="http://localhost/DEV/governancewatchers/public_assets/css/themify-icons.css" type="text/css" media="all">
        <link rel="stylesheet" href="http://localhost/DEV/governancewatchers/public_assets/css/style.css">
        <link rel="stylesheet" href="http://localhost/DEV/governancewatchers/public_assets/css/jquery-ui.min.css">
        <link rel="stylesheet" href="http://localhost/DEV/governancewatchers/public_assets/css/fonts.css">
        <link rel="stylesheet" href="http://localhost/DEV/governancewatchers/public_assets/css/font-awesome.min.css">
        <link rel="shortcut icon" href="http://localhost/DEV/governancewatchers/public_assets/image/favicon.png">
        <title>
            <!--__FUEL_MARKER__3-->Contact        </title>
        <link href='http://fonts.googleapis.com/css?family=Raleway:400,700' rel='stylesheet' type='text/css'>
    </head>

<!--<section id="main_inner">
</section>-->


<body onload="startTime()">
    <!--Load Page-->
    <div class="load-page">
        <div class="sk-cube-grid">
            <div class="sk-cube sk-cube1"></div>
            <div class="sk-cube sk-cube2"></div>
            <div class="sk-cube sk-cube3"></div>
            <div class="sk-cube sk-cube4"></div>
            <div class="sk-cube sk-cube5"></div>
            <div class="sk-cube sk-cube6"></div>
            <div class="sk-cube sk-cube7"></div>
            <div class="sk-cube sk-cube8"></div>
            <div class="sk-cube sk-cube9"></div>
        </div>
    </div>
    <!-- Mobile nav -->
    <nav class="visible-sm visible-xs mobile-menu-container mobile-nav">
        <div class="menu-mobile-nav navbar-toggle">
            <span class="icon-search-mobile"><i class="fa fa-search" aria-hidden="true"></i></span>
            <span class="icon-bar"><i class="fa fa-bars" aria-hidden="true"></i></span>
        </div>
        <div id="cssmenu" class="animated">
            <div class="uni-icons-close"><i class="fa fa-times" aria-hidden="true"></i></div>
            <ul class="nav navbar-nav animated">
                <li class="has-sub home-icon"><a href='#'>Home</a>
                    <ul>
                        <li><a href="index-2.html">Home default</a></li>
                        <li><a href="01_02_fashion.html">Home Fashion</a></li>
                        <li><a href="01_03_sport.html">Home Sport</a></li>
                        <li><a href="01_04_techology.html">Home Techology</a></li>
                        <li><a href="01_05_video.html">Home Video</a></li>
                        <li><a href="01_06_boxed.html">Home Boxed</a></li>
                    </ul>
                </li>
                <li class='has-sub'><a href='#'>Economy</a></li>
                <li class="has-sub"><a href='#'>Sport</a></li>
                <li class="has-sub"><a href='#'>Fashion</a></li>
                <li class="has-sub"><a href='#'>Music</a></li>
                <li class="has-sub"><a href='#'>Video</a></li>
                <li class="has-sub"><a href='#'>Features</a>
                    <ul>
                        <li class="has-sub"><a href="#">Sidebar</a>
                            <ul>
                                <li><a href="03_01_01_left_sidebar.html">Left Sidebar</a></li>
                                <li><a href="03_01_02_right_sidebar.html">Right Sidebar</a></li>
                                <li><a href="03_01_03_without_sidebar.html">Without Sidebar</a></li>
                            </ul>
                        </li>
                        <li class="has-sub"><a href="#">Single Post</a>
                            <ul>
                                <li><a href="03_02_01_image_post.html">Image Post</a></li>
                                <li><a href="03_02_02_slide_post.html">Slide Post</a></li>
                                <li><a href="03_02_03_video_post.html">Video Post</a></li>
                                <li><a href="03_02_04_post_full_width.html">Post Full</a></li>
                                <li><a href="03_02_05_post_no_sidebar.html">Post No Sidebar</a></li>
                            </ul>
                        </li>
                        <li class="has-sub"><a href="#">Search Results</a>
                            <ul>
                                <li><a href="03_03_01_search_results_list.html">Search Result List</a></li>
                                <li><a href="03_03_02_search_results_grid.html">Search Result Grid</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="has-sub"><a href='#'>Category</a>
                    <ul>
                        <li><a href="02_01_list.html">List</a></li>
                        <li><a href="02_02_list.html">List 2</a></li>
                        <li><a href="02_03_grid_2_columns.html">Grid 2 Columns</a></li>
                        <li><a href="02_04_grid_2_columns_2.html">Grid 2 Columns 2</a></li>
                        <li><a href="02_05_mixed.html">Mixed</a></li>
                    </ul>
                </li>
                <li class="has-sub"><a href='#'>Pages</a>
                    <ul>
                        <li><a href="04_01_about.html">About</a></li>
                        <li><a href="04_02_contact.html">Contact</a></li>
                        <li><a href="04_03_404page.html">404 Page</a></li>
                    </ul>
                </li>
                <li class="has-sub"><a href='#'>Shop</a>
                    <ul>
                        <li><a href="05_01_shop.html">Shop</a></li>
                        <li><a href="05_02_single_product.html">Single Product</a></li>
                        <li><a href="05_03_cart.html">Cart</a></li>
                        <li><a href="05_04_checkout.html">Checkout</a></li>
                    </ul>
                </li>
            </ul>
            <div class="uni-nav-mobile-bottom">
                <div class="form-search-wrapper-mobile">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search">
                        <span class="input-group-addon success"><i class="fa fa-search"></i></span>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </nav>
    <!-- End mobile menu -->


    <div id="wrapper-container" class="site-wrapper-container">
        <header>
            <div class="vk-header-default">
                <div class="container-fluid">
                    <div class="row">
                        <div class="vk-top-header">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-4 col-sm-4">
                                        <div class="vk-top-header-1">
                                            <ul>
                                                <li><a href="#"> Contact</a></li>
                                                <li><a href="#">Purchase Now</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class="vk-top-header-2">
                                            <ul>
                                                <li><span id="datetime-current"></span></li>
                                                <li>-</li>
                                                <li><span id="year-current"></span></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class="vk-top-header-3">
                                            <ul>
                                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="vk-between-header">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="vk-between-header-logo">
                                            <a href="index-2.html"><img src="image/logo_24.png" alt="" class="img-responsive"></a>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-md-offset-1">
                                        <div class="vk-between-header-banner">
                                            <a href="#"><img src="image/ad-header.jpg" alt="" class="img-responsive"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="visible-md visible-lg vk-bottom-header uni-sticky">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-11">
                                        <div class="cssmenu">
                                            <ul>
                                                <li class="has-sub home-icon"><a href='#'><i class="fa fa-home" aria-hidden="true"></i></a>
                                                </li>
                                                <li class='has-sub home-economy'><a href='#'>ECONOMY</a></li>
                                                <li class="has-sub home-sport"><a href='#'>SPORT</a></li>
                                                <li class="has-sub home-fashion"><a href='#'>fashion</a></li>
                                                <li class="has-sub home-music"><a href='#'>music</a></li>
                                                <li class="has-sub home-video"><a href='#'>video</a></li>
                                                <li class="has-sub"><a href='#'>features</a>
                                                    <ul>
                                                        <li class="has-sub"><a href="#">Sidebar</a>
                                                            <ul>
                                                                <li><a href="03_01_01_left_sidebar.html">Left Sidebar</a></li>
                                                                <li><a href="03_01_02_right_sidebar.html">Right Sidebar</a></li>
                                                                <li><a href="03_01_03_without_sidebar.html">Without Sidebar</a></li>
                                                            </ul>
                                                        </li>
                                                        <li class="has-sub"><a href="#">Single Post</a>
                                                            <ul>
                                                                <li><a href="03_02_01_image_post.html">Image Post</a></li>
                                                                <li><a href="03_02_02_slide_post.html">Slide Post</a></li>
                                                                <li><a href="03_02_03_video_post.html">Video Post</a></li>
                                                                <li><a href="03_02_04_post_full_width.html">Post Full</a></li>
                                                                <li><a href="03_02_05_post_no_sidebar.html">Post No Sidebar</a></li>
                                                            </ul>
                                                        </li>
                                                        <li class="has-sub"><a href="#">Search Results</a>
                                                            <ul>
                                                                <li><a href="03_03_01_search_results_list.html">Search Result List</a></li>
                                                                <li><a href="03_03_02_search_results_grid.html">Search Result Grid</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="has-sub"><a href='#'>Category</a>
                                                    <ul>
                                                        <li><a href="02_01_list.html">List</a></li>
                                                        <li><a href="02_02_list.html">List 2</a></li>
                                                        <li><a href="02_03_grid_2_columns.html">Grid 2 Columns</a></li>
                                                        <li><a href="02_04_grid_2_columns_2.html">Grid 2 Columns 2</a></li>
                                                        <li><a href="02_05_mixed.html">Mixed</a></li>
                                                    </ul>
                                                </li>
                                                <li class="has-sub"><a href='#'>pages</a>
                                                    <ul>
                                                        <li><a href="04_01_about.html">About</a></li>
                                                        <li><a href="04_02_contact.html">Contact</a></li>
                                                        <li><a href="04_03_404page.html">404 Page</a></li>
                                                    </ul>
                                                </li>
                                                <li class="has-sub"><a href='#'>shop</a>
                                                    <ul>
                                                        <li><a href="05_01_shop.html">Shop</a></li>
                                                        <li><a href="05_02_single_product.html">Single Product</a></li>
                                                        <li><a href="05_03_cart.html">Cart</a></li>
                                                        <li><a href="05_04_checkout.html">Checkout</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-1">
                                        <div class="vk-bottom-header-search toggle-form">
                                            <i class="fa fa-search" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                                <!--Form search-->
                                <div class="form-search-wrapper">
                                    <div class="input-group">
                                        <input type="text" class="form-control" placeholder="Search">
                                        <span class="input-group-addon success"><i class="fa fa-search"></i></span>
                                    </div>
                                </div>
                                <!--MEGA MENU 2-->
                                <div class="uni-mega-menu-2 animated">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <h4>Home pages</h4>
                                            <ul>
                                                <li><a href="index-2.html">Home Default</a></li>
                                                <li><a href="01_02_fashion.html">Fashion News</a></li>
                                                <li><a href="01_03_sport.html">Sport News</a></li>
                                                <li><a href="01_04_techology.html">Tech News</a></li>
                                                <li><a href="01_05_video.html">Video News</a></li>
                                            </ul>
                                        </div>
                                        <div class="col-md-3">
                                            <h4>PAGES</h4>
                                            <ul>
                                                <li><a href="04_01_about.html">About</a></li>
                                                <li><a href="04_02_contact.html">Contact</a></li>
                                                <li><a href="04_03_404page.html">404 Page</a></li>
                                                <li><a href="03_03_01_search_results_list.html">Search Result List</a></li>
                                                <li><a href="03_03_02_search_results_grid.html">Search Result Grid</a></li>
                                            </ul>
                                        </div>
                                        <div class="col-md-3">
                                            <h4>Categories</h4>
                                            <ul>
                                                <li><a href="#">Economy</a></li>
                                                <li><a href="#">Sport</a></li>
                                                <li><a href="#">Fashion</a></li>
                                                <li><a href="#">Music</a></li>
                                                <li><a href="#">Video</a></li>
                                            </ul>
                                        </div>
                                        <div class="col-md-3">
                                            <h4>Shortcode</h4>
                                            <ul>
                                                <li><a href="#">Buttons</a></li>
                                                <li><a href="#">Typogarphy</a></li>
                                                <li><a href="#">Tabs</a></li>
                                                <li><a href="#">Icons</a></li>
                                                <li><a href="#">Headers</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <!--MEGA MENU 1-->
                                <div class="uni-mega-menu-1">
                                    <!--MEGA MENU 1 SPORT-->
                                    <div class="uni-mega-menu-1-sport animated">
                                        <div class="uni-mega-menu-1-left">
                                            <ul class="nav nav-pills">
                                                <li class="active"><a href="#tab-1" data-toggle="tab" data-hover="tab">FootBall</a></li>
                                                <li><a href="#tab-2" data-toggle="tab" data-hover="tab">Tennis</a></li>
                                                <li><a href="#tab-3" data-toggle="tab" data-hover="tab">Golf</a></li>
                                                <li><a href="#tab-4" data-toggle="tab" data-hover="tab">Moto Racing</a></li>
                                                <li><a href="#tab-5" data-toggle="tab" data-hover="tab">Basketball</a></li>
                                                <li><a href="#tab-6" data-toggle="tab" data-hover="tab">Hockey</a></li>
                                            </ul>
                                        </div>
                                        <div class="uni-mega-menu-1-right">
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="tab-1">
                                                    <div id="uni-mega-menu-tab-sport-1" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img22.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img24.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img25.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-2">
                                                    <div id="uni-mega-menu-tab-sport-2" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img22.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img24.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img25.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-3">
                                                    <div id="uni-mega-menu-tab-sport-3" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img22.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img24.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img25.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-4">
                                                    <div id="uni-mega-menu-tab-sport-4" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img22.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img24.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img25.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-5">
                                                    <div id="uni-mega-menu-tab-sport-5" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img22.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img24.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img25.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-6">
                                                    <div id="uni-mega-menu-tab-sport-6" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img22.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <div class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img24.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img25.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--MEGA MENU Economy-->
                                    <div class="uni-mega-menu-1-economy animated">
                                        <div class="uni-mega-menu-1-left">
                                            <ul class="nav nav-pills">
                                                <li class="active"><a href="#tab-eco-1" data-toggle="tab" data-hover="tab">Stock</a></li>
                                                <li><a href="#tab-eco-2" data-toggle="tab" data-hover="tab">Finance</a></li>
                                                <li><a href="#tab-eco-3" data-toggle="tab" data-hover="tab">Business</a></li>
                                                <li><a href="#tab-eco-4" data-toggle="tab" data-hover="tab">Labor - Job</a></li>
                                                <li><a href="#tab-eco-5" data-toggle="tab" data-hover="tab">Basketball</a></li>
                                                <li><a href="#tab-eco-6" data-toggle="tab" data-hover="tab">Hockey</a></li>
                                            </ul>
                                        </div>
                                        <div class="uni-mega-menu-1-right">
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="tab-eco-1">
                                                    <div id="uni-mega-menu-tab-eco-1" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/homepage1/sec-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-eco-2">
                                                    <div id="uni-mega-menu-tab-eco-2" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/homepage1/sec-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-eco-3">
                                                    <div id="uni-mega-menu-tab-eco-3" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/homepage1/sec-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-eco-4">
                                                    <div id="uni-mega-menu-tab-eco-4" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/homepage1/sec-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-eco-5">
                                                    <div id="uni-mega-menu-tab-eco-5" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/homepage1/sec-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-eco-6">
                                                    <div id="uni-mega-menu-tab-eco-6" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/homepage1/sec-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--MEGA MENU FASHION-->
                                    <div class="uni-mega-menu-1-fashion animated">
                                        <div class="uni-mega-menu-1-left">
                                            <ul class="nav nav-pills">
                                                <li class="active"><a href="#tab-fas-1" data-toggle="tab" data-hover="tab">Fashion +</a></li>
                                                <li><a href="#tab-fas-2" data-toggle="tab" data-hover="tab">Fashion Star</a></li>
                                                <li><a href="#tab-fas-3" data-toggle="tab" data-hover="tab">Model</a></li>
                                                <li><a href="#tab-fas-4" data-toggle="tab" data-hover="tab">Design</a></li>
                                                <li><a href="#tab-fas-5" data-toggle="tab" data-hover="tab">Fashion man</a></li>
                                                <li><a href="#tab-fas-6" data-toggle="tab" data-hover="tab">Fashion Unisex</a></li>
                                            </ul>
                                        </div>
                                        <div class="uni-mega-menu-1-right">
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="tab-fas-1">
                                                    <div id="uni-mega-menu-tab-fas-1" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-fas-2">
                                                    <div id="uni-mega-menu-tab-fas-2" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-fas-3">
                                                    <div id="uni-mega-menu-tab-fas-3" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-fas-4">
                                                    <div id="uni-mega-menu-tab-fas-4" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-fas-5">
                                                    <div id="uni-mega-menu-tab-fas-5" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-fas-6">
                                                    <div id="uni-mega-menu-tab-fas-6" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/fas5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--MEGA MENU MUSIC-->
                                    <div class="uni-mega-menu-1-music animated">
                                        <div class="uni-mega-menu-1-left">
                                            <ul class="nav nav-pills">
                                                <li class="active"><a href="#tab-mus-1" data-toggle="tab" data-hover="tab">Pop Music</a></li>
                                                <li><a href="#tab-mus-2" data-toggle="tab" data-hover="tab">EDM Music</a></li>
                                                <li><a href="#tab-mus-3" data-toggle="tab" data-hover="tab">Rap Music</a></li>
                                                <li><a href="#tab-mus-4" data-toggle="tab" data-hover="tab">Rock Music</a></li>
                                                <li><a href="#tab-mus-5" data-toggle="tab" data-hover="tab">Underground</a></li>
                                                <li><a href="#tab-mus-6" data-toggle="tab" data-hover="tab">R&B Music</a></li>
                                            </ul>
                                        </div>
                                        <div class="uni-mega-menu-1-right">
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="tab-mus-1">
                                                    <div id="uni-mega-menu-tab-mus-1" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-mus-2">
                                                    <div id="uni-mega-menu-tab-mus-2" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-mus-3">
                                                    <div id="uni-mega-menu-tab-mus-3" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-mus-4">
                                                    <div id="uni-mega-menu-tab-mus-4" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-mus-5">
                                                    <div id="uni-mega-menu-tab-mus-5" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-mus-6">
                                                    <div id="uni-mega-menu-tab-mus-6" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--MEGA MENU VIDEO-->
                                    <div class="uni-mega-menu-1-video animated">
                                        <div class="uni-mega-menu-1-left">
                                            <ul class="nav nav-pills">
                                                <li class="active"><a href="#tab-vid-1" data-toggle="tab" data-hover="tab">Video Economy</a></li>
                                                <li><a href="#tab-vid-2" data-toggle="tab" data-hover="tab">Video Sport</a></li>
                                                <li><a href="#tab-vid-3" data-toggle="tab" data-hover="tab">Video Fashion</a></li>
                                                <li><a href="#tab-vid-4" data-toggle="tab" data-hover="tab">Video Music</a></li>
                                                <li><a href="#tab-vid-5" data-toggle="tab" data-hover="tab">Underground</a></li>
                                                <li><a href="#tab-vid-6" data-toggle="tab" data-hover="tab">R&B Music</a></li>
                                            </ul>
                                        </div>
                                        <div class="uni-mega-menu-1-right">
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="tab-vid-1">
                                                    <div id="uni-mega-menu-tab-video-1" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-vid-2">
                                                    <div id="uni-mega-menu-tab-video-2" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-vid-3">
                                                    <div id="uni-mega-menu-tab-video-3" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-vid-4">
                                                    <div id="uni-mega-menu-tab-video-4" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-vid-5">
                                                    <div id="uni-mega-menu-tab-video-5" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-vid-6">
                                                    <div id="uni-mega-menu-tab-video-6" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <div id="main-content" class="site-main-content">
            <div id="home-main-content" class="site-home-main-content">
                <div id="vk-home-default-slide">
                    <div class="container-fluid">
                        <div class="row">
                            <!--HOME 1 SLIDE-->
                            <div id="uni-home-defaults-slide">
                                <div id="vk-owl-demo-singer-slider" class="owl-carousel owl-theme">
                                    <div class="item">
                                        <div class="uni-item-img-1"></div>
                                        <!--                        <img src="image/slideshow/center.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">LIFESTYLE</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="03_02_01_image_post.html">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <span class="time"> June 21, 2017</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="uni-item-img-2"></div>
                                        <!--                        <img src="image/slideshow/right.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">SPORT</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="03_02_01_image_post.html">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <span class="time"> June 21, 2017</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="uni-item-img-3"></div>
                                        <!--                        <img src="image/slideshow/left.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">TRAVEL</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="03_02_01_image_post.html">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <span class="time"> June 21, 2017</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="vk-home-default-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8">
                                <div id="vk-home-default-left">

                                    <!--HOME DEFAULT HOT NEWS-->
                                    <div class="vk-home-section-hotnews">
                                        <div class="tab-default tabbable-panel">
                                            <div class="tabbable-line">
                                                <div class="uni-sticker-label">
                                                    <div class="label-info">
                                                        <a href="#">
                                                            <img src="image/homepage1/icon/fire.png" alt="" class="img-responsive img-gen">
                                                            <img src="image/fire-red.png" alt="" class="img-responsive img-hover">
                                                            <span class="label-title">Hot News</span>
                                                        </a>
                                                    </div>
                                                    <!--Tab show destop-->
                                                    <ul class="visible-sm visible-md visible-lg nav nav-tabs ">
                                                        <li class="active">
                                                            <a href="#tab_default_1" data-toggle="tab">Economy </a>
                                                        </li>
                                                        <li>
                                                            <a href="#tab_default_2" data-toggle="tab">Sport </a>
                                                        </li>
                                                        <li>
                                                            <a href="#tab_default_3" data-toggle="tab">Fashion </a>
                                                        </li>
                                                        <li>
                                                            <a href="#tab_default_4" data-toggle="tab">Music </a>
                                                        </li>
                                                        <li>
                                                            <a href="#tab_default_5" data-toggle="tab">Video </a>
                                                        </li>
                                                    </ul>

                                                    <!--Tab show mobiles-->
                                                    <div class="btn btn-select btn-select-light">
                                                        <input type="hidden" class="btn-select-input" name="hot-news-input" value="" />
                                                        <span class="btn-select-value">Economy</span>
                                                        <span class='btn-select-arrow'><i class="fa fa-angle-down" aria-hidden="true"></i></span>
                                                        <ul>
                                                            <li><a href="#tab_default_1" data-toggle="tab">Economy </a></li>
                                                            <li><a href="#tab_default_2" data-toggle="tab">Sport </a></li>
                                                            <li><a href="#tab_default_3" data-toggle="tab">Fashion </a></li>
                                                            <li><a href="#tab_default_4" data-toggle="tab">Music </a></li>
                                                            <li><a href="#tab_default_5" data-toggle="tab">Video </a></li>
                                                        </ul>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tab_default_1">
                                                        <div class="vk-section1-eco">
                                                            <div id="uni-home-default-hotnews-economy-slide" class="owl-carousel owl-theme">
                                                                <div class="item">
                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_04_techology/sec-4/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_04_techology/sec-4/img-5.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_04_techology/sec-4/img-7.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="item">
                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/homepage1/img1.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/homepage1/img.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/homepage1/img2.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane" id="tab_default_2">
                                                        <div class="vk-section1-eco">
                                                            <div id="uni-home-default-hotnews-sport-slide" class="owl-carousel owl-theme">
                                                                <div class="item">
                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_03_sport/sec-4/img.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_03_sport/sec-4/img1.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_03_sport/sec-4/img-1.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="item">
                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_03_sport/sec-4/img2.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_03_sport/sec-4/img-2.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_03_sport/sec-4/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane" id="tab_default_3">
                                                        <div class="vk-section1-eco">

                                                            <div id="uni-home-default-hotnews-fashion-slide" class="owl-carousel owl-theme">
                                                                <div class="item">
                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_02_fashion/sec-2/img.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_02_fashion/sec-2/img-9.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_02_fashion/sec-2/img-8.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="item">
                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_02_fashion/sec-2/img-7.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_02_fashion/sec-2/img-6.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_02_fashion/sec-2/img-5.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane" id="tab_default_4">
                                                        <div class="vk-section1-eco">
                                                            <div id="uni-home-default-hotnews-music-slide" class="owl-carousel owl-theme">
                                                                <div class="item">
                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_05_video/sec-3/img-8.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_05_video/sec-3/img-7.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/01_05_video/sec-3/img-6.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="item">
                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/homepage1/img1.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/homepage1/img.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="vk-section1-eco-img">
                                                                                    <a href="03_02_01_image_post.html"><img src="image/homepage1/img2.jpg" alt="" class="img-responsive"></a>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane" id="tab_default_5">
                                                        <div class="vk-section1-eco">
                                                            <div id="uni-home-default-hotnews-video-slide" class="owl-carousel owl-theme">
                                                                <div class="item">
                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="uni-play-img vk-section1-eco-img">
                                                                                    <a href="03_02_03_video_post.html"><img src="image/homepage1/img2.jpg" alt="" class="img-responsive"></a>
                                                                                    <div class="uni-play">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                    </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="uni-play-img vk-section1-eco-img">
                                                                                    <a href="03_02_03_video_post.html"><img src="image/homepage1/img1.jpg" alt="" class="img-responsive"></a>
                                                                                    <div class="uni-play">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                    </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="uni-play-img vk-section1-eco-img">
                                                                                    <a href="03_02_03_video_post.html"><img src="image/homepage1/img2.jpg" alt="" class="img-responsive"></a>
                                                                                    <div class="uni-play">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                    </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="item">
                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="uni-play-img vk-section1-eco-img">
                                                                                    <a href="03_02_03_video_post.html"><img src="image/homepage1/img1.jpg" alt="" class="img-responsive"></a>
                                                                                    <div class="uni-play">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                    </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="uni-play-img vk-section1-eco-img">
                                                                                    <a href="03_02_03_video_post.html"><img src="image/homepage1/img.jpg" alt="" class="img-responsive"></a>
                                                                                    <div class="uni-play">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                    </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>

                                                                    <div class="vk-section1-eco-item">
                                                                        <ul>
                                                                            <li>
                                                                                <div class="uni-play-img vk-section1-eco-img">
                                                                                    <a href="03_02_03_video_post.html"><img src="image/homepage1/img2.jpg" alt="" class="img-responsive"></a>
                                                                                    <div class="uni-play">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                    </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="vk-section-content">
                                                                                    <div class="vk-section1-eco-title">
                                                                                        <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                                fames ac turpis egestas</a></h2>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-time">
                                                                                        <ul>
                                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                            <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                            <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="vk-section1-eco-text">
                                                                                        <p>
                                                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                                                                                            Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante...
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </li>
                                                                        </ul>
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--HOME DEFAULT ECONOMY-->
                                    <div class="vk-home-section-economy">
                                        <div class="tab-default tabbable-panel">
                                            <div class="tabbable-line">
                                                <div class="uni-sticker-label">
                                                    <div class="label-info">
                                                        <a href="#">
                                                            <img src="image/homepage1/icon/data.png" alt="" class="img-responsive img-gen">
                                                            <img src="image/eco-red.png" alt="" class="img-responsive img-hover">
                                                            <span class="label-title">Economy</span>
                                                        </a>
                                                    </div>
                                                    <!--Tab show destop-->
                                                    <ul class="visible-sm visible-md visible-lg nav nav-tabs ">
                                                        <li class="active"><a href="#tab_sec-2_1" data-toggle="tab">Newest </a></li>
                                                        <li><a href="#tab_sec-2_2" data-toggle="tab">Popular </a></li>
                                                    </ul>

                                                    <!--Tab show mobiles-->
                                                    <div class="btn btn-select btn-select-light">
                                                        <input type="hidden" class="btn-select-input" name="economy-input" value="" />
                                                        <span class="btn-select-value">Newest</span>
                                                        <span class='btn-select-arrow'><i class="fa fa-angle-down" aria-hidden="true"></i></span>
                                                        <ul>
                                                            <li><a href="#tab_sec-2_1" data-toggle="tab">Newest </a></li>
                                                            <li><a href="#tab_sec-2_2" data-toggle="tab">Popular </a></li>
                                                        </ul>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>

                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tab_sec-2_1">
                                                        <div id="uni-home-default-economy-newest-slide" class="owl-carousel owl-theme">
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-2.jpg" alt=""></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img5.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img6.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img7.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/01_04_techology/sec-4/img-5.jpg" alt=""></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img5.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img6.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img7.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane" id="tab_sec-2_2">
                                                        <div id="uni-home-default-economy-popular-slide" class="owl-carousel owl-theme">
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/slideshow/img.jpg" alt="" class="img-responsive"></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img5.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img6.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img7.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/01_02_fashion/sec-2/img-8.jpg" alt="" class="img-responsive"></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img5.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img6.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img7.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <!--HOME DEFAULT SPORT-->
                                    <div class="vk-home-section-sport">
                                        <div class="tab-default tabbable-panel">
                                            <div class="tabbable-line">
                                                <div class="uni-sticker-label">
                                                    <div class="label-info">
                                                        <a href="#">
                                                            <img src="image/homepage1/icon/ball.png" alt="" class="img-responsive img-gen">
                                                            <img src="image/sport-red.png" alt="" class="img-responsive img-hover">
                                                            <span class="label-title">Sport</span>
                                                        </a>
                                                    </div>
                                                    <!--Tab show destop-->
                                                    <ul class="visible-sm visible-md visible-lg nav nav-tabs ">
                                                        <li class="active"><a href="#tab_sec-3_1" data-toggle="tab">Newest </a></li>
                                                        <li><a href="#tab_sec-3_2" data-toggle="tab">Popular </a></li>
                                                    </ul>

                                                    <!--Tab show mobiles-->
                                                    <div class="btn btn-select btn-select-light">
                                                        <input type="hidden" class="btn-select-input" name="sport-input" value="" />
                                                        <span class="btn-select-value">Newest</span>
                                                        <span class='btn-select-arrow'><i class="fa fa-angle-down" aria-hidden="true"></i></span>
                                                        <ul>
                                                            <li><a href="#tab_sec-3_1" data-toggle="tab">Newest </a></li>
                                                            <li><a href="#tab_sec-3_2" data-toggle="tab">Popular </a></li>
                                                        </ul>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tab_sec-3_1">

                                                        <div id="uni-home-default-sport-newest-slide" class="owl-carousel owl-theme">
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/homepage1/abc/img-5.jpg" alt=""></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/abc/img-2.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/abc/img-3.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/abc/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/01_03_sport/sec-4/img1.jpg" alt=""></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/abc/img-2.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/abc/img-3.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/abc/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane" id="tab_sec-3_2">
                                                        <div id="uni-home-default-sport-popular-slide" class="owl-carousel owl-theme">
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/slideshow/img.jpg" alt="" class="img-responsive"></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img5.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img6.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img7.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/01_03_sport/sec-4/img.jpg" alt=""  class="img-responsive"></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img5.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img6.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img7.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--HOME DEFAULT FASHION-->
                                    <div class="vk-home-section-fashion">
                                        <div class="tab-default tabbable-panel">
                                            <div class="tabbable-line">
                                                <div class="uni-sticker-label">
                                                    <div class="label-info">
                                                        <a href="#">
                                                            <img src="image/homepage1/icon/fashion.png" alt="" class="img-responsive img-gen">
                                                            <img src="image/fas-red.png" alt="" class="img-responsive img-hover">
                                                            <span class="label-title">Fashion</span>
                                                        </a>
                                                    </div>
                                                    <!--Tab show destop-->
                                                    <ul class="visible-sm visible-md visible-lg nav nav-tabs ">
                                                        <li class="active">
                                                            <a href="#tab_sec-4_1" data-toggle="tab">Newest </a>
                                                        </li>
                                                        <li>
                                                            <a href="#tab_sec-4_2" data-toggle="tab">Popular </a>
                                                        </li>
                                                    </ul>

                                                    <!--Tab show mobiles-->
                                                    <div class="btn btn-select btn-select-light">
                                                        <input type="hidden" class="btn-select-input" name="fashion-input" value="" />
                                                        <span class="btn-select-value">Newest</span>
                                                        <span class='btn-select-arrow'><i class="fa fa-angle-down" aria-hidden="true"></i></span>
                                                        <ul>
                                                            <li>
                                                                <a href="#tab_sec-4_1" data-toggle="tab">Newest </a>
                                                            </li>
                                                            <li>
                                                                <a href="#tab_sec-4_2" data-toggle="tab">Popular </a>
                                                            </li>
                                                        </ul>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tab_sec-4_1">

                                                        <div id="uni-home-default-fashion-newest-slide" class="owl-carousel owl-theme">
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/homepage1/img-5.jpg" alt=""></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img-2.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img-3.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/homepage1/img9.jpg" alt=""></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img-2.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img-3.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane" id="tab_sec-4_2">

                                                        <div id="uni-home-default-fashion-popular-slide" class="owl-carousel owl-theme">
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/01_02_fashion/img21.jpg" alt=""></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img-2.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img-3.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/01_02_fashion/img3.jpg" alt=""></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img-2.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img-3.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--HOME DEFAULTS MUSIC-->
                                    <div class="vk-home-section-music">
                                        <div class="tab-default tabbable-panel">
                                            <div class="tabbable-line">
                                                <div class="uni-sticker-label">
                                                    <div class="label-info">
                                                        <a href="#">
                                                            <img src="image/homepage1/icon/music.png" alt="" class="img-responsive img-gen">
                                                            <img src="image/mus-red.png" alt="" class="img-responsive img-hover">
                                                            <span class="label-title">Music</span>
                                                        </a>
                                                    </div>
                                                    <!--Tab show destop-->
                                                    <ul class="visible-sm visible-md visible-lg nav nav-tabs ">
                                                        <li class="active">
                                                            <a href="#tab_sec-5_1" data-toggle="tab">Newest </a>
                                                        </li>
                                                        <li>
                                                            <a href="#tab_sec-5_2" data-toggle="tab">Popular </a>
                                                        </li>
                                                    </ul>

                                                    <!--Tab show mobiles-->
                                                    <div class="btn btn-select btn-select-light">
                                                        <input type="hidden" class="btn-select-input" name="music-input" value="" />
                                                        <span class="btn-select-value">Newest</span>
                                                        <span class='btn-select-arrow'><i class="fa fa-angle-down" aria-hidden="true"></i></span>
                                                        <ul>
                                                            <li>
                                                                <a href="#tab_sec-5_1" data-toggle="tab">Newest </a>
                                                            </li>
                                                            <li>
                                                                <a href="#tab_sec-5_2" data-toggle="tab">Popular </a>
                                                            </li>
                                                        </ul>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tab_sec-5_1">
                                                        <div id="uni-home-default-music-newest-slide" class="owl-carousel owl-theme">
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-5/img-5.jpg" alt=""></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-5/img-2.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-5/img-3.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-5/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/slideshow/img.jpg" alt=""></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-5/img-2.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-5/img-3.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-5/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane" id="tab_sec-5_2">
                                                        <div id="uni-home-default-music-popular-slide" class="owl-carousel owl-theme">
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/01_04_techology/sec-4/img-5.jpg" alt=""></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-5/img-2.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-5/img-3.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-5/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="vk-sec-2-left-img">
                                                                                <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-5/img-5.jpg" alt=""></a>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-5/img-2.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-5/img-3.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/sec-5/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="vk-sec-2-eco-img">
                                                                                        <a href="03_02_01_image_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_01_image_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--HOME DEFAULTS VIDEO-->
                                    <div class="vk-home-section-video">
                                        <div class="tab-default tabbable-panel">
                                            <div class="tabbable-line">
                                                <div class="uni-sticker-label">
                                                    <div class="label-info">
                                                        <a href="#">
                                                            <img src="image/homepage1/icon/video.png" alt="" class="img-responsive img-gen">
                                                            <img src="image/video-red.png" alt="" class="img-responsive img-hover">
                                                            <span class="label-title">Video</span>
                                                        </a>
                                                    </div>
                                                    <!--Tab show destop-->
                                                    <ul class="visible-sm visible-md visible-lg nav nav-tabs ">
                                                        <li class="active">
                                                            <a href="#tab_sec-6_1" data-toggle="tab">Newest </a>
                                                        </li>
                                                        <li>
                                                            <a href="#tab_sec-6_2" data-toggle="tab">Popular </a>
                                                        </li>
                                                    </ul>

                                                    <!--Tab show mobiles-->
                                                    <div class="btn btn-select btn-select-light">
                                                        <input type="hidden" class="btn-select-input" name="video-input" value="" />
                                                        <span class="btn-select-value">Newest</span>
                                                        <span class='btn-select-arrow'><i class="fa fa-angle-down" aria-hidden="true"></i></span>
                                                        <ul>
                                                            <li>
                                                                <a href="#tab_sec-6_1" data-toggle="tab">Newest </a>
                                                            </li>
                                                            <li>
                                                                <a href="#tab_sec-6_2" data-toggle="tab">Popular </a>
                                                            </li>
                                                        </ul>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tab_sec-6_1">

                                                        <div id="uni-home-default-video-newest-slide" class="owl-carousel owl-theme">
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="uni-play-img vk-sec-2-left-img">
                                                                                <a href="03_02_03_video_post.html"><img src="image/homepage1/sec-6/img-5.jpg" alt=""></a>
                                                                                <div class="uni-play">
                                                                                    <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/sec-6/img-2.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/sec-6/img-3.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/sec-6/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="uni-play-img vk-sec-2-left-img">
                                                                                <a href="03_02_03_video_post.html"><img src="image/01_02_fashion/sec-2/img.jpg" alt=""></a>
                                                                                <div class="uni-play">
                                                                                    <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/sec-6/img-2.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/sec-6/img-3.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/sec-6/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane" id="tab_sec-6_2">
                                                        <div id="uni-home-default-video-popular-slide" class="owl-carousel owl-theme">
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="uni-play-img vk-sec-2-left-img">
                                                                                <a href="03_02_03_video_post.html"><img src="image/slideshow/img.jpg" alt=""  class="img-responsive"></a>
                                                                                <div class="uni-play">
                                                                                    <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/img5.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/img6.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/img7.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-left">
                                                                            <div class="uni-play-img vk-sec-2-left-img">
                                                                                <a href="03_02_03_video_post.html"><img src="image/01_02_fashion/sec-2/img-1.jpg" alt=""></a>
                                                                                <div class="uni-play">
                                                                                    <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="vk-sec-2-left-content">
                                                                                <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristique senectus
                                                                                        et netus et malesuada fames ac turpis egestas</a></h2>
                                                                                <div class="vk-sec-2-left-time">
                                                                                    <ul>
                                                                                        <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                        <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                        <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="vk-sec-2-left-text">
                                                                                    <p>
                                                                                        Pellentesque habitant morbi tristique senectus et netus et malesuada
                                                                                        fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget,
                                                                                        tempor sit amet, ante. Donec eu libero sit amet quam egestas semper...
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/sec-6/img-2.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/sec-6/img-3.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/img4.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/sec-6/img-4.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>

                                                                        <div class="vk-home-section-2-right">
                                                                            <ul>
                                                                                <li>
                                                                                    <div class="uni-play-img vk-sec-2-eco-img">
                                                                                        <a href="03_02_03_video_post.html"><img src="image/homepage1/img8.jpg" alt="" class="img-responsive"></a>
                                                                                        <div class="uni-play">
                                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt=""></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <div class="vk-sec-2-content">
                                                                                        <div class="vk-sec-2-title">
                                                                                            <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                                        </div>
                                                                                        <div class="vk-sec-2-time">
                                                                                            <span class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</span>
                                                                                        </div>
                                                                                    </div>

                                                                                </li>
                                                                            </ul>
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <aside class="col-md-4">
                                <aside class="widget-area">

                                    <aside class="widget">
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-ad">
                                                <a href="#">
                                                    <img src="image/ad-sidebar.jpg" alt="ad-sidebar" class="img-responsive">
                                                </a>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <h3 class="widget-title">Editor Picks</h3>
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-ep">
                                                <div id="vk-owl-ep-slider" class="owl-carousel owl-theme">
                                                    <div class="item">
                                                        <ul>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img.jpg" alt="img"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img-1.jpg" alt="img-1"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img-2.jpg" alt="img-2"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img-3.jpg" alt="img-3"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img-4.jpg" alt="img-4"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="item">
                                                        <ul>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img.jpg" alt="img"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img-1.jpg" alt="img-1"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img-2.jpg" alt="img-2"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img-3.jpg" alt="img-3"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img-4.jpg" alt="img-4"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="item">
                                                        <ul>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img.jpg" alt="img"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img-1.jpg" alt="img-1"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img-2.jpg" alt="img-2"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img-3.jpg" alt="img-3"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-ep">
                                                                    <div class="vk-item-ep-img">
                                                                        <a href="#"><img src="image/siderbar/img-4.jpg" alt="ìm-4"></a>
                                                                    </div>
                                                                    <div class="vk-item-ep-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-ep-time">
                                                                            <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-facebook">
                                                <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ffacebook&amp;tabs=timeline&amp;width=340&amp;height=500&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId" width="340" height="500" style="border:none;overflow:hidden"></iframe>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <h3 class="widget-title">Feature Videos</h3>
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-fea">
                                                <div id="vk-owl-fea-slider" class="owl-carousel owl-theme">
                                                    <div class="item">
                                                        <ul>
                                                            <li>
                                                                <div class="vk-item-fea">
                                                                    <div class="uni-play-img vk-item-fea-img">
                                                                            <!--                                            <iframe width="560" height="315" src="https://www.youtube.com/embed/v-Dur3uXXCQ" frameborder="0" allowfullscreen></iframe>-->
                                                                        <a href="03_02_03_video_post.html"><img src="image/slideshow/img-2.jpg" alt="img-2"></a>
                                                                        <div class="uni-play">
                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="vk-item-fea-text">
                                                                        <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-fea-time">
                                                                            <ul>
                                                                                <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-fea">
                                                                    <div class="uni-play-img vk-item-fea-img">
                                                                            <!--                                            <iframe width="560" height="315" src="https://www.youtube.com/embed/WyiIGEHQP8o" frameborder="0" allowfullscreen></iframe>-->
                                                                        <a href="03_02_03_video_post.html"><img src="image/slideshow/img-1.jpg" alt="img-1"></a>
                                                                        <div class="uni-play"><a href="03_02_03_video_post.html"><img src="image/play.png" alt="" class="img-responsive"></a></div>
                                                                    </div>
                                                                    <div class="vk-item-fea-text">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-fea-time">
                                                                            <ul>
                                                                                <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-fea">
                                                                    <div class="uni-play-img vk-item-fea-img">
                                                                            <!--                                            <iframe width="560" height="315" src="https://www.youtube.com/embed/zEkg4GBQumc" frameborder="0" allowfullscreen></iframe>-->
                                                                        <a href="03_02_03_video_post.html"><img src="image/slideshow/img.jpg" alt="img"></a>
                                                                        <div class="uni-play">
                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="vk-item-fea-text">
                                                                        <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-fea-time">
                                                                            <ul>
                                                                                <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="item">
                                                        <ul>
                                                            <li>
                                                                <div class="vk-item-fea">
                                                                    <div class="uni-play-img vk-item-fea-img">
                                                                            <!--                                            <iframe width="560" height="315" src="https://www.youtube.com/embed/v-Dur3uXXCQ" frameborder="0" allowfullscreen></iframe>-->
                                                                        <a href="03_02_03_video_post.html"><img src="image/slideshow/img-2.jpg" alt="img-2"></a>
                                                                        <div class="uni-play">
                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="vk-item-fea-text">
                                                                        <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-fea-time">
                                                                            <ul>
                                                                                <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-fea">
                                                                    <div class="uni-play-img vk-item-fea-img">
                                                                            <!--                                            <iframe width="560" height="315" src="https://www.youtube.com/embed/WyiIGEHQP8o" frameborder="0" allowfullscreen></iframe>-->
                                                                        <a href="03_02_03_video_post.html"><img src="image/slideshow/img-1.jpg" alt="img-1"></a>
                                                                        <div class="uni-play">
                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="vk-item-fea-text">
                                                                        <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-fea-time">
                                                                            <ul>
                                                                                <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-fea">
                                                                    <div class="uni-play-img vk-item-fea-img">
                                                                            <!--                                            <iframe width="560" height="315" src="https://www.youtube.com/embed/zEkg4GBQumc" frameborder="0" allowfullscreen></iframe>-->
                                                                        <a href="03_02_03_video_post.html"><img src="image/slideshow/img.jpg" alt="img"></a>
                                                                        <div class="uni-play">
                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="vk-item-fea-text">
                                                                        <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-fea-time">
                                                                            <ul>
                                                                                <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="item">
                                                        <ul>
                                                            <li>
                                                                <div class="vk-item-fea">
                                                                    <div class="uni-play-img vk-item-fea-img">
                                                                            <!--                                            <iframe width="560" height="315" src="https://www.youtube.com/embed/v-Dur3uXXCQ" frameborder="0" allowfullscreen></iframe>-->
                                                                        <a href="03_02_03_video_post.html"><img src="image/slideshow/img-2.jpg" alt="img-2"></a>
                                                                        <div class="uni-play">
                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="vk-item-fea-text">
                                                                        <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-fea-time">
                                                                            <ul>
                                                                                <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-fea">
                                                                    <div class="uni-play-img vk-item-fea-img">
                                                                            <!--                                            <iframe width="560" height="315" src="https://www.youtube.com/embed/WyiIGEHQP8o" frameborder="0" allowfullscreen></iframe>-->
                                                                        <a href="#"><img src="image/slideshow/img-1.jpg" alt="img-1"></a>
                                                                        <div class="uni-play">
                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="vk-item-fea-text">
                                                                        <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-fea-time">
                                                                            <ul>
                                                                                <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-item-fea">
                                                                    <div class="uni-play-img vk-item-fea-img">
                                                                            <!--                                            <iframe width="560" height="315" src="https://www.youtube.com/embed/zEkg4GBQumc" frameborder="0" allowfullscreen></iframe>-->
                                                                        <a href="03_02_03_video_post.html"><img src="image/slideshow/img.jpg" alt="img"></a>
                                                                        <div class="uni-play">
                                                                            <a href="03_02_03_video_post.html"><img src="image/play.png" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="vk-item-fea-text">
                                                                        <h2><a href="03_02_03_video_post.html">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                        <div class="vk-item-fea-time">
                                                                            <ul>
                                                                                <li><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</li>
                                                                                <li><i class="fa fa-eye-slash" aria-hidden="true"></i> 2134 views</li>
                                                                                <li><i class="fa fa-comments-o" aria-hidden="true"></i> 30 Comments</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <h3 class="widget-title">Stay Connected</h3>
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-stay">
                                                <div class="vk-right-stay-body">
                                                    <a class="btn btn-block btn-social btn-facebook">
                                                        <span class="icon"><i class="fa fa-facebook"></i></span>
                                                        <span class="info"> 2134 Like</span>
                                                        <span class="text">Like</span>
                                                    </a>
                                                    <a class="btn btn-block btn-social btn-twitter">
                                                        <span class="icon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                                                        <span class="info"> 13634 Follows</span>
                                                        <span class="text">Follows</span>
                                                    </a>
                                                    <a class="btn btn-block btn-social btn-youtube">
                                                        <span class="icon"><i class="fa fa-youtube-play" aria-hidden="true"></i></span>
                                                        <span class="info">10634 Subscribers</span>
                                                        <span class="text">Subscribe</span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-ad">
                                                <a href="#">
                                                    <img src="image/ad-sidebar.jpg" alt="ad-sidebar" class="img-responsive">
                                                </a>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <h3 class="widget-title">Tags Clound</h3>
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-tags">
                                                <ul>
                                                    <li><a href="#">LifeStyle</a></li>
                                                    <li><a href="#">Sport</a></li>
                                                    <li><a href="#">Economy</a></li>
                                                    <li><a href="#">Business</a></li>
                                                    <li><a href="#">Travel</a></li>
                                                    <li><a href="#">Techology</a></li>
                                                    <li><a href="#">Movies</a></li>
                                                    <li><a href="#">Fashion</a></li>
                                                    <li><a href="#">video</a></li>
                                                    <li><a href="#">Music</a></li>
                                                    <li><a href="#">Photography</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </aside>

                                </aside>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <footer>
            <div class="container-fluid">
                <div class="row">
                    <div class="vk-sec-footer">
                        <div class="container">
                            <div class="row">
                                <div class="vk-footer">
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <div class="widget-title">
                                                <a href="index-2.html"><img src="image/logo_2.png" alt="" class="img-responsive"></a>
                                            </div>
                                            <div class="widget-content">
                                                <div class="vk-footer-1">

                                                    <div class="vk-footer-1-content">
                                                        <p>
                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis
                                                            egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante.
                                                            Donec eu libero sit amet quam egestas semper.
                                                        </p>
                                                        <div class="vk-footer-1-address">
                                                            <ul>
                                                                <li><i class="fa fa-map-marker" aria-hidden="true"></i> <span>45 Queen's Park Rd, Brighton, BN2 0GJ, UK</span></li>
                                                                <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <span><a href="#">maxnews@domain.com</a></span></li>
                                                                <li><i class="fa fa-headphones" aria-hidden="true"></i> <span> (0123) 456 789</span></li>
                                                            </ul>
                                                        </div>
                                                        <div class="vk-footer-1-icon">
                                                            <ul>
                                                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <h3 class="widget-title"> Latest News</h3>
                                            <div class="widget-content">
                                                <div class="vk-footer-2">
                                                    <div class="vk-footer-2-content">
                                                        <ul>
                                                            <li>
                                                                <div class="vk-footer-img">
                                                                    <a href="#"><img src="image/footer/img.jpg" alt="" class="img-responsive"></a>
                                                                </div>
                                                                <div class="vk-footer-content">
                                                                    <div class="vk-footer-title">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                    </div>
                                                                    <div class="vk-footer-time">
                                                                        <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-footer-img">
                                                                    <a href="#"><img src="image/footer/img-1.jpg" alt="" class="img-responsive"></a>
                                                                </div>
                                                                <div class="vk-footer-content">
                                                                    <div class="vk-footer-title">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                    </div>
                                                                    <div class="vk-footer-time">
                                                                        <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-footer-img">
                                                                    <a href="#"><img src="image/footer/img-2.jpg" alt="" class="img-responsive"></a>
                                                                </div>
                                                                <div class="vk-footer-content">
                                                                    <div class="vk-footer-title">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                    </div>
                                                                    <div class="vk-footer-time">
                                                                        <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <h3 class="widget-title">Twitter Feed</h3>
                                            <div class="widget-content">
                                                <div class="vk-footer-3">
                                                    <div class="vk-footer-3-content">
                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> MaxNews</a></span>
                                                            Your body is like a race car!! You need to fuel it right to keep performing at your best!
                                                        </p>
                                                        <div class="time">about 5 days ago</div>

                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> MaxNews</a></span>
                                                            Your body is like a race car!! You need to fuel it right to keep performing at your best!
                                                        </p>
                                                        <div class="time">about 5 days ago</div>

                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> MaxNews</a></span>
                                                            Your body is like a race car!! You need to fuel it right to keep performing at your best!
                                                        </p>
                                                        <div class="time">about 5 days ago</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="vk-sub-footer">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="vk-sub-footer-1">
                                            <p>
                                                <span>MaxNews</span>
                                                -  News & Magazine PSD Template. Design by
                                                <span>Univertheme</span>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-5 col-md-offset-2">
                                        <div class="vk-sub-footer-2">
                                            <ul>
                                                <li><a href="#">Disclaimer </a></li>
                                                <li><a href="#"> Privacy</a></li>
                                                <li><a href="#"> Advertisement</a></li>
                                                <li><a href="#">Contact us</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>

            <script src="http://localhost/DEV/governancewatchers/public_assets/js/jquery-2.0.2.min.js"></script>
        <script src="http://localhost/DEV/governancewatchers/public_assets/js/jquery.sticky.js"></script>
        <script src="http://localhost/DEV/governancewatchers/public_assets/js/masonry.min.js"></script>
        <script src="http://localhost/DEV/governancewatchers/public_assets/js/jquery-ui.min.js"></script>
        <script src="http://localhost/DEV/governancewatchers/public_assets/js/bootstrap.min.js"></script>
        <script src="http://localhost/DEV/governancewatchers/public_assets/dist/owl.carousel.js"></script>
        <script src="http://localhost/DEV/governancewatchers/public_assets/js/main.js"></script>
        <script src="http://localhost/DEV/governancewatchers/public_assets/js/bootstrap-hover-tabs.js"></script>
    </body>
</html>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>