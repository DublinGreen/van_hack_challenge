<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><a href="<?php echo site_url('advertisement');?>" target="_blank"><img src="<?php echo img_path('ad_top.jpg');?>" alt="advert" title="top advert" class="img-responsive" /></a><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>