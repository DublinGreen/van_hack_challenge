<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>The Nigerian Importers Integrity Association (NIIA) has condemned the poor performance of the Nigerian Ports Authority (NPA) in the quest to developing the nation&rsquo;s seaports.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>