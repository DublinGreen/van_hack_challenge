<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('17861431_10210808805448942_2517129343912443366_n.jpg');?>" alt="Federal Government" class="img img-responsive" alt="Federal Government" /></p><div style="clear: both"></div>Going to buy fuel is a very big deal now and this is happening at the beginning of the year.<br><br><div style="clear: both"></div><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>