<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>The ascending the hills of Akure and looking south,&#8230;</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>