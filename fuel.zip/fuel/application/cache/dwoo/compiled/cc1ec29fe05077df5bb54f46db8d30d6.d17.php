<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('image_1.jpg');?>" alt="Former Minister Oby Ezekwesili Speaks After Release From Detention" class="img img-responsive" /><br />
The Abuja police command has released the&nbsp;former Minister of Education and convener of the BringBackOurGirls group, Oby Ezekwesili.<br />
Mrs. Ezekwesiki said the police refused to tell her and seven members of her group the reason they were arrested Tuesday in Abuja.<br />
Mrs. Ezekwesili was arrested and detained by the police in Abuja earlier on Tuesday.<br />
Her arrest, however, was believed to be connected to the activities of the group.<br />
The group has been carrying out sit-outs in Abuja since more than 200 girls were abducted from Government Secondary School, Chibok, in April 2014 by Boko Haram insurgents.<br />
Mr. Ezekwesili&rsquo;s BBOG group has sustained its advocacy for the safe return of the girls to their families for more than three years.<br />
She said Aisha Yesufu, a known critic of the President Muhammadu Buhari-led administration and six others, were also arrested.<br />
In a series of tweets after her release, the former minister said the Abuja commissioner of police, Sadiq Abubakar Bello, who ordered their release did not state why they were detained.<br />
&ldquo;Without stating the reason for our arrest and detention, Commissioner of Police at the FCT Command, CP Bello has asked us to be let out of their station,&rdquo; she tweeted.<br />
&ldquo;We insisted on a formal charge and release but his response? &ldquo;I am the commissioner and now release you to go.&rdquo;<br />
Efforts by PREMIUM TIMES to reach the police authorities in Abuja for comment were not successful at the time of filing this report.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>