<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>A former Nigerian Secretary to the Federal Government, Babachir Lawal has been arrested and detained by the Economic and Financial Crimes Commission over fraud allegations relating to grass cutting contracts.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>