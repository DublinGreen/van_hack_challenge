<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('3.jpg');?>" alt="The National Leader of the All Progressives Congress (APC), Senator Bola Ahmed Tinubu, and then interim National Chairman of the party, Chief Bisi Akande, Tuesday held a secret meeting with President Muhammadu Buhari in the State House." class="img img-responsive" /><br />
The National Leader of the All Progressives Congress (APC), Senator Bola Ahmed Tinubu, and then interim National Chairman of the party, Chief Bisi Akande, Tuesday held a secret meeting with President Muhammadu Buhari in the State House.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>