<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('17861431_10210808805448942_2517129343912443366_n.jpg');?>" alt="" /><br />
<br /></p>

<p>Going to buy fuel is a very big deal now and this is happening at the beginning of the year.</p>

<p><br><br></p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>