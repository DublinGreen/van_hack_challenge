<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>Mrs.&nbsp; Marie Ebikake, the former Commissioner for Transport in Bayelsa, a soldier and were abducted in separate incidents at the weekend by unknown gunmen in Bayelsa. The incidents occurred barely three days after a Bayelsa monarch&rsquo;s wife who spent 25 days in captivity was freed on Thursday.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>