<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>Are we one of the countries Donald Trump had in mind when he wondered why US lawmakers were seeking protection for &#8220;all these people from shithole countries&#8221;&#8212; immigrants from Haiti, El Salvador and African countries?<br />
To be clear, this question is not original to Nigeria. It has been appropriated&#8212;and I am thoroughly ashamed to admit this&#8212;from Botswana.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>