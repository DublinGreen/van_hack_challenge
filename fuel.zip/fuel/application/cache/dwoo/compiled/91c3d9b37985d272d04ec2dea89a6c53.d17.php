<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>Governor Rochas Okorocha of Imo State has said he will not give any land in Imo State to the Federal Government for a cattle colony.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>