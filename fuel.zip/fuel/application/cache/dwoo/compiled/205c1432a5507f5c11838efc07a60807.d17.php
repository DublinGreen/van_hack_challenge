<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>Two security officials of Second Coming Gas Plant died in a fire outbreak that engulfed the gas station at the early hours of today. The two men and a number of others were on night duty when the fire started.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>