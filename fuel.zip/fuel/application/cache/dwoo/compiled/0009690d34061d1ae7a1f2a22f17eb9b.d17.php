<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('kajfifi.jpg');?>" alt="Sack Defence Minister, rejig security architecture, Afenifere tells Buhari" class="img img-responsive"/><br />
Afenifere said the removal of the Defence Minister would ensure that the lives of Nigerians still count</p>

<p>It also called for the reorganization of the country&rsquo;s security architecture to reflect the country&rsquo;s diversity.</p>

<p>This was contained in a communiqu&eacute; issued at its expanded monthly meeting held in Akure, the country home of its national leader, Pa Reuben Fasoranti.</p>

<p>Yesterday&rsquo;s meeting was attended by former governors of Ondo, Ogun and Kwara, Dr. Olusegun Mimiko, Otunba Gbenga Daniel and Chief Cornelius Adebayo respectively.</p>

<p>Others in attendance were: Pa Ayo Adebanjo, former Secretary to the Government of the Federation, Chief Olu Falae; Bashorun Seinde Arogbofa, Sen Mojisoluwa Akinfenwa, Dr Olu Agunloye, Mrs Modupe Adesanya, Sen Femi Okurounmu, Dr Kunle Olajide, Chief Supo Shonibare, Segun Adegoke, Dare Babarinsa, Reuben Famuyibo, Prof Banji Akintoye and Chief Sola Ebiseni.</p>

<p>Reading the communiqu&eacute;, Afenifere&rsquo;s National Publicity Secretary, Yinka Odumakin said the General Assembly of the group called for the &ldquo;immediate removal of the Minister of Defence Brig- Gen. Monsur Dan Alli (retd) for his insensitivity and not sanctioning killers of Nigerians. This is the only way to show that the lives of Nigerians still count.&rdquo;</p>

<p>While it called on the President to reorganise the country&rsquo;s security architecture to reflect the diversity of the country, the apex Yoruba group equally demanded the &ldquo;immediate disarming of all Fulani herdsmen carrying AK 47 all over Nigeria.&rdquo;</p>

<p>It also urged the President to rise up to the challenge of his office by &ldquo;addressing the nation directly on these developments that threaten Nigeria&rsquo;s corporate existence and ensure the killings are stopped and the perpetrators brought to book.&rdquo;</p>

<p>The communiqu&eacute; reads in part: &ldquo;These killings and arsonist attacks now wear the garb of state-approval given the loud silence of the president over these dastardly acts and in fact asking the governor of Benue State to find accommodation with the killers.</p>

<p>&ldquo;The Inspector General of Police has also said that the killers are Nigerians while the Minister of Defence has blamed the killings on the promulgation of anti-open-grazing law and the blockage of grazing routes in an official sanctioning of the horrendous killings.</p>

<p>&ldquo;Nigeria today has become a primitive and barbaric enclave as the state is either complicit or unwilling to stop these dastardly acts.&rdquo;</p>

<p>On the proposed establishment of cattle colonies, the group rejected cattle colonies saying the concept is &ldquo;offensive, repugnant and an affront on the rights of non-Fulani communities across Nigeria as their lands would now be forcefully acquired and be subjected to an alien culture and rule in the name of cattle rearing.</p>

<p>&ldquo;The Yoruba people would not allow any colony on our land as we are a free people. Anyone who wants to raise cow within our space should do ranching. We ask Yoruba entrepreneurs to venture into ranching to produce cows for domestic consumption and exportation.&rdquo;</p>

<p>While it restated its call for the restructuring of Nigeria into a proper federation with the federating units having their own police to guarantee internal security and law enforcement, Afenifere called on the federal government &ldquo;to put a halt to the culture of repression going on in the country and for the govt to realize that we are in a constitutional democracy where the rule of law should prevail.&nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp; &ldquo;</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>