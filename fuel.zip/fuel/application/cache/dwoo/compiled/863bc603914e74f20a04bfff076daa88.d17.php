<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>The immediate past Governor of Ondo State, Mr Olusegun&#8230;</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>