<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>The former President, in a statement, issueThe former President, in a statement, issued on Tuesday, described the two major parties as unworthy of leading Nigeria and called for a coalition of fresh minds to rescue the country from the grip of the two behemoths in the next general electionsd on Tuesday, described the two major parties as unworthy of leading Nigeria and called for a coalition of fresh minds to rescue the country from the grip of the two behemoths in the next general elections</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>