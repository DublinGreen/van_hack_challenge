<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('kajfifi.jpg');?>" alt="Sack Defence Minister, rejig security architecture, Afenifere tells Buhari" class="img img-responsive"/><br />
Afenifere said the removal of the Defence Minister would ensure that the lives of Nigerians still count It also called for the reorganization of the country&rsquo;s security architecture to reflect the country&rsquo;s diversity.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>