<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('blog/patience_johnathan.jpg');?>" alt="patience johnathan" class="img img-responsive" /><br />
<br><br />
The Economic and Financial Crimes Commission is in fresh moves to seize funds in 15 bank accounts linked to Mrs. Patience Jonathan.</p>

<p>The funds, which the EFCC is seeking to seize, include a total of $8,435,788.84 and over N7.35bn.</p>

<p>The EFCC had appeared before Justice Mojisola Olatoregun of the Federal High Court in Lagos with an ex parte application, seeking the forfeiture of the funds.</p>

<p>The move was, however, interrupted by a train of Senior Advocates of Nigeria led by Mr. Ifedayo Adedipe (SAN) and Mr. Mike Ozekhome (SAN), who challenged the court&rsquo;s jurisdiction to entertain the ex parte application.</p>

<p>They told the judge that the funds, which the EFCC seeks to seize, were already a subject of litigation.</p>

<p>But counsel for the EFCC, Mr. Rotimi Oyedepo, maintained that the SANs had no right of hearing in the court, since his application was ex parte, wondering how they got wind of the move by the anti-graft agency.</p>

<p>In view of the development, the judge adjourned the case till January 23, 2018 and directed the EFCC to file an affidavit to convince it that there were no pending lawsuits relating to the funds before other courts.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>