<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>Officials of the National Drug Law Enforcement Agency (NDLEA) have arrested nine drug traffickers within one week at the Murtala Muhammed International Airport (MMIA), Lagos. The arrests were made between December 24 and 31, 2017 at the airport. Among the suspects was a South African male. At least, 120kg of several illicit narcotic substances were seized from the suspects within the one week period. An investigation by SaharaReporters indicated that many of the suspects fights originated from Brazil, connected Lagos to Johannesburg, South Africa.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>