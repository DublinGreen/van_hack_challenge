<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('14.jpg');?>" alt="Aisha Buhari Reposts Video Of Misau, Murray-Bruce Criticizing Federal Government" class="img img-responsive" /><br />
Wife of President Muhammadu Buhari, Aisha, using her official Twitter handle @aishambuhari on Friday has reposted videos of two senators criticising the federal government.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>