<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?>3, Ilaje Close, Ijapo Estate Akure.<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>