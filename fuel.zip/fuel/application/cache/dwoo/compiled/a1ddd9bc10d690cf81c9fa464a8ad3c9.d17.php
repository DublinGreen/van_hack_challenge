<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="keywords" content="<!--__FUEL_MARKER__0-->governance watchers,">
        <meta name="description" content="<!--__FUEL_MARKER__1-->about governance watchers">
        <!-- Latest compiled and minified CSS -->
        
        <link rel="stylesheet" href="<!--__FUEL_MARKER__2-->http://localhost/DEV/governancewatchers/public_assets/dist/assets/owl.carousel.min.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__3-->http://localhost/DEV/governancewatchers/public_assets/dist/assets/owl.theme.default.min.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__4-->http://localhost/DEV/governancewatchers/public_assets/css/bootstrap.min.css">

        <!-- Optional theme -->
        <link rel="stylesheet" href="<!--__FUEL_MARKER__5-->http://localhost/DEV/governancewatchers/public_assets/css/bootstrap-theme.min.css">
        <link rel="stylesheet" id="themify-icons-css" href="<!--__FUEL_MARKER__6-->http://localhost/DEV/governancewatchers/public_assets/css/themify-icons.css" type="text/css" media="all">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__7-->http://localhost/DEV/governancewatchers/public_assets/css/style.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__8-->http://localhost/DEV/governancewatchers/public_assets/css/jquery-ui.min.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__9-->http://localhost/DEV/governancewatchers/public_assets/css/fonts.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__10-->http://localhost/DEV/governancewatchers/public_assets/css/font-awesome.min.css">
        <link rel="shortcut icon" href="<!--__FUEL_MARKER__11-->http://localhost/DEV/governancewatchers/public_assets/image/favicon.png">
        <title>
            <!--__FUEL_MARKER__12-->About        </title>
        <link href='http://fonts.googleapis.com/css?family=Raleway:400,700' rel='stylesheet' type='text/css'>
    </head>
<body onload="startTime()">
    <!--Load Page-->
    <div class="load-page">
        <div class="sk-cube-grid">
            <div class="sk-cube sk-cube1"></div>
            <div class="sk-cube sk-cube2"></div>
            <div class="sk-cube sk-cube3"></div>
            <div class="sk-cube sk-cube4"></div>
            <div class="sk-cube sk-cube5"></div>
            <div class="sk-cube sk-cube6"></div>
            <div class="sk-cube sk-cube7"></div>
            <div class="sk-cube sk-cube8"></div>
            <div class="sk-cube sk-cube9"></div>
        </div>
    </div>
    <!-- Mobile nav -->
    <nav class="visible-sm visible-xs mobile-menu-container mobile-nav">
        <div class="menu-mobile-nav navbar-toggle">
            <span class="icon-search-mobile"><i class="fa fa-search" aria-hidden="true"></i></span>
            <span class="icon-bar"><i class="fa fa-bars" aria-hidden="true"></i></span>
        </div>
        <div id="cssmenu" class="animated">
            <div class="uni-icons-close"><i class="fa fa-times" aria-hidden="true"></i></div>
            <ul class="nav navbar-nav animated">
                <li class="has-sub home-icon"><a href='#'>Home</a>
                    <ul>
                        <li><a href="index-2.html">Home default</a></li>
                        <li><a href="01_02_fashion.html">Home Fashion</a></li>
                        <li><a href="01_03_sport.html">Home Sport</a></li>
                        <li><a href="01_04_techology.html">Home Techology</a></li>
                        <li><a href="01_05_video.html">Home Video</a></li>
                        <li><a href="01_06_boxed.html">Home Boxed</a></li>
                    </ul>
                </li>
                <li class='has-sub'><a href='#'>Economy</a></li>
                <li class="has-sub"><a href='#'>Sport</a></li>
                <li class="has-sub"><a href='#'>Fashion</a></li>
                <li class="has-sub"><a href='#'>Music</a></li>
                <li class="has-sub"><a href='#'>Video</a></li>
                <li class="has-sub"><a href='#'>Features</a>
                    <ul>
                        <li class="has-sub"><a href="#">Sidebar</a>
                            <ul>
                                <li><a href="03_01_01_left_sidebar.html">Left Sidebar</a></li>
                                <li><a href="03_01_02_right_sidebar.html">Right Sidebar</a></li>
                                <li><a href="03_01_03_without_sidebar.html">Without Sidebar</a></li>
                            </ul>
                        </li>
                        <li class="has-sub"><a href="#">Single Post</a>
                            <ul>
                                <li><a href="03_02_01_image_post.html">Image Post</a></li>
                                <li><a href="03_02_02_slide_post.html">Slide Post</a></li>
                                <li><a href="03_02_03_video_post.html">Video Post</a></li>
                                <li><a href="03_02_04_post_full_width.html">Post Full</a></li>
                                <li><a href="03_02_05_post_no_sidebar.html">Post No Sidebar</a></li>
                            </ul>
                        </li>
                        <li class="has-sub"><a href="#">Search Results</a>
                            <ul>
                                <li><a href="03_03_01_search_results_list.html">Search Result List</a></li>
                                <li><a href="03_03_02_search_results_grid.html">Search Result Grid</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="has-sub"><a href='#'>Category</a>
                    <ul>
                        <li><a href="02_01_list.html">List</a></li>
                        <li><a href="02_02_list.html">List 2</a></li>
                        <li><a href="02_03_grid_2_columns.html">Grid 2 Columns</a></li>
                        <li><a href="02_04_grid_2_columns_2.html">Grid 2 Columns 2</a></li>
                        <li><a href="02_05_mixed.html">Mixed</a></li>
                    </ul>
                </li>
                <li class="has-sub"><a href='#'>Pages</a>
                    <ul>
                        <li><a href="04_01_about.html">About</a></li>
                        <li><a href="04_02_contact.html">Contact</a></li>
                        <li><a href="04_03_404page.html">404 Page</a></li>
                    </ul>
                </li>
                <li class="has-sub"><a href='#'>Shop</a>
                    <ul>
                        <li><a href="05_01_shop.html">Shop</a></li>
                        <li><a href="05_02_single_product.html">Single Product</a></li>
                        <li><a href="05_03_cart.html">Cart</a></li>
                        <li><a href="05_04_checkout.html">Checkout</a></li>
                    </ul>
                </li>
            </ul>
            <div class="uni-nav-mobile-bottom">
                <div class="form-search-wrapper-mobile">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search">
                        <span class="input-group-addon success"><i class="fa fa-search"></i></span>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </nav>
    <!-- End mobile menu -->



    <div id="wrapper-container" class="site-wrapper-container">
        <header>
            <div class="vk-header-default">
                <div class="container-fluid">
                    <div class="row">
                        <div class="vk-top-header">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-4 col-sm-4">
                                        <div class="vk-top-header-1">
                                            <ul>
                                                <li><a href="#"> Contact</a></li>
                                                <!--<li><a href="#">Purchase Now</a></li>-->
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class="vk-top-header-2">
                                            <ul>
                                                <li><span id="datetime-current"></span></li>
                                                <li>-</li>
                                                <li><span id="year-current"></span></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class="vk-top-header-3">
                                            <ul>
                                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="vk-between-header">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="vk-between-header-logo">
                                            <a href="index-2.html"><img src="<!--__FUEL_MARKER__13-->http://localhost/DEV/governancewatchers/public_assets/image/governance_watchers.png" alt="" class="img-responsive"></a>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-md-offset-1">
                                        <div class="vk-between-header-banner">
                                            <a href="#"><img src="<!--__FUEL_MARKER__14-->http://localhost/DEV/governancewatchers/public_assets/image/ad-header.jpg" alt="" class="img-responsive"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="visible-md visible-lg vk-bottom-header uni-sticky">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-11">
                                        <div class="cssmenu">
                                            <ul>
                                                <li class="has-sub home-icon"><a href='#'><i class="fa fa-home" aria-hidden="true"></i></a>
                                                </li>
                                                <li class='has-sub home-economy'><a href='#'>ECONOMY</a></li>
                                                <li class="has-sub home-sport"><a href='#'>SPORT</a></li>
                                                <li class="has-sub home-fashion"><a href='#'>fashion</a></li>
                                                <li class="has-sub home-music"><a href='#'>music</a></li>
                                                <li class="has-sub home-video"><a href='#'>video</a></li>
                                                <li class="has-sub"><a href='#'>features</a>
                                                    <ul>
                                                        <li class="has-sub"><a href="#">Sidebar</a>
                                                            <ul>
                                                                <li><a href="03_01_01_left_sidebar.html">Left Sidebar</a></li>
                                                                <li><a href="03_01_02_right_sidebar.html">Right Sidebar</a></li>
                                                                <li><a href="03_01_03_without_sidebar.html">Without Sidebar</a></li>
                                                            </ul>
                                                        </li>
                                                        <li class="has-sub"><a href="#">Single Post</a>
                                                            <ul>
                                                                <li><a href="03_02_01_image_post.html">Image Post</a></li>
                                                                <li><a href="03_02_02_slide_post.html">Slide Post</a></li>
                                                                <li><a href="03_02_03_video_post.html">Video Post</a></li>
                                                                <li><a href="03_02_04_post_full_width.html">Post Full</a></li>
                                                                <li><a href="03_02_05_post_no_sidebar.html">Post No Sidebar</a></li>
                                                            </ul>
                                                        </li>
                                                        <li class="has-sub"><a href="#">Search Results</a>
                                                            <ul>
                                                                <li><a href="03_03_01_search_results_list.html">Search Result List</a></li>
                                                                <li><a href="03_03_02_search_results_grid.html">Search Result Grid</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="has-sub"><a href='#'>Category</a>
                                                    <ul>
                                                        <li><a href="02_01_list.html">List</a></li>
                                                        <li><a href="02_02_list.html">List 2</a></li>
                                                        <li><a href="02_03_grid_2_columns.html">Grid 2 Columns</a></li>
                                                        <li><a href="02_04_grid_2_columns_2.html">Grid 2 Columns 2</a></li>
                                                        <li><a href="02_05_mixed.html">Mixed</a></li>
                                                    </ul>
                                                </li>
                                                <li class="has-sub"><a href='#'>pages</a>
                                                    <ul>
                                                        <li><a href="04_01_about.html">About</a></li>
                                                        <li><a href="04_02_contact.html">Contact</a></li>
                                                        <li><a href="04_03_404page.html">404 Page</a></li>
                                                    </ul>
                                                </li>
                                                <li class="has-sub"><a href='#'>shop</a>
                                                    <ul>
                                                        <li><a href="05_01_shop.html">Shop</a></li>
                                                        <li><a href="05_02_single_product.html">Single Product</a></li>
                                                        <li><a href="05_03_cart.html">Cart</a></li>
                                                        <li><a href="05_04_checkout.html">Checkout</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-1">
                                        <div class="vk-bottom-header-search toggle-form">
                                            <i class="fa fa-search" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                                <!--Form search-->
                                <div class="form-search-wrapper">
                                    <div class="input-group">
                                        <input type="text" class="form-control" placeholder="Search">
                                        <span class="input-group-addon success"><i class="fa fa-search"></i></span>
                                    </div>
                                </div>
                                <!--MEGA MENU 2-->
                                <div class="uni-mega-menu-2 animated">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <h4>Home pages</h4>
                                            <ul>
                                                <li><a href="index-2.html">Home Default</a></li>
                                                <li><a href="01_02_fashion.html">Fashion News</a></li>
                                                <li><a href="01_03_sport.html">Sport News</a></li>
                                                <li><a href="01_04_techology.html">Tech News</a></li>
                                                <li><a href="01_05_video.html">Video News</a></li>
                                            </ul>
                                        </div>
                                        <div class="col-md-3">
                                            <h4>PAGES</h4>
                                            <ul>
                                                <li><a href="04_01_about.html">About</a></li>
                                                <li><a href="04_02_contact.html">Contact</a></li>
                                                <li><a href="04_03_404page.html">404 Page</a></li>
                                                <li><a href="03_03_01_search_results_list.html">Search Result List</a></li>
                                                <li><a href="03_03_02_search_results_grid.html">Search Result Grid</a></li>
                                            </ul>
                                        </div>
                                        <div class="col-md-3">
                                            <h4>Categories</h4>
                                            <ul>
                                                <li><a href="#">Economy</a></li>
                                                <li><a href="#">Sport</a></li>
                                                <li><a href="#">Fashion</a></li>
                                                <li><a href="#">Music</a></li>
                                                <li><a href="#">Video</a></li>
                                            </ul>
                                        </div>
                                        <div class="col-md-3">
                                            <h4>Shortcode</h4>
                                            <ul>
                                                <li><a href="#">Buttons</a></li>
                                                <li><a href="#">Typogarphy</a></li>
                                                <li><a href="#">Tabs</a></li>
                                                <li><a href="#">Icons</a></li>
                                                <li><a href="#">Headers</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <!--MEGA MENU 1-->
                                <div class="uni-mega-menu-1">
                                    <!--MEGA MENU 1 SPORT-->
                                    <div class="uni-mega-menu-1-sport animated">
                                        <div class="uni-mega-menu-1-left">
                                            <ul class="nav nav-pills">
                                                <li class="active"><a href="#tab-1" data-toggle="tab" data-hover="tab">FootBall</a></li>
                                                <li><a href="#tab-2" data-toggle="tab" data-hover="tab">Tennis</a></li>
                                                <li><a href="#tab-3" data-toggle="tab" data-hover="tab">Golf</a></li>
                                                <li><a href="#tab-4" data-toggle="tab" data-hover="tab">Moto Racing</a></li>
                                                <li><a href="#tab-5" data-toggle="tab" data-hover="tab">Basketball</a></li>
                                                <li><a href="#tab-6" data-toggle="tab" data-hover="tab">Hockey</a></li>
                                            </ul>
                                        </div>
                                        <div class="uni-mega-menu-1-right">
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="tab-1">
                                                    <div id="uni-mega-menu-tab-sport-1" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__15-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__16-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img22.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__17-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__18-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__19-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__20-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img24.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__21-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__22-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img25.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__23-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__24-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-2">
                                                    <div id="uni-mega-menu-tab-sport-2" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__25-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__26-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img22.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__27-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__28-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__29-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__30-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img24.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__31-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__32-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img25.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__33-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__34-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-3">
                                                    <div id="uni-mega-menu-tab-sport-3" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__35-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__36-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img22.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__37-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__38-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__39-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__40-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img24.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__41-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__42-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img25.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__43-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__44-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-4">
                                                    <div id="uni-mega-menu-tab-sport-4" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__45-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__46-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img22.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__47-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__48-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__49-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__50-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img24.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__51-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__52-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img25.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__53-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__54-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-5">
                                                    <div id="uni-mega-menu-tab-sport-5" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__55-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__56-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img22.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__57-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__58-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__59-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__60-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img24.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__61-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__62-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img25.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__63-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__64-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-6">
                                                    <div id="uni-mega-menu-tab-sport-6" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__65-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__66-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img22.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <div class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__67-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__68-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__69-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__70-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img24.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__71-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__72-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img25.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__73-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__74-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/img23.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--MEGA MENU Economy-->
                                    <div class="uni-mega-menu-1-economy animated">
                                        <div class="uni-mega-menu-1-left">
                                            <ul class="nav nav-pills">
                                                <li class="active"><a href="#tab-eco-1" data-toggle="tab" data-hover="tab">Stock</a></li>
                                                <li><a href="#tab-eco-2" data-toggle="tab" data-hover="tab">Finance</a></li>
                                                <li><a href="#tab-eco-3" data-toggle="tab" data-hover="tab">Business</a></li>
                                                <li><a href="#tab-eco-4" data-toggle="tab" data-hover="tab">Labor - Job</a></li>
                                                <li><a href="#tab-eco-5" data-toggle="tab" data-hover="tab">Basketball</a></li>
                                                <li><a href="#tab-eco-6" data-toggle="tab" data-hover="tab">Hockey</a></li>
                                            </ul>
                                        </div>
                                        <div class="uni-mega-menu-1-right">
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="tab-eco-1">
                                                    <div id="uni-mega-menu-tab-eco-1" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__75-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__76-->http://localhost/DEV/governancewatchers/public_assets/image/homepage1/sec-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__77-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__78-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__79-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__80-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__81-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__82-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__83-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-eco-2">
                                                    <div id="uni-mega-menu-tab-eco-2" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__84-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__85-->http://localhost/DEV/governancewatchers/public_assets/image/homepage1/sec-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__86-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__87-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__88-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__89-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__90-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__91-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__92-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__93-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-eco-3">
                                                    <div id="uni-mega-menu-tab-eco-3" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__94-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__95-->http://localhost/DEV/governancewatchers/public_assets/image/homepage1/sec-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__96-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__97-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__98-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__99-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__100-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__101-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__102-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__103-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-eco-4">
                                                    <div id="uni-mega-menu-tab-eco-4" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__104-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__105-->http://localhost/DEV/governancewatchers/public_assets/image/homepage1/sec-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__106-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__107-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__108-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__109-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__110-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__111-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__112-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__113-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-eco-5">
                                                    <div id="uni-mega-menu-tab-eco-5" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__114-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__115-->http://localhost/DEV/governancewatchers/public_assets/image/homepage1/sec-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__116-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__117-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__118-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__119-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__120-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__121-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__122-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__123-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-eco-6">
                                                    <div id="uni-mega-menu-tab-eco-6" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__124-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__125-->http://localhost/DEV/governancewatchers/public_assets/image/homepage1/sec-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__126-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__127-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__128-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__129-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__130-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__131-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__132-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__133-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/economy-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--MEGA MENU FASHION-->
                                    <div class="uni-mega-menu-1-fashion animated">
                                        <div class="uni-mega-menu-1-left">
                                            <ul class="nav nav-pills">
                                                <li class="active"><a href="#tab-fas-1" data-toggle="tab" data-hover="tab">Fashion +</a></li>
                                                <li><a href="#tab-fas-2" data-toggle="tab" data-hover="tab">Fashion Star</a></li>
                                                <li><a href="#tab-fas-3" data-toggle="tab" data-hover="tab">Model</a></li>
                                                <li><a href="#tab-fas-4" data-toggle="tab" data-hover="tab">Design</a></li>
                                                <li><a href="#tab-fas-5" data-toggle="tab" data-hover="tab">Fashion man</a></li>
                                                <li><a href="#tab-fas-6" data-toggle="tab" data-hover="tab">Fashion Unisex</a></li>
                                            </ul>
                                        </div>
                                        <div class="uni-mega-menu-1-right">
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="tab-fas-1">
                                                    <div id="uni-mega-menu-tab-fas-1" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__134-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__135-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__136-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__137-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__138-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__139-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__140-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__141-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__142-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__143-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-fas-2">
                                                    <div id="uni-mega-menu-tab-fas-2" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__144-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__145-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__146-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__147-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__148-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__149-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__150-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__151-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__152-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__153-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-fas-3">
                                                    <div id="uni-mega-menu-tab-fas-3" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__154-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__155-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__156-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__157-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__158-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__159-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__160-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__161-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__162-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__163-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-fas-4">
                                                    <div id="uni-mega-menu-tab-fas-4" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__164-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__165-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__166-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__167-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__168-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__169-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__170-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__171-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__172-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__173-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-fas-5">
                                                    <div id="uni-mega-menu-tab-fas-5" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__174-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__175-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__176-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__177-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__178-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__179-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__180-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__181-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__182-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__183-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-fas-6">
                                                    <div id="uni-mega-menu-tab-fas-6" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__184-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__185-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__186-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__187-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__188-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__189-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__190-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__191-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__192-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__193-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/fas5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--MEGA MENU MUSIC-->
                                    <div class="uni-mega-menu-1-music animated">
                                        <div class="uni-mega-menu-1-left">
                                            <ul class="nav nav-pills">
                                                <li class="active"><a href="#tab-mus-1" data-toggle="tab" data-hover="tab">Pop Music</a></li>
                                                <li><a href="#tab-mus-2" data-toggle="tab" data-hover="tab">EDM Music</a></li>
                                                <li><a href="#tab-mus-3" data-toggle="tab" data-hover="tab">Rap Music</a></li>
                                                <li><a href="#tab-mus-4" data-toggle="tab" data-hover="tab">Rock Music</a></li>
                                                <li><a href="#tab-mus-5" data-toggle="tab" data-hover="tab">Underground</a></li>
                                                <li><a href="#tab-mus-6" data-toggle="tab" data-hover="tab">R&B Music</a></li>
                                            </ul>
                                        </div>
                                        <div class="uni-mega-menu-1-right">
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="tab-mus-1">
                                                    <div id="uni-mega-menu-tab-mus-1" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__194-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__195-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__196-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__197-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__198-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__199-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__200-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__201-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__202-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__203-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-mus-2">
                                                    <div id="uni-mega-menu-tab-mus-2" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__204-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__205-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__206-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__207-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__208-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__209-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__210-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__211-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__212-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__213-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-mus-3">
                                                    <div id="uni-mega-menu-tab-mus-3" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__214-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__215-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__216-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__217-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__218-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__219-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__220-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__221-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__222-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__223-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-mus-4">
                                                    <div id="uni-mega-menu-tab-mus-4" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__224-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__225-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__226-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__227-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__228-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__229-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__230-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__231-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__232-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__233-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-mus-5">
                                                    <div id="uni-mega-menu-tab-mus-5" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__234-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__235-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__236-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__237-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__238-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__239-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__240-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__241-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__242-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__243-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-mus-6">
                                                    <div id="uni-mega-menu-tab-mus-6" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__244-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__245-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__246-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__247-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__248-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__249-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__250-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__251-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__252-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__253-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--MEGA MENU VIDEO-->
                                    <div class="uni-mega-menu-1-video animated">
                                        <div class="uni-mega-menu-1-left">
                                            <ul class="nav nav-pills">
                                                <li class="active"><a href="#tab-vid-1" data-toggle="tab" data-hover="tab">Video Economy</a></li>
                                                <li><a href="#tab-vid-2" data-toggle="tab" data-hover="tab">Video Sport</a></li>
                                                <li><a href="#tab-vid-3" data-toggle="tab" data-hover="tab">Video Fashion</a></li>
                                                <li><a href="#tab-vid-4" data-toggle="tab" data-hover="tab">Video Music</a></li>
                                                <li><a href="#tab-vid-5" data-toggle="tab" data-hover="tab">Underground</a></li>
                                                <li><a href="#tab-vid-6" data-toggle="tab" data-hover="tab">R&B Music</a></li>
                                            </ul>
                                        </div>
                                        <div class="uni-mega-menu-1-right">
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="tab-vid-1">
                                                    <div id="uni-mega-menu-tab-video-1" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__254-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__255-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__256-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__257-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__258-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__259-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__260-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__261-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__262-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__263-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__264-->http://localhost/DEV/governancewatchers/public_assets/<!--__FUEL_MARKER__265-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__266-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__267-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__268-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__269-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-vid-2">
                                                    <div id="uni-mega-menu-tab-video-2" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__270-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__271-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__272-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__273-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__274-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__275-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__276-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__277-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__278-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__279-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-vid-3">
                                                    <div id="uni-mega-menu-tab-video-3" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__280-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__281-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__282-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__283-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__284-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__285-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__286-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__287-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__288-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__289-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-vid-4">
                                                    <div id="uni-mega-menu-tab-video-4" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__290-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__291-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__292-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__293-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__294-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__295-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__296-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__297-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__298-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__299-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-vid-5">
                                                    <div id="uni-mega-menu-tab-video-5" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__300-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__301-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__302-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__303-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__304-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__305-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__306-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__307-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__308-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__309-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="tab-vid-6">
                                                    <div id="uni-mega-menu-tab-video-6" class="owl-carousel owl-theme">
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__310-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-4.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__311-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__312-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-1.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__313-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__314-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-2.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__315-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__316-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-3.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__317-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                        <div class="item">
                                                            <article class="post type-post">
                                                                <div class="content-inner">
                                                                    <div class="entry-top">
                                                                        <div class="uni-play-img thumbnail-img">
                                                                            <a href="#"><img src="<!--__FUEL_MARKER__318-->http://localhost/DEV/governancewatchers/public_assets/image/mega_menu_1/mus-5.jpg" alt="" class="img-responsive"></a>
                                                                            <div class="uni-play">
                                                                                <a href="#"><img src="<!--__FUEL_MARKER__319-->http://localhost/DEV/governancewatchers/public_assets/image/play.png" alt=""></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="entry-content">
                                                                        <div class="entry-header">
                                                                            <h2 class="entry-title">
                                                                                <a href="#" rel="">Pellentesque habitant morbi tristique senectus et netus et malesuada fames
                                                                                </a>
                                                                            </h2>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </article>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        
        <div id="main-content" class="site-main-content">
        <div id="home-main-content" class="site-home-main-content">

            <div class="uni-about">
                <div id="vk-home-default-slide">
                    <div class="container-fluid">
                        <div class="row">
                            <div id="uni-home-defaults-slide">
                                <div id="vk-owl-demo-singer-slider" class="owl-carousel owl-theme owl-loaded owl-drag">
                                    
                                    
                                    
                                <div class="owl-stage-outer"><div class="owl-stage" style="transition: 0s; width: 4764px; transform: translate3d(-1020px, 0px, 0px);"><div class="owl-item cloned" style="width: 670.5px; margin-right: 10px;"><div class="item">
                                        <div class="uni-item-img-2"></div>
                                        <!--                        <img src="image/slideshow/right.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">SPORT</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <div class="time"> June 21, 2017</div>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item cloned" style="width: 670.5px; margin-right: 10px;"><div class="item">
                                        <div class="uni-item-img-3"></div>
                                        <!--                        <img src="image/slideshow/left.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">TRAVEL</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <div class="time"> June 21, 2017</div>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item active center" style="width: 670.5px; margin-right: 10px;"><div class="item">
                                        <div class="uni-item-img-1"></div>
                                        <!--                        <img src="image/slideshow/center.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">LIFESTYLE</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <div class="time"> June 21, 2017</div>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item active" style="width: 670.5px; margin-right: 10px;"><div class="item">
                                        <div class="uni-item-img-2"></div>
                                        <!--                        <img src="image/slideshow/right.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">SPORT</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <div class="time"> June 21, 2017</div>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item" style="width: 670.5px; margin-right: 10px;"><div class="item">
                                        <div class="uni-item-img-3"></div>
                                        <!--                        <img src="image/slideshow/left.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">TRAVEL</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <div class="time"> June 21, 2017</div>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item cloned" style="width: 670.5px; margin-right: 10px;"><div class="item">
                                        <div class="uni-item-img-1"></div>
                                        <!--                        <img src="image/slideshow/center.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">LIFESTYLE</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <div class="time"> June 21, 2017</div>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item cloned" style="width: 670.5px; margin-right: 10px;"><div class="item">
                                        <div class="uni-item-img-2"></div>
                                        <!--                        <img src="image/slideshow/right.jpg" alt="">-->
                                        <div class="vk-item-caption">
                                            <div class="vk-item-caption-top">
                                                <div class="ribbon">
                                                    <span class="border-ribbon"><img src="image/homepage1/icon/fire.png" alt="" class="img-responsive"></span>
                                                </div>
                                                <ul>
                                                    <li><a href="#">SPORT</a></li>
                                                    <li>-</li>
                                                    <li>2134 views</li>
                                                </ul>
                                            </div>
                                            <div class="vk-item-caption-text">
                                                <h2><a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing elit</a></h2>
                                            </div>
                                            <div class="vk-item-caption-time">
                                                <div class="time"> June 21, 2017</div>
                                            </div>
                                        </div>
                                    </div></div></div></div><div class="owl-nav disabled"><div class="owl-prev"></div><div class="owl-next"></div></div><div class="owl-dots disabled"></div></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="uni-about-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="breadcrumb breadcrumb-search">
                                    <a href="#">Home</a>
                                    <a href="#" class="active">about</a>
                                </div>

                                <div class="uni-about-content">
                                    <h2><!--__FUEL_MARKER__320-->About Governance Watchers</h2>
                                    <div class="description">
										<!--__FUEL_MARKER__321-->This is a test for the.....                                    </div>

                                    <!--                        OUR EDITOR-->
                                    <div class="uni-about-our-editor">
                                        <h2>Our Editors</h2>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="uni-about-our-editor-item">
                                                    <div class="uni-itme-img">
                                                        <img src="image/04_01_about/img.jpg" alt="" class="img-responsive">
                                                    </div>
                                                    <h4>Amanda Smith</h4>
                                                    <ul class="list-inline">
                                                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="uni-about-our-editor-item">
                                                    <div class="uni-itme-img">
                                                        <img src="image/04_01_about/img1.jpg" alt="" class="img-responsive">
                                                    </div>
                                                    <h4>Adam Henderson</h4>
                                                    <ul class="list-inline">
                                                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="uni-about-our-editor-item">
                                                    <div class="uni-itme-img">
                                                        <img src="image/04_01_about/img2.jpg" alt="" class="img-responsive">
                                                    </div>
                                                    <h4>Tom Hank</h4>
                                                    <ul class="list-inline">
                                                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="uni-about-our-editor-item">
                                                    <div class="uni-itme-img">
                                                        <img src="image/04_01_about/img3.jpg" alt="" class="img-responsive">
                                                    </div>
                                                    <h4>Taylor Swift</h4>
                                                    <ul class="list-inline">
                                                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="uni-about-our-editor-item">
                                                    <div class="uni-itme-img">
                                                        <img src="image/04_01_about/img4.jpg" alt="" class="img-responsive">
                                                    </div>
                                                    <h4>Katy Perry</h4>
                                                    <ul class="list-inline">
                                                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="uni-about-our-editor-item">
                                                    <div class="uni-itme-img">
                                                        <img src="image/04_01_about/img5.jpg" alt="" class="img-responsive">
                                                    </div>
                                                    <h4>Justin Bieber</h4>
                                                    <ul class="list-inline">
                                                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="uni-about-our-editor-item">
                                                    <div class="uni-itme-img">
                                                        <img src="image/04_01_about/img6.jpg" alt="" class="img-responsive">
                                                    </div>
                                                    <h4>MiLey Cyrus</h4>
                                                    <ul class="list-inline">
                                                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="uni-about-our-editor-item">
                                                    <div class="uni-itme-img">
                                                        <img src="image/04_01_about/img7.jpg" alt="" class="img-responsive">
                                                    </div>
                                                    <h4>Maria Carey</h4>
                                                    <ul class="list-inline">
                                                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--                        CONTACT INFORMATION-->
                                    <div class="uni-about-contact-info">
                                        <h2>Contact Infomation</h2>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="uni-about-contact-info-left">
                                                    <ul>
                                                        <li>
                                                            <h4><i class="fa fa-home" aria-hidden="true"></i> Office Address</h4>
                                                            <p>45 Queen's Park Rd, Brighton, BN2 0GJ, United Kingdom</p>
                                                        </li>
                                                        <li>
                                                            <h4><i class="fa fa-envelope" aria-hidden="true"></i> Office Address</h4>
                                                            <p>maxnews@domain.com</p>
                                                            <p>suppost@domain.com</p>
                                                        </li>
                                                        <li>
                                                            <h4><i class="fa fa-phone" aria-hidden="true"></i> Tel</h4>
                                                            <p>(+233) 123 456789</p>
                                                            <p>(+233) 123 458952</p>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="uni-about-contact-info-right">
                                                    <div class="uni-about-contact-map">
                                                        <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2520.3558605259554!2d-0.1305261839151272!3d50.824572079528714!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4875859878db2cc7%3A0xff129250121f260d!2s45+Queen's+Park+Rd%2C+Brighton+BN2+0GJ%2C+UK!5e0!3m2!1sen!2s!4v1505207016897" allowfullscreen=""></iframe>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <aside class="widget-area">

                                    <aside class="widget">
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-ad">
                                                <a href="#">
                                                    <img src="image/ad-sidebar.jpg" alt="ad-sidebar" class="img-responsive">
                                                </a>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-facebook">
                                                <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ffacebook&amp;tabs=timeline&amp;width=340&amp;height=500&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId" width="340" height="500" style="border:none;overflow:hidden"></iframe>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <h3 class="widget-title">Stay Connected</h3>
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-stay">
                                                <div class="vk-right-stay-body">
                                                    <a class="btn btn-block btn-social btn-facebook">
                                                        <span class="icon"><i class="fa fa-facebook"></i></span>
                                                        <span class="info"> 2134 Like</span>
                                                        <span class="text">Like</span>
                                                    </a>
                                                    <a class="btn btn-block btn-social btn-twitter">
                                                        <span class="icon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                                                        <span class="info"> 13634 Follows</span>
                                                        <span class="text">Follows</span>
                                                    </a>
                                                    <a class="btn btn-block btn-social btn-youtube">
                                                        <span class="icon"><i class="fa fa-youtube-play" aria-hidden="true"></i></span>
                                                        <span class="info">10634 Subscribers</span>
                                                        <span class="text">Subscribe</span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <h3 class="widget-title">Tags Clound</h3>
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-tags">
                                                <ul>
                                                    <li><a href="#">LifeStyle</a></li>
                                                    <li><a href="#">Sport</a></li>
                                                    <li><a href="#">Economy</a></li>
                                                    <li><a href="#">Business</a></li>
                                                    <li><a href="#">Travel</a></li>
                                                    <li><a href="#">Techology</a></li>
                                                    <li><a href="#">Movies</a></li>
                                                    <li><a href="#">Fashion</a></li>
                                                    <li><a href="#">video</a></li>
                                                    <li><a href="#">Music</a></li>
                                                    <li><a href="#">Photography</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </aside>

                                </aside>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>

        </div>
    </div>

        <footer>
            <div class="container-fluid">
                <div class="row">
                    <div class="vk-sec-footer">
                        <div class="container">
                            <div class="row">
                                <div class="vk-footer">
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <div class="widget-title">
                                                <a href="index-2.html"><img src="<!--__FUEL_MARKER__322-->http://localhost/DEV/governancewatchers/public_assets/image/logo_2.png" alt="" class="img-responsive"></a>
                                            </div>
                                            <div class="widget-content">
                                                <div class="vk-footer-1">

                                                    <div class="vk-footer-1-content">
                                                        <p>
                                                            Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis
                                                            egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante.
                                                            Donec eu libero sit amet quam egestas semper.
                                                        </p>
                                                        <div class="vk-footer-1-address">
                                                            <ul>
                                                                <li><i class="fa fa-map-marker" aria-hidden="true"></i> <span>45 Queen's Park Rd, Brighton, BN2 0GJ, UK</span></li>
                                                                <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <span><a href="#">maxnews@domain.com</a></span></li>
                                                                <li><i class="fa fa-headphones" aria-hidden="true"></i> <span> (0123) 456 789</span></li>
                                                            </ul>
                                                        </div>
                                                        <div class="vk-footer-1-icon">
                                                            <ul>
                                                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <h3 class="widget-title"> Latest News</h3>
                                            <div class="widget-content">
                                                <div class="vk-footer-2">
                                                    <div class="vk-footer-2-content">
                                                        <ul>
                                                            <li>
                                                                <div class="vk-footer-img">
                                                                    <a href="#"><img src="<!--__FUEL_MARKER__323-->http://localhost/DEV/governancewatchers/public_assets/image/footer/img.jpg" alt="" class="img-responsive"></a>
                                                                </div>
                                                                <div class="vk-footer-content">
                                                                    <div class="vk-footer-title">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                    </div>
                                                                    <div class="vk-footer-time">
                                                                        <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-footer-img">
                                                                    <a href="#"><img src="<!--__FUEL_MARKER__324-->http://localhost/DEV/governancewatchers/public_assets/image/footer/img-1.jpg" alt="" class="img-responsive"></a>
                                                                </div>
                                                                <div class="vk-footer-content">
                                                                    <div class="vk-footer-title">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                    </div>
                                                                    <div class="vk-footer-time">
                                                                        <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                            <li>
                                                                <div class="vk-footer-img">
                                                                    <a href="#"><img src="<!--__FUEL_MARKER__325-->http://localhost/DEV/governancewatchers/public_assets/image/footer/img-2.jpg" alt="" class="img-responsive"></a>
                                                                </div>
                                                                <div class="vk-footer-content">
                                                                    <div class="vk-footer-title">
                                                                        <h2><a href="#">Pellentesque habitant morbi tristi senectus et netus</a></h2>
                                                                    </div>
                                                                    <div class="vk-footer-time">
                                                                        <div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> March, 20, 2017</div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <h3 class="widget-title">Twitter Feed</h3>
                                            <div class="widget-content">
                                                <div class="vk-footer-3">
                                                    <div class="vk-footer-3-content">
                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> MaxNews</a></span>
                                                            Your body is like a race car!! You need to fuel it right to keep performing at your best!
                                                        </p>
                                                        <div class="time">about 5 days ago</div>

                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> MaxNews</a></span>
                                                            Your body is like a race car!! You need to fuel it right to keep performing at your best!
                                                        </p>
                                                        <div class="time">about 5 days ago</div>

                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> MaxNews</a></span>
                                                            Your body is like a race car!! You need to fuel it right to keep performing at your best!
                                                        </p>
                                                        <div class="time">about 5 days ago</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="vk-sub-footer">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="vk-sub-footer-1">
                                            <p>
                                                <span>MaxNews</span>
                                                -  News & Magazine PSD Template. Design by
                                                <span>Univertheme</span>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-5 col-md-offset-2">
                                        <div class="vk-sub-footer-2">
                                            <ul>
                                                <li><a href="#">Disclaimer </a></li>
                                                <li><a href="#"> Privacy</a></li>
                                                <li><a href="#"> Advertisement</a></li>
                                                <li><a href="#">Contact us</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>

        <script src="<!--__FUEL_MARKER__326-->http://localhost/DEV/governancewatchers/public_assets/js/jquery-2.0.2.min.js"></script>
        <script src="<!--__FUEL_MARKER__327-->http://localhost/DEV/governancewatchers/public_assets/js/jquery.sticky.js"></script>
        <script src="<!--__FUEL_MARKER__328-->http://localhost/DEV/governancewatchers/public_assets/js/masonry.min.js"></script>
        <script src="<!--__FUEL_MARKER__329-->http://localhost/DEV/governancewatchers/public_assets/js/jquery-ui.min.js"></script>
        <script src="<!--__FUEL_MARKER__330-->http://localhost/DEV/governancewatchers/public_assets/js/bootstrap.min.js"></script>
        <script src="<!--__FUEL_MARKER__331-->http://localhost/DEV/governancewatchers/public_assets/dist/owl.carousel.js"></script>
        <script src="<!--__FUEL_MARKER__332-->http://localhost/DEV/governancewatchers/public_assets/js/main.js"></script>
        <script src="<!--__FUEL_MARKER__333-->http://localhost/DEV/governancewatchers/public_assets/js/bootstrap-hover-tabs.js"></script>
    </body>
</html>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>