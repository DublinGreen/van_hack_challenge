<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="keywords" content="<!--__FUEL_MARKER__0-->governance watchers,">
        <meta name="description" content="<!--__FUEL_MARKER__1-->about governance watchers">
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="dist/assets/owl.carousel.min.css">
        <link rel="stylesheet" href="dist/assets/owl.theme.default.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">

        <!-- Optional theme -->
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <link rel="stylesheet" id="themify-icons-css" href="css/themify-icons.css" type="text/css" media="all">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/jquery-ui.min.css">
        <link rel="stylesheet" href="css/fonts.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="shortcut icon" href="image/favicon.png">
        <title>
            <!--__FUEL_MARKER__2-->About        </title>
        <link href='http://fonts.googleapis.com/css?family=Raleway:400,700' rel='stylesheet' type='text/css'>
        <link href="/DEV/governancewatchers/assets/css/main.css?c=-62169955200" media="all" rel="stylesheet"/>
	        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script><script>window.jQuery || document.write('<script src="/DEV/governancewatchers/assets/js/jquery.js?c=-62169955200"><\/script>');</script>    </head>

    <section id="main_inner">
        <!--__FUEL_MARKER__3-->This is a default layout. To change this layout go to the fuel/application/views/_layouts/main.php file.    </section>

        <script src="http://localhost/DEV/governancewatchers/public_assets/js/jquery-2.0.2.min.js"></script>
        <script src="http://localhost/DEV/governancewatchers/public_assets/js/jquery.sticky.js"></script>
        <script src="http://localhost/DEV/governancewatchers/public_assets/js/masonry.min.js"></script>
        <script src="http://localhost/DEV/governancewatchers/public_assets/js/jquery-ui.min.js"></script>
        <script src="http://localhost/DEV/governancewatchers/public_assets/js/bootstrap.min.js"></script>
        <script src="http://localhost/DEV/governancewatchers/public_assets/dist/owl.carousel.js"></script>
        <script src="http://localhost/DEV/governancewatchers/public_assets/js/main.js"></script>
        <script src="http://localhost/DEV/governancewatchers/public_assets/js/bootstrap-hover-tabs.js"></script>
        <script src="/DEV/governancewatchers/assets/js/main.js?c=-62169955200" type="text/javascript" charset="utf-8"></script>
	    </body>
</html>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>