<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('13.jpg');?>" alt="Wike: Don&rsquo;t Use INEC, Security Agencies to Undermine Electoral System" class="img img-responsive" /><br />
Rivers State Governor, Nyesom Wike, has declared that political leaders would be more accountable if security agencies and the Independent National Electoral Commission (INEC) restrict themselves  to their constitutional roles.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>