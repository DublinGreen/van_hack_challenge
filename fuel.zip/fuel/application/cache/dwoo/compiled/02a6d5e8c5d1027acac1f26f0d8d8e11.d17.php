<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('buhari.jpg');?>" alt="President Muhammadu Buhari" class="img-responsive" /><br />
<br><br />
President Muhammadu Buhari on Monday assured Benue State leaders who met with him on recent killings in the state that he will never protect criminals.</p>

<p>He has again ordered the Inspector-General of Police, Ibrahim Idris, to arrest and prosecute the perpetrators of the recent killings in the state.</p>

<p>Governor Samuel Ortom disclosed these while speaking with State House correspondents at the end of the meeting that lasted about an hour.</p>

<p>Ortom said the state could not spare 10,000 hectares the Federal Government requested to establish cattle colonies in the state.</p>

<p>Ortom said they also appealed to Buhari to cause the arrest of Miyetti Allah leaders who, he said, were still issuing threats of attacks.</p>

<p>He said the President assured them that there is no room for impunity and that he would ensure there is peace in Benue.</p>

<p>The governor also denied the allegations that he was arming militias.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>