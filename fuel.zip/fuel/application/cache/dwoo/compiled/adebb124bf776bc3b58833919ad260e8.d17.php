<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('15.jpg');?>" alt="Police Detain #BringBackOurGirls Leader, Oby Ezekwesili" class="img img-responsive" /><br />
The Federal Capital Territory command&nbsp;of the Nigerian police has detained, former World bank VP and Coordinator&nbsp;of Bring Back Our Girls movement, Oby Ezekwesili and other members of her movement during a sit-out&nbsp;at the Unity Fountain in Abuja.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>