<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('_DSC0535.JPG');?>" alt="IDANRE MOUNTAIN RESORT" class="img-responsive"/><br><br />
<img src="<?php echo img_path('_DSC0543.JPG');?>" alt="IDANRE MOUNTAIN RESORT" class="img-responsive" /><br />
<br><br />
<br></p>
<p>The ascending the hills of Akure and looking south, one is confronted by stupefying vistas of the surrounding inselberg landscape bedecked with an enigmatic skyline of jagged peaks held in place by gigantic mountains smeared in glossy sheens of grey and silver- a cluster of intriguing inselbergs, towering high into the skies at the distant horizon. They are none but the magnificent Idanre Hills. Idanre is an ancient town located amidst an intricate cluster of inselbergs (hills with steep sides and rounded tops) and located south of Akure, Ondo State capital. Idanre Hills, &ldquo;The city of inselbergs&rdquo; sprawls across a land area of about 900km2 and is well known for its repertoire of picturesque landscapes and geo-tourist attractions, as well as the famous Orosun festival- one of the major factors for its consideration for upgrading to the status of a UNESCO World Heritage Site.
</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>