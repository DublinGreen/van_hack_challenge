<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>A former governor of Rivers State and Minister of&#8230;</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>