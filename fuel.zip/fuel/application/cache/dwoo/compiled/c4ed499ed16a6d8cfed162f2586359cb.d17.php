<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('olusegunmimiko.jpg');?>" alt="Mimiko to Deliver Yoruba Youth Annual Lecture on Restructuring" class="img img-responsive" /><br />
The immediate past Governor of Ondo State, Mr Olusegun Mimiko, has been billed to delivere this year&rsquo;s Yoruba Youth annual lecture scheduled to hold in Ibadan on February 1, 2018.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>