<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('1.jpg');?>" alt="THE WAY OUT: A CLARION CALL FOR COALITION FOR NIGERIA MOVEMENT" class="img img-responsive" /><br />
Since we are still in the month of January, it is appropriate to wish all Nigerians Happy 2018. I am constrained to issue this special statement at this time considering the situation of the country. Some of you may be asking, &ldquo;What has brought about this special occasion of Obasanjo issuing a Special Statement?&rdquo;.............</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>