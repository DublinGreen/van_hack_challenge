<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('olusegunmimiko.jpg');?>" alt="Mimiko to Deliver Yoruba Youth Annual Lecture on Restructuring" class="img img-responsive" /><br />
The immediate past Governor of Ondo State, Mr Olusegun Mimiko, has been billed to delivere this year&rsquo;s Yoruba Youth annual lecture scheduled to hold in Ibadan on February 1, 2018.</p>

<p>Chairman of the Local Organizing Committee of the event, Comrade Olufemi Lawson, who disclosed this in Ibadan this morning, said this year&rsquo;s theme of the lecture is &lsquo;National Development, Restructuring and the Yoruba Nation.&rsquo;</p>

<p><img src="<?php echo img_path('olusegunmimiko1.jpg');?>" alt="Mimiko to Deliver Yoruba Youth Annual Lecture on Restructuring" class="img img-responsive" /><br />
He also said the choice of this year&rsquo;s Guest Speaker, Dr Mimiko, was in realization of his strong commitment to the imperative and sustenance of an all-inclusive exemplary and inspiring leadership qualities.</p>

<p>He said state Governors, royal fathers, captains of industry, leaders of pan Yoruba organizations, including the Afenifere, representatives of youth groups and the media, are expected to be part of the historic event.</p>

<p>According to the group, the event has been scheduled for 10am on Thursday, at the Banquet Hall of the Premier Hotel in Ibadan, Oyo State.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>