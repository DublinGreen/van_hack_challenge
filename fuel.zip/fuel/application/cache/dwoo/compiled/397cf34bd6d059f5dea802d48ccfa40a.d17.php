<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('image_1.jpg');?>" alt="Former Minister Oby Ezekwesili Speaks After Release From Detention" class="img img-responsive" /><br />
The Abuja police command has released the former Minister of Education and convener of the BringBackOurGirls group, Oby Ezekwesili.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>