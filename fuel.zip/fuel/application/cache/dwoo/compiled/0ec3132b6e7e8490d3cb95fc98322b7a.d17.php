<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>A former governor of Rivers State and Minister of Transportation, Mr. Rotimi Amaechi, has assured the people of the state that those involved in the killing of Rivers people on New Year Day will face the wrath of the law.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>