<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="keywords" content="<!--__FUEL_MARKER__0-->advert on governance watchers, advertisement on governance watchers, how to advertise on governance watchers">
        <meta name="description" content="<!--__FUEL_MARKER__1-->Advertisement on governance watchers">
        <!-- Latest compiled and minified CSS -->
        
        <link rel="stylesheet" href="<!--__FUEL_MARKER__2-->http://localhost/DEV/governancewatchers/public_assets/dist/assets/owl.carousel.min.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__3-->http://localhost/DEV/governancewatchers/public_assets/dist/assets/owl.theme.default.min.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__4-->http://localhost/DEV/governancewatchers/public_assets/css/bootstrap.min.css">

        <!-- Optional theme -->
        <link rel="stylesheet" href="<!--__FUEL_MARKER__5-->http://localhost/DEV/governancewatchers/public_assets/css/bootstrap-theme.min.css">
        <link rel="stylesheet" id="themify-icons-css" href="<!--__FUEL_MARKER__6-->http://localhost/DEV/governancewatchers/public_assets/css/themify-icons.css" type="text/css" media="all">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__7-->http://localhost/DEV/governancewatchers/public_assets/css/style.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__8-->http://localhost/DEV/governancewatchers/public_assets/css/jquery-ui.min.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__9-->http://localhost/DEV/governancewatchers/public_assets/css/fonts.css">
        <link rel="stylesheet" href="<!--__FUEL_MARKER__10-->http://localhost/DEV/governancewatchers/public_assets/css/font-awesome.min.css">
        <link rel="shortcut icon" href="<!--__FUEL_MARKER__11-->http://localhost/DEV/governancewatchers/public_assets//favicon.png">
        <title>
            <!--__FUEL_MARKER__12-->Advertisement        </title>
        <link href='http://fonts.googleapis.com/css?family=Raleway:400,700' rel='stylesheet' type='text/css'>
    </head>
<body onload="startTime()">
    <!--Load Page-->
    <div class="load-page">
        <div class="sk-cube-grid">
            <div class="sk-cube sk-cube1"></div>
            <div class="sk-cube sk-cube2"></div>
            <div class="sk-cube sk-cube3"></div>
            <div class="sk-cube sk-cube4"></div>
            <div class="sk-cube sk-cube5"></div>
            <div class="sk-cube sk-cube6"></div>
            <div class="sk-cube sk-cube7"></div>
            <div class="sk-cube sk-cube8"></div>
            <div class="sk-cube sk-cube9"></div>
        </div>
    </div>
    <!-- Mobile nav -->
    <nav class="visible-sm visible-xs mobile-menu-container mobile-nav">
        <div class="menu-mobile-nav navbar-toggle">
            <span class="icon-search-mobile"><i class="fa fa-search" aria-hidden="true"></i></span>
            <span class="icon-bar"><i class="fa fa-bars" aria-hidden="true"></i></span>
        </div>
        <div id="cssmenu" class="animated">
            <div class="uni-icons-close"><i class="fa fa-times" aria-hidden="true"></i></div>
            <ul class="nav navbar-nav animated">
                <li class="home-icon"><a href='http://localhost/DEV/governancewatchers/page/index'>Home</a></li>
                <li><a href='http://localhost/DEV/governancewatchers/about/'>About</a></li>
				<li class="has-sub">><a href='#'>News</a>
					<ul>
						<li><a href="http://localhost/DEV/governancewatchers/blog/">All News</a></li>
						<li><a href='http://localhost/DEV/governancewatchers/blog/categories/confirmed-news'>CONFIRMED NEWS</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/crime'>CRIME</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/economic'>ECONOMIC</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/editor-pick'>EDITOR-PICK</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/foreign'>FOREIGN</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/hot-news'>HOT-NEWS</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/politics'>POLITICS</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/social'>SOCIAL</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/unconfirmed-news'>UNCONFIRMED NEWS</a></li>					</ul>
                </li>
                <li><a href='http://localhost/DEV/governancewatchers/page/survey'>Survey</a></li>
                <li><a href='http://localhost/DEV/governancewatchers/page/performance'>Governance Performance</a></li>
                <li><a href='http://localhost/DEV/governancewatchers/page/contact'>Contact</a></li>
                <!--<li class="has-sub"><a href='#'>Features</a>
                    <ul>
                        <li class="has-sub"><a href="#">Sidebar</a>
                            <ul>
                                <li><a href="03_01_01_left_sidebar.html">Left Sidebar</a></li>
                                <li><a href="03_01_02_right_sidebar.html">Right Sidebar</a></li>
                                <li><a href="03_01_03_without_sidebar.html">Without Sidebar</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>-->
            </ul>
            <div class="uni-nav-mobile-bottom">
                <div class="form-search-wrapper-mobile">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search">
                        <span class="input-group-addon success"><i class="fa fa-search"></i></span>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </nav>
    <!-- End mobile menu -->



    <div id="wrapper-container" class="site-wrapper-container">
        <header>
            <div class="vk-header-default">
                <div class="container-fluid">
                    <div class="row">
                        <div class="vk-top-header">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-4 col-sm-4">
                                        <div class="vk-top-header-1">
                                            <ul>
                                                <li><a href="http://localhost/DEV/governancewatchers/page/contact"> Contact</a></li>
                                                <!--<li><a href="#">Purchase Now</a></li>-->
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class="vk-top-header-2">
                                            <ul>
                                                <li><span id="datetime-current"></span></li>
                                                <li>-</li>
                                                <li><span id="year-current"></span></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <div class="vk-top-header-3">
                                            <ul>
                                                <li><a target="_blank" href="<!--__FUEL_MARKER__13-->https://facebook.com"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                <li><a target="_blank" href="<!--__FUEL_MARKER__14-->https://twitter.com"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                <li><a target="_blank" href="<!--__FUEL_MARKER__15-->https://googleplus.com"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                <li><a target="_blank" href="<!--__FUEL_MARKER__16-->https://instagram.com"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                <li><a target="_blank" href="<!--__FUEL_MARKER__17-->https://youtube.com"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="vk-between-header">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="vk-between-header-logo">
                                            <a href="http://localhost/DEV/governancewatchers/page/index"><img src="<!--__FUEL_MARKER__18-->http://localhost/DEV/governancewatchers/public_assets/image/governance_watchers.png" alt="" class="img-responsive"></a>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-md-offset-1">
                                        <div class="vk-between-header-banner">
                                            <!--__FUEL_MARKER__19--><a href="https://facebook.com" target="_blank"><img src="/DEV/governancewatchers/assets/images/ad_top.jpg" alt="advert" title="top advert" class="img-responsive" /></a>                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="visible-md visible-lg vk-bottom-header uni-sticky">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-11">
                                        <div class="cssmenu">
                                            <ul>
                                                <li class="home-icon"><a href='http://localhost/DEV/governancewatchers/page/index'><i class="fa fa-home" aria-hidden="true"></i></a>
                                                </li>
												<li><a href='http://localhost/DEV/governancewatchers/about/'>About</a></li>
												<li class="has-sub"><a href='#'>News</a>
													<ul>
														<li><a href="http://localhost/DEV/governancewatchers/blog/">All News</a></li>
														<li><a href='http://localhost/DEV/governancewatchers/blog/categories/confirmed-news'>CONFIRMED NEWS</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/crime'>CRIME</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/economic'>ECONOMIC</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/editor-pick'>EDITOR-PICK</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/foreign'>FOREIGN</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/hot-news'>HOT-NEWS</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/politics'>POLITICS</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/social'>SOCIAL</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/unconfirmed-news'>UNCONFIRMED NEWS</a></li>													</ul>
												</li>
												<li><a href='http://localhost/DEV/governancewatchers/page/survey'>Survey</a></li>
												<li><a href='http://localhost/DEV/governancewatchers/page/performance'>Governance Performance</a></li>
												<li><a href='http://localhost/DEV/governancewatchers/page/contact'>Contact</a></li>
                                                <!--<li class="has-sub"><a href='#'>Category</a>
                                                    <ul>
                                                        <li><a href="02_01_list.html">List</a></li>
                                                        <li><a href="02_02_list.html">List 2</a></li>
                                                        <li><a href="02_03_grid_2_columns.html">Grid 2 Columns</a></li>
                                                        <li><a href="02_04_grid_2_columns_2.html">Grid 2 Columns 2</a></li>
                                                        <li><a href="02_05_mixed.html">Mixed</a></li>
                                                    </ul>
                                                </li>-->
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-1">
                                        <div class="vk-bottom-header-search toggle-form">
                                            <i class="fa fa-search" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                                <!--Form search-->
                                <div class="form-search-wrapper">
                                    <div class="input-group">
                                        <input type="text" class="form-control" placeholder="Search">
                                        <span class="input-group-addon success"><i class="fa fa-search"></i></span>
                                    </div>
                                </div>
                                
							</div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        
        <div id="main-content" class="site-main-content">
        <div id="home-main-content" class="site-home-main-content">

            <div class="uni-about">

                <div class="uni-about-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8">
                                <!--<div class="breadcrumb breadcrumb-search">
                                    <a href="#">Home</a>
                                    <a href="http://localhost/DEV/governancewatchers/about/" class="active">about</a>
                                </div>-->

                                <div class="uni-about-content">
                                    <h2><!--__FUEL_MARKER__20-->Advertisement</h2>
                                    <div class="description">
										<!--__FUEL_MARKER__21--><p>Thirty parties can advertise the products and services on Governance Watchers. You can advertise on 3 main slots.</p>
<ol>
    <li>Top Homepage advert</li>
    <li>Top Side Homepage advert</li>
    <li>Bottom Side Homepage advert</li>
    <li>Sponsor news advert<del></del></li>    
</ol>                                    </div>

									<br><br>
                                    <!-- CONTACT INFORMATION-->
                                    <div class="uni-about-contact-info">
                                        <h2>Contact Infomation</h2>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="uni-about-contact-info-left">
                                                    <ul>
                                                        <li>
                                                            <h4><i class="fa fa-home" aria-hidden="true"></i> Office Address</h4>
                                                            <!--__FUEL_MARKER__22--><strong>Ondo Address</strong>
<br>
<p>3, Ilaje Close, Ijapo Estate Akure.</p><br>
                                                            <!--__FUEL_MARKER__23--><strong>Canada</strong>

<p>909, Mandolin Place, Mississauga, Ontario</p><br>
                                                            <!--__FUEL_MARKER__24--><strong>Ireland</strong>					
<p>10 Mount Eustace Walk				
Tyrrelstown, Dublin 15</p><br>
                                                        </li>
                                                        <li>
                                                            <h4><i class="fa fa-envelope" aria-hidden="true"></i> Office Email</h4>
															<p><!--__FUEL_MARKER__25-->info@governancewatchers.com</p>
                                                            <p><!--__FUEL_MARKER__26-->support@governancewatchers.com</p>
                                                        </li>
                                                        <li>
                                                            <h4><i class="fa fa-phone" aria-hidden="true"></i> Tel</h4>
                                                            <p><!--__FUEL_MARKER__27-->+2349063190670</p>
                                                            <p><!--__FUEL_MARKER__28-->+2348095060650</p>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="uni-about-contact-info-right">
                                                    <div class="uni-about-contact-map">
                                                        <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2520.3558605259554!2d-0.1305261839151272!3d50.824572079528714!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4875859878db2cc7%3A0xff129250121f260d!2s45+Queen's+Park+Rd%2C+Brighton+BN2+0GJ%2C+UK!5e0!3m2!1sen!2s!4v1505207016897" allowfullscreen=""></iframe>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <aside class="widget-area">

                                    <aside class="widget">
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-ad">
                                                    <!--__FUEL_MARKER__29--><a href="https://facebook.com" target="_blank"><img src="/DEV/governancewatchers/assets/images/side-advert.jpg" alt="side advert" title="side advert" class="img-responsive" /></a>                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-facebook">
                                                <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ffacebook&amp;tabs=timeline&amp;width=340&amp;height=500&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId" width="340" height="500" style="border:none;overflow:hidden"></iframe>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <h3 class="widget-title">Stay Connected</h3>
                                        <div class="widget-content">
                                            <div class="vk-home-default-right-stay">
                                                <div class="vk-right-stay-body">
                                                    <a class="btn btn-block btn-social btn-facebook">
                                                        <span class="icon"><i class="fa fa-facebook"></i></span>
                                                        <span class="info"> 2134 Like</span>
                                                        <span class="text">Like</span>
                                                    </a>
                                                    <a class="btn btn-block btn-social btn-twitter">
                                                        <span class="icon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                                                        <span class="info"> 13634 Follows</span>
                                                        <span class="text">Follows</span>
                                                    </a>
                                                    <a class="btn btn-block btn-social btn-youtube">
                                                        <span class="icon"><i class="fa fa-youtube-play" aria-hidden="true"></i></span>
                                                        <span class="info">10634 Subscribers</span>
                                                        <span class="text">Subscribe</span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </aside>

                                    <aside class="widget">
                                        <h3 class="widget-title">News Tags</h3>
                                        <div class="widget-content">											
                                            <div class="vk-home-default-right-tags">
                                                <ul>
													<li><a href='http://localhost/DEV/governancewatchers/blog/categories/confirmed-news'>Confirmed News</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/crime'>crime</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/economic'>economic</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/editor-pick'>editor-pick</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/foreign'>foreign</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/hot-news'>hot-news</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/politics'>politics</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/social'>Social</a></li><li><a href='http://localhost/DEV/governancewatchers/blog/categories/unconfirmed-news'>Unconfirmed News</a></li>                                                </ul>
                                            </div>
                                        </div>
                                    </aside>

                                </aside>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>

        </div>
    </div>

        <footer>
            <div class="container-fluid">
                <div class="row">
                    <div class="vk-sec-footer">
                        <div class="container">
                            <div class="row">
                                <div class="vk-footer">
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <div class="widget-title">
                                                <a href="#"><img src="<!--__FUEL_MARKER__30-->http://localhost/DEV/governancewatchers/public_assets/image/governance_watchers.png"" alt="" class="img-responsive"></a>
                                            </div>
                                            <div class="widget-content">
                                                <div class="vk-footer-1">

                                                    <div class="vk-footer-1-content">
                                                        <p>
															<!--__FUEL_MARKER__31-->Information that mirrors variability of opinions and meaningful discussions about development of democratic society in Nigeria. Governance watchers provides instant news reports, analytical materials, review.                                                        </p>
                                                        <div class="vk-footer-1-address">
                                                            <ul>
                                                                <li><i class="fa fa-map-marker" aria-hidden="true"></i> <span><!--__FUEL_MARKER__32-->3, Ilaje Close, Ijapo Estate Akure.</span></li>
                                                                <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <span><a href="mailto:<!--__FUEL_MARKER__33-->info@governancewatchers.com"><!--__FUEL_MARKER__34-->info@governancewatchers.com</a></span></li>
                                                                <li><i class="fa fa-headphones" aria-hidden="true"></i> <span> <!--__FUEL_MARKER__35-->+2349063190670</span></li>
                                                            </ul>
                                                        </div>
                                                        <div class="vk-footer-1-icon">
                                                            <ul>
																<li><a target="_blank" href="<!--__FUEL_MARKER__36-->https://facebook.com"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
																<li><a target="_blank" href="<!--__FUEL_MARKER__37-->https://twitter.com"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
																<li><a target="_blank" href="<!--__FUEL_MARKER__38-->https://googleplus.com"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
																<li><a target="_blank" href="<!--__FUEL_MARKER__39-->https://instagram.com"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
																<li><a target="_blank" href="<!--__FUEL_MARKER__40-->https://youtube.com"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <h3 class="widget-title"> Latest News</h3>
                                            <div class="widget-content">
                                                <div class="vk-footer-2">
                                                    <div class="vk-footer-2-content">
														  <ul>
																																		<li>
																			<!--<div class="vk-footer-img">
																				<img src="http://localhost/DEV/governancewatchers/assets/images/South-African-Airways-Airbus-A319-100_PlanespottersNet_159129.jpg" alt='Nigerian Drug Law Agency Arrests Nine Drug Traffickers Including A South African At Lagos Airport' width='10%' height='10%' />																			</div>-->
																			<div class="vk-footer-content" style="padding-left: 0px;">
																				<div class="vk-footer-title">
																					<h2><a href="#"><a href="http://localhost/DEV/governancewatchers/blog/2018/01/17/nigerian-drug-law-agency-arrests-nine-drug-traffickers-including-a-south-african-at-lagos-airport">Nigerian Drug Law Agency Arrests Nine Drug Traffickers Including A South African At Lagos Airport </a></a></h2>
																				</div>
																				<div class="vk-footer-time">
																					<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> Wednesday 17th of January 2018</div>
																				</div>
																			</div>
																			<div class="clearfix"></div>
																		</li>
																																		<li>
																			<!--<div class="vk-footer-img">
																				<img src="http://localhost/DEV/governancewatchers/assets/images/Charles_okah-2.jpg" alt='Panic Grips Kuje Prisons Officials As Alleged MEND's Charles Okah Fakes Escape From Custody' width='10%' height='10%' />																			</div>-->
																			<div class="vk-footer-content" style="padding-left: 0px;">
																				<div class="vk-footer-title">
																					<h2><a href="#"><a href="http://localhost/DEV/governancewatchers/blog/2018/01/17/panic-grips-kuje-prisons-officials-as-alleged-mends-charles-okah-fakes-escape-from-custody">Panic Grips Kuje Prisons Officials As Alleged MEND's Charles Okah Fakes Escape From Custody </a></a></h2>
																				</div>
																				<div class="vk-footer-time">
																					<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> Wednesday 17th of January 2018</div>
																				</div>
																			</div>
																			<div class="clearfix"></div>
																		</li>
																																		<li>
																			<!--<div class="vk-footer-img">
																				<img src="http://localhost/DEV/governancewatchers/assets/images/Rotimi-aketi-Akeredolu.jpg" alt='We Are Ready To Face Fulani Herdsmen With Force, Says Gov. Akeredolu' width='10%' height='10%' />																			</div>-->
																			<div class="vk-footer-content" style="padding-left: 0px;">
																				<div class="vk-footer-title">
																					<h2><a href="#"><a href="http://localhost/DEV/governancewatchers/blog/2018/01/17/we-are-ready-to-face-fulani-herdsmen-with-force-says-gov-akeredolu">We Are Ready To Face Fulani Herdsmen With Force, Says Gov. Akeredolu </a></a></h2>
																				</div>
																				<div class="vk-footer-time">
																					<div class="time"><i class="fa fa-calendar" aria-hidden="true"></i> Wednesday 17th of January 2018</div>
																				</div>
																			</div>
																			<div class="clearfix"></div>
																		</li>
																															</ul>
                                                      </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>
                                    <div class="footer-main-content-element col-sm-4">
                                        <aside class="widget">
                                            <h3 class="widget-title">Twitter Feed</h3>
                                            <div class="widget-content">
                                                <div class="vk-footer-3">
                                                    <div class="vk-footer-3-content">
                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> MaxNews</a></span>
                                                            Your body is like a race car!! You need to fuel it right to keep performing at your best!
                                                        </p>
                                                        <div class="time">about 5 days ago</div>

                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> MaxNews</a></span>
                                                            Your body is like a race car!! You need to fuel it right to keep performing at your best!
                                                        </p>
                                                        <div class="time">about 5 days ago</div>

                                                        <p>
                                                            <span><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> MaxNews</a></span>
                                                            Your body is like a race car!! You need to fuel it right to keep performing at your best!
                                                        </p>
                                                        <div class="time">about 5 days ago</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </aside>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="vk-sub-footer">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="vk-sub-footer-1">
                                            <p>
                                                <span><!--__FUEL_MARKER__41-->Governance watchers</span>
                                                -  News & More.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-5 col-md-offset-2">
                                        <div class="vk-sub-footer-2">
                                            <ul>
                                                <li><a href="http://localhost/DEV/governancewatchers/disclaimer">Disclaimer </a></li>
                                                <li><a href="http://localhost/DEV/governancewatchers/privacy"> Privacy</a></li>
                                                <li><a href="http://localhost/DEV/governancewatchers/advertisement"> Advertisement</a></li>
                                                <li><a href="http://localhost/DEV/governancewatchers/page/contact">Contact us</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>

        <script src="<!--__FUEL_MARKER__42-->http://localhost/DEV/governancewatchers/public_assets/js/jquery-2.0.2.min.js"></script>
        <script src="<!--__FUEL_MARKER__43-->http://localhost/DEV/governancewatchers/public_assets/js/jquery.sticky.js"></script>
        <script src="<!--__FUEL_MARKER__44-->http://localhost/DEV/governancewatchers/public_assets/js/masonry.min.js"></script>
        <script src="<!--__FUEL_MARKER__45-->http://localhost/DEV/governancewatchers/public_assets/js/jquery-ui.min.js"></script>
        <script src="<!--__FUEL_MARKER__46-->http://localhost/DEV/governancewatchers/public_assets/js/bootstrap.min.js"></script>
        <script src="<!--__FUEL_MARKER__47-->http://localhost/DEV/governancewatchers/public_assets/dist/owl.carousel.js"></script>
        <script src="<!--__FUEL_MARKER__48-->http://localhost/DEV/governancewatchers/public_assets/js/main.js"></script>
        <script src="<!--__FUEL_MARKER__49-->http://localhost/DEV/governancewatchers/public_assets/js/bootstrap-hover-tabs.js"></script>
    </body>
</html>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>