<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?>	
	<section id="main_inner">
		<!--__FUEL_MARKER__0-->This is a default layout. To change this layout go to the fuel/application/views/_layouts/main.php file.	</section>
	
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>