<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>The state police command spokesperson, David Misal, who confirmed the development, said the lawmaker who represented Takum II Constituency in the State Assembly, was found dead  along Takum-Kashimbila road in his local government, Takum Local Government Area of the state today January 15th.</p>

<p>Misal added that preliminary investigations shows that Ibi might have died three days before his body was found today.</p>

<p>While the police said they were making efforts to rescue the legislator, no demand for ransom was made from any quarter.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>