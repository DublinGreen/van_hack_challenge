<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>Officials of Kuje Prisons were, on Thursday night, thrown panic for over one hour after it was discovered that Mr. Charles Okah, a leader of the Movement for the Emancipation of Niger Delta (MEND), could not be found in his cell by warders on the night shift at about 8 pm.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>