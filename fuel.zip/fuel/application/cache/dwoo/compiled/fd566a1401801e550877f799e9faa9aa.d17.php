<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('9.jpg');?>" alt="A Rise in Kidnapping" class="img img-responsive" /><br />
The news of the recent attacks by herdsmen on some communities in Benue State almost took the shine off other equally critical issues in the country, particularly the rising incidences of kidnapping across the country. From the South to the North, there is always one case or two of kidnapping somewhere. It is a damning verdict on the security architecture of the country.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>