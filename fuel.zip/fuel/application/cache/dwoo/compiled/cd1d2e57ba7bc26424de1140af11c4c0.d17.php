<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('00.jpg');?>" alt="We Are Still Living In Fear, Ortom Tells APC Governors" class="img img-responsive" /><br />
Governor Samuel Ortom of Benue, on Friday, said that people of the state live in fear and still under siege of Fulani herdsmen.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>