<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>Human rights activist, Mark Adebayo has condemned President Muhammadu Buhari over his inability to arrest and prosecute members of Miyetti Allah despite their continuous killings across the country.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>