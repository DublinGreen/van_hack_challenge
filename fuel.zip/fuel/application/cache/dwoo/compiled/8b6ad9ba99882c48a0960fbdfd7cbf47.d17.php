<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><video controls="" width="360" height="280">
                                                    <source src="http://localhost/DEV/olusegunmimiko.org/UPLOADS/VIDEOS/203/Welcome To Idanre Hills Resort.mp4" type="video/mp4">
                                                    Your browser does not support the video tag.
                                                </video>
<p>Idanre Mountain Resort(Tourism in Ondo State)<p>
<br><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>