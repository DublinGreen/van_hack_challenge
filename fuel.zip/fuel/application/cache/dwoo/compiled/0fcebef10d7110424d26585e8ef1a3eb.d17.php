<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>Believe in the formation of a radical, spirited and peoples&#8217; centered political movement in Nigeria, a movement that is designed with a specific mandate to redeem and salvage Nigeria. We urgently need a mass movement that will place Nigeria above other considerations.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>