<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('Rotimi-aketi-Akeredolu.jpg');?>" alt="We Are Ready To Face Fulani Herdsmen With Force, Says Gov. Akeredolu" class="img img-responsive" /><br />
<br><br />
Ondo State governor, Mr. Rotimi Akeredolu, has declared that his administration will apply force to arrest the menace of Fulani herdsmen in the state. The governor made the declaration in Akure, on Sunday, during an event to commemorate the Armed Forces Remembrance Day.&ldquo;We have been using security agencies to engage the herdsmen to carry out their business peacefully but when engagement fails, we will use force. We will confront the herdsmen with all we have,&#8221; the governor said.</p>

<p>Ondo State governor, Mr. Rotimi Akeredolu, has declared that his administration will apply force to arrest the menace of Fulani herdsmen in the state. The governor made the declaration in Akure, on Sunday, during an event to commemorate the Armed Forces Remembrance Day.</p>

<p>&ldquo;We have been using security agencies to engage the herdsmen to carry out their business peacefully but when engagement fails, we will use force. We will confront the herdsmen with all we have,&#8221; the governor said.</p>

<p>He vowed that his administration will do everything to protect the people of the state, adding that all the security agencies have been put on red alert to monitor the activities of herdsmen.<br />
He condemned the recurrent clashes between farmers and herdsmen across the country, adding that his government will ensure such does not occur in the state.</p>

<p>&#8220;I must not fail to make a statement on the unfortunate recurrence of clashes between the farmers and pastoralists otherwise known as herdsmen. Our state has had her share of the crisis but not on the horrendous scale whose odious effect continues to reverberate throughout the country. Our Administration is taking proactive steps to ensure that this obnoxious phenomenon is nipped in the bud,&#8221; he said.</p>

<p>While encouraging those who want to visit the state to come, he warned that those coming to perpetrate crime under should avoid the state or face fire. The governor noted that farmers in the state have suffered crop losses on account of the activities of herdsmen and their livestock, a trend his administration is minded to stop.</p>

<p>Mr. Akeredolu condemned the repeated attacks on the farmland of Mr. Olu Falae, former Secretary to Government of Federation, by the Fulani herdsmen.</p>

<p>&ldquo;We will not tolerate any act of brigandage. We will defend the right of our people to engage farming without let of any hindrance of any sort. We will sanction with impassioned severity any acts which seek to tilt the balance of harmonious coexistence in the state towards anarchy. The full weight of the law will be brought to bear on criminal elements&rdquo; the governor vowed,&#8221; said the governor.</p>

<p>He urged farmers in the state to go about their business and ensure they report suspicious movements in their areas to security agencies.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>