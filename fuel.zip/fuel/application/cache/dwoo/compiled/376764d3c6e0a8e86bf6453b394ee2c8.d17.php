<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('Charles_okah-2.jpg');?>" alt="Panic Grips Kuje Prisons Officials As Alleged MEND's Charles Okah Fakes Escape From Custody" class="img img-responsive" /><br />
<br><br />
<img src="<?php echo img_path('Okah-Charles-Dummy.jpeg');?>" alt="Panic Grips Kuje Prisons Officials As Alleged MEND's Charles Okah Fakes Escape From Custody" class="img img-responsive" /><br />
<br><br />
<img src="<?php echo img_path('Okah-note.jpeg');?>" alt="Panic Grips Kuje Prisons Officials As Alleged MEND's Charles Okah Fakes Escape From Custody" class="img img-responsive" /><br />
<br></p>

<p>Officials of Kuje Prisons were, on Thursday night, thrown panic for over one hour after it was discovered that Mr. Charles Okah, a leader of the Movement for the Emancipation of Niger Delta (MEND), could not be found in his cell by warders on the night shift at about 8 pm.&nbsp;  &nbsp;  &nbsp;   </p>

<p>The situation led to a frantic search.</p>

<p>While prison officials were searching in panic, Okah was lying under his bed and had propped a dummy on his bed.</p>

<p>The MEND leader was said to have taken the action because of prison officials&#8217; refusal to take him to the National Hospital, Abuja, where he was scheduled to run a battery of medical tests.</p>

<p>Prison sources told SaharaReporters that the Comptroller of Prisons, Federal Capital Territory Command, Mr. Sylvester Nwakuche, received a text message from the Directorate State Security (DSS) informing him that a man that looks like Mr. Okah was sighted boarding a vehicle at Gwagwalada area of the Federal Capital City.</p>

<p>The Comptroller contacted the Officer in Charge of Kuje Prison to confirm if Mr. Okah was still in custody. </p>

<p>The Officer in Charge and many other officers rushed to Mr. Okah&#8217;s cell (Number 6), where they were relieved to see a man sleeping and left to report to the Comptroller. They, however, did not ascertain if it was the MEND leader that was sleeping.</p>

<p>Not satisfied, the Comptroller asked them to return to the cell, where they discovered that sleeping figure they assumed to be Mr. Okah was a dummy in a sleeping position. They also found a note from Mr.Okah, which he addressed to the Comptroller-General of the Nigeria Prisons Service.</p>

<p>The officials read the note, which led to further panic as they were reminded of their colleagues, who lost their jobs as a result of a previous jailbreak in which</p>

<p>Mr. Okah&#8217;s name was mentioned.&nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp; </p>

<p>Mr. Okah later emerged from under the bed to chide them for responding promptly to news of an escape but were reluctant to take him to hospital.</p>

<p>Before Friday night&#8217;s drama, Mr. Okah, who has previously stated that he donated a kidney to his mother 35 years ago, had complained that the Kuje Prison authorities were treating complaints about his health with levity.&nbsp;  &nbsp;  &nbsp; </p>

<p>He had reportedly complained of passing blood in his urine, a complaint to which the prison authorities did not respond until after five months when they took him to the National Hospital Abuja eight weeks ago. <br />
After that visit, during which he was Okah was reportedly advised to run a series of tests by one Dr. Badamasi, he&rsquo;s not been taken back to the hospital to run the tests even after complaining that his health was deteriorating. </p>

<p>The prison physician, Dr. Osakwe, said he had applied to the authorities in vain to make arrangements for transportation and security to convey him and others to referral hospitals.</p>

<p>Mr. Okah, who is detained for allegedly masterminding the 1 October 2010 bombing in Abuja, has just one more adjourned date of January 24, 2018, for Adoption of written address before a date for judgement is set for his trial which has lasted years while he remained in detention.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>