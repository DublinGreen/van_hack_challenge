<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('_DSC0535.JPG');?>" alt="IDANRE MOUNTAIN RESORT" class="img-responsive" /><br />
<br><br><br />
The ascending the hills of Akure and looking south, one is confronted by stupefying vistas of the surrounding inselberg landscape bedecked with an enigmatic skyline of jagged peaks held in place by gigantic mountains smeared in glossy sheens of grey and silver- a cluster of intriguing inselbergs, to&#8230;...</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>