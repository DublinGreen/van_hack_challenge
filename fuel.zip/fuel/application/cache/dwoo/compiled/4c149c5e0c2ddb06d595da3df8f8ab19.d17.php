<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('apc.jpg');?>" alt="APC" class="img img-resonsive"/><br />
<br><br />
The All Progressives Congress National Working Committee and governors elected on its platform would meet at the party national secretariat on Wednesday, Jan. 17.</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>