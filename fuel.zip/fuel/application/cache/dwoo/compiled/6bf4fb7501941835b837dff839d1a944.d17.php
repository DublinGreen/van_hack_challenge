<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>This is just a test for the blog function</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>