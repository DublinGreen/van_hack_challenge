<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>President Muhammadu Buhari on Monday assured Benue&#8230;</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>