<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p><img src="<?php echo img_path('blog/funke_edited.jpeg');?>" alt="" /><br /></p>

<p>Going to buy fuel</p>

<p><br><br></p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>