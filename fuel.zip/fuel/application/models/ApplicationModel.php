<?php

#GENERAL APP MODEL


class ApplicationModel extends CI_Model {
	
	public $cookieSurveyName = "survey";
	public $cookieSurveyPrefix = "governance_watchers";

	//Constructor method 
	// used to load essential CI library and helper
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->database();
        $this->load->helper('html');
        $this->load->helper('url');
        $this->load->library('email');
        $this->load->helper('cookie');
    }

	//Gets Blog categories and orders by name in ASC 
    public function getBlogCategories() {
        $resultSet = "";

		$this->db->order_by(' name', 'ASC');
        $query = $this->db->get('fuel_categories');

        if ($query->num_rows() > 0) {
            $resultSet = $query->result();
        }

        return $resultSet;
    }
    
    //Gets category by id
	public function getCategoryById($id){
        $resultSet = "";

        $query = $this->db->get_where('fuel_categories', array('id' => $id));

        if ($query->num_rows() > 0) {
            $resultSet = $query->row();
        }

        return $resultSet;		
	}
    
    //Gets Blog posts, order by id in DESC
	public function getBlogPost() {
        $resultSet = "";

        $this->db->order_by('id', 'DESC');
        $query = $this->db->get('fuel_blog_posts');

        if ($query->num_rows() > 0) {
            $resultSet = $query->result();
        }

        return $resultSet;
    }
    
    //Gets survey resultSet by survey id
    public function getSurveyById($id){
		$resultSet = "";

		$query = $this->db->get_where('survey', array('id' => $id));

        if ($query->num_rows() > 0) {
            $resultSet = $query->row();
        }

        return $resultSet;		
	}
    
    //Gets all the survey resultSets
    public function getSurvey(){
		$resultSet = "";

        $this->db->order_by('id', 'DESC');
        $query = $this->db->get('survey');

        if ($query->num_rows() > 0) {
            $resultSet = $query->result();
        }

        return $resultSet;
	}
	
	//Gets survey options, using survey id to map survey options
	public function getOptionsForSurvey($surveyId){
		$resultSet = "";

		$this->db->order_by('options_slot', 'ASC');
        $query = $this->db->get_where('survey_options', array('survery_id' => $surveyId));

        if ($query->num_rows() > 0) {
            $resultSet = $query->result();
        }

        return $resultSet;		
	}
	
	//Get survey answers by survey id
	public function getSurveyAnswers($surveyId){
		$resultSet = "";

		$this->db->order_by('survey_option_choice', 'ASC');
        $query = $this->db->get_where('survey_answers', array('survey_id' => $surveyId));

        if ($query->num_rows() > 0) {
            $resultSet = $query->result();
        }

        return $resultSet;	
	}
	
	//Gets survey answer for each survey opinion slot
	public function getSurveyAnswersOpinion($surveyId){
		$resultSet = "";

		$this->db->order_by('id', 'DESC');
        $query = $this->db->get_where('survey_answers', array('survey_id' => $surveyId));

        if ($query->num_rows() > 0) {
            $resultSet = $query->result();
        }

        return $resultSet;	
	}
	
	//Gets survey answer option count
	// Used for per calculation
	public function getSurveyAnswersOptionCount($surveyId,$option){
		$resultSet = "";

        $query = $this->db->query("SELECT COUNT(*) as total FROM survey_answers WHERE survey_option_choice = '{$option}' AND survey_id = {$surveyId}");
        if ($query->num_rows() > 0) {
            $resultSet = $query->row();
        }

        return $resultSet;	
	}
	
	//Updates survey question and answer results
	public function updateSurveyQAndAResults($survey_id,$survey_question,
	$survey_option_a_per,$survey_option_b_per,$survey_option_c_per,$survey_option_d_per){
		
		$query = $this->db->get_where('survey_q_and_a_results', array('survey_id' => $survey_id));
		if ($query->num_rows() > 0){
			$updateData = array(
               'survey_question' => $survey_question,
               'survey_option_a_per' => $survey_option_a_per,
               'survey_option_b_per' => $survey_option_b_per,
               'survey_option_c_per' => $survey_option_c_per,
               'survey_option_d_per' => $survey_option_d_per,
            );
			$this->db->where('survey_id', $survey_id);
			$this->db->update('survey_q_and_a_results', $updateData); 
			
		}else{
			$insertData = array(
				'survey_id' => $survey_id,
               'survey_question' => $survey_question,
               'survey_option_a_per' => $survey_option_a_per,
               'survey_option_b_per' => $survey_option_b_per,
               'survey_option_c_per' => $survey_option_c_per,
               'survey_option_d_per' => $survey_option_d_per,
			);		
			$this->db->insert('survey_q_and_a_results', $insertData); 	
			
		}
	}
	
	//Add to survey cookie
	public function addToSurveyCookie($cookieName){
		$cookie = array(
			'name'   => $cookieName,
			'value'  => "true",
			'expire' => '2592000', // 30 days This is a day (86400)
			'domain' => base_url(),
			'path'   => '/',
			'prefix' => $this->cookieSurveyPrefix,
			'secure' => TRUE
		);

		$this->input->set_cookie($cookie);
	}
	
	//Gets survey cookie
	public function getSurveyCookie($cookieName){
		//$this->input->cookie($cookieName);
		$this->input->cookie($cookieName, TRUE); // with XSS filter
	}
	
	//deletes survey cookie
	public function deleteSurveyCookie($cookieSurveyName){
		delete_cookie($cookieSurveyName);
	}
	
	//Get user IP Addr
	public function getIP(){
		return $this->input->ip_address();
	}
    
}
